#include "buildspans.h"
#include "../crucible/crucible.h"
#include "ext_proto.h"
#include "ext_critical.h"
#include "ext_systhread.h"
#include "../shared/visualize.h"
#include "../shared/async_worker.h"
#include "../shared/logging.h"
#include <math.h>
#include <stdlib.h> // For qsort
#include <string.h> // For isdigit
#if defined(WIN_VERSION) || defined(_WIN32)
#include <windows.h>
#else
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dlfcn.h>
#include <unistd.h>
#endif
#include <time.h>

// Helper function to generate a hierarchical key symbol
t_symbol* generate_hierarchical_key(t_symbol *palette, t_symbol *track, t_symbol *bar, t_symbol *key) {
    char key_str[512];
    snprintf(key_str, 512, "%s::%s::%s::%s", palette->s_name, track->s_name, bar->s_name, key->s_name);
    return gensym(key_str);
}

// Helper function to parse a hierarchical key symbol.
// Returns 1 on success, 0 on failure.
// Pointers passed for palette, track, bar, and key will be set to newly allocated char buffers.
// The caller is responsible for freeing these buffers.
int parse_hierarchical_key(t_symbol *hierarchical_key, char **palette, char **track, char **bar, char **key) {
    const char *key_str = hierarchical_key->s_name;
    const char *first_delim = strstr(key_str, "::");
    if (!first_delim) return 0;

    const char *second_delim = strstr(first_delim + 2, "::");
    if (!second_delim) return 0;

    const char *third_delim = strstr(second_delim + 2, "::");
    if (!third_delim) return 0;

    size_t pal_len = first_delim - key_str;
    *palette = (char *)sysmem_newptr(pal_len + 1);
    strncpy(*palette, key_str, pal_len);
    (*palette)[pal_len] = '\0';

    size_t track_len = second_delim - (first_delim + 2);
    *track = (char *)sysmem_newptr(track_len + 1);
    strncpy(*track, first_delim + 2, track_len);
    (*track)[track_len] = '\0';

    size_t bar_len = third_delim - (second_delim + 2);
    *bar = (char *)sysmem_newptr(bar_len + 1);
    strncpy(*bar, second_delim + 2, bar_len);
    (*bar)[bar_len] = '\0';

    *key = (char *)sysmem_newptr(strlen(third_delim + 2) + 1);
    strcpy(*key, third_delim + 2);

    return 1;
}


// Helper function to convert an atomarray to a string for buildspans_loging
char* atomarray_to_string(t_atomarray *arr) {
    if (!arr) return NULL;

    long count = atomarray_getsize(arr);
    if (count == 0) {
        char *empty_str = (char *)sysmem_newptr(3);
        strcpy(empty_str, "[]");
        return empty_str;
    }

    long buffer_size = 256; // Initial size
    char *buffer = (char *)sysmem_newptr(buffer_size);
    long offset = 0;

    offset += snprintf(buffer + offset, buffer_size - offset, "[");

    for (long i = 0; i < count; i++) {
        t_atom a;
        atomarray_getindex(arr, i, &a);

        char temp_str[64];
        if (atom_gettype(&a) == A_FLOAT) {
            snprintf(temp_str, 64, "%.2f", atom_getfloat(&a));
        } else if (atom_gettype(&a) == A_LONG) {
            snprintf(temp_str, 64, "%ld", atom_getlong(&a));
        } else {
            snprintf(temp_str, 64, "?");
        }

        if (buffer_size - offset < strlen(temp_str) + 4) { // +4 for ", ]\0"
            buffer_size *= 2;
            buffer = (char *)sysmem_resizeptr(buffer, buffer_size);
            if (!buffer) return NULL;
        }

        offset += snprintf(buffer + offset, buffer_size - offset, "%s", temp_str);
        if (i < count - 1) {
            offset += snprintf(buffer + offset, buffer_size - offset, ", ");
        }
    }

    snprintf(buffer + offset, buffer_size - offset, "]");
    return buffer;
}


// Helper function to create a deep copy of a t_atomarray
t_atomarray* atomarray_deep_copy(t_atomarray *src) {
    if (!src) {
        return NULL;
    }
    long count;
    t_atom *atoms;
    atomarray_getatoms(src, &count, &atoms);

    // atomarray_new with arguments creates a new array and copies the atoms from the source.
    t_atomarray *dest = atomarray_new(count, atoms);
    return dest;
}


// Comparison function for qsort
int compare_longs(const void *a, const void *b) {
    long la = *(const long *)a;
    long lb = *(const long *)b;
    return (la > lb) - (la < lb);
}

// Struct for holding note pairs for sorting
typedef struct { double timestamp; double score; } NotePair;

// Comparison function for qsort to sort NotePairs
int compare_notepairs(const void *a, const void *b) {
    NotePair *pa = (NotePair *)a;
    NotePair *pb = (NotePair *)b;
    if (pa->timestamp < pb->timestamp) return -1;
    if (pa->timestamp > pb->timestamp) return 1;
    return 0;
}

// Struct for holding note data for duplication manifest
typedef struct {
    long track_number;
    double timestamp;
    double score;
} t_duplication_manifest_item;

// Comparison function for qsort to sort t_duplication_manifest_item by timestamp
int compare_manifest_items(const void *a, const void *b) {
    t_duplication_manifest_item *pa = (t_duplication_manifest_item *)a;
    t_duplication_manifest_item *pb = (t_duplication_manifest_item *)b;
    if (pa->timestamp < pb->timestamp) return -1;
    if (pa->timestamp > pb->timestamp) return 1;
    return 0;
}


// Function prototypes
void *buildspans_new(t_symbol *s, long argc, t_atom *argv);
void buildspans_free(t_buildspans *x);
void buildspans_clear(t_buildspans *x);
void buildspans_do_clear(t_buildspans *x, t_symbol *s, long argc, t_atom *argv);
void buildspans_list(t_buildspans *x, t_symbol *s, long argc, t_atom *argv);
void buildspans_do_list(t_buildspans *x, t_symbol *s, long argc, t_atom *argv);
void buildspans_float(t_buildspans *x, double f);
void buildspans_offset(t_buildspans *x, double f);
void buildspans_do_offset(t_buildspans *x, double f, double loop_start, double most_negative_bar);
void buildspans_track(t_buildspans *x, long n);
void buildspans_track_deferred(t_buildspans *x, t_symbol *s, long argc, t_atom *argv);
void buildspans_offset_deferred(t_buildspans *x, t_symbol *s, long argc, t_atom *argv);
void buildspans_anything(t_buildspans *x, t_symbol *s, long argc, t_atom *argv);
void buildspans_do_anything(t_buildspans *x, t_symbol *s, long argc, t_atom *argv, long inlet_num);
void buildspans_anything_deferred(t_buildspans *x, t_symbol *s, long argc, t_atom *argv);
void buildspans_assist(t_buildspans *x, void *b, long m, long a, char *s);
void buildspans_bang(t_buildspans *x);
void buildspans_do_bang(t_buildspans *x, t_symbol *s, long argc, t_atom *argv);
void buildspans_flush(t_buildspans *x, t_symbol *palette_sym);
void buildspans_flush_track(t_buildspans *x, long track_num);
void buildspans_run_cleanup(t_buildspans *x);
void buildspans_end_track_span(t_buildspans *x, t_symbol *palette_sym, t_symbol *track_sym);
void buildspans_prune_span(t_buildspans *x, t_symbol *palette_sym, t_symbol *track_sym, long bar_to_keep);
void buildspans_visualize_memory(t_buildspans *x);
void buildspans_log(t_buildspans *x, const char *fmt, ...);
void buildspans_reset_bar_to_standalone(t_buildspans *x, t_symbol *palette_sym, t_symbol *track_sym, t_symbol *bar_sym);
void buildspans_finalize_and_log_span(t_buildspans *x, t_symbol *palette_sym, t_symbol *track_sym, t_atomarray *span_array);
int buildspans_deferred_rating_check(t_buildspans *x, t_symbol *palette_sym, t_symbol *track_sym, long last_bar_timestamp);
double buildspans_calc_looped_absolute(t_buildspans *x, double raw_absolute);
void buildspans_process_and_add_note(t_buildspans *x, double looped_absolute, double store_timestamp, double score, double raw_offset, double stored_offset, long bar_length);
void buildspans_check_discontiguity(t_buildspans *x, t_symbol *palette_sym, t_symbol *track_sym, double relative_comparison_val);
void buildspans_cleanup_track_offset_if_needed(t_buildspans *x, t_symbol *palette_sym, t_symbol *track_offset_sym);
double find_next_offset(t_buildspans *x, t_symbol *palette_sym, long track_num_to_check, double offset_val_to_check);
int buildspans_validate_span_before_output(t_buildspans *x, t_symbol *palette_sym, t_symbol *track_sym, t_atomarray *span_to_output);
void buildspans_output_span_data(t_buildspans *x, t_symbol *palette_sym, t_symbol *track_sym, t_atomarray *span_atom_array);
long buildspans_get_bar_length(t_buildspans *x);
void buildspans_set_bar_buffer(t_buildspans *x, t_symbol *s);
void buildspans_local_bar_length(t_buildspans *x, double f);
void buildspans_do_local_bar_length(t_buildspans *x, t_symbol *s, long argc, t_atom *argv);
void buildspans_bind_resolve(t_buildspans *x);
void buildspans_bind_clock_cb(t_buildspans *x);
void buildspans_notify(t_buildspans *x, t_symbol *s, t_symbol *msg, void *sender, void *data);
t_max_err buildspans_attr_set_log(t_buildspans *x, void *attr, long ac, t_atom *av);
t_max_err buildspans_attr_set_async(t_buildspans *x, void *attr, long ac, t_atom *av);
t_max_err buildspans_attr_set_visualize(t_buildspans *x, void *attr, long ac, t_atom *av);
t_max_err buildspans_attr_set_bind(t_buildspans *x, void *attr, long ac, t_atom *av);


// Helper function to send verbose log messages
void buildspans_enqueue_task(t_buildspans *x, method m, t_symbol *s, long argc, t_atom *argv) {
    if (!x->worker) return;
    systhread_mutex_lock(x->sequence_mutex);
    long seq = x->enqueue_sequence++;
    linklist_append(x->pending_sequences, (void *)(intptr_t)seq);
    systhread_mutex_unlock(x->sequence_mutex);
    async_worker_enqueue(x->worker, x, m, s, argc, argv);
}

long buildspans_get_task_sequence(t_buildspans *x) {
    long seq = -1;
    if (x->async && x->worker && async_worker_is_worker_thread(x->worker)) {
        systhread_mutex_lock(x->sequence_mutex);
        if (linklist_getsize(x->pending_sequences) > 0) {
            seq = (long)(intptr_t)linklist_getindex(x->pending_sequences, 0);
            linklist_chuckindex(x->pending_sequences, 0);
        }
        systhread_mutex_unlock(x->sequence_mutex);
    }
    return seq;
}

int buildspans_is_task_cancelled(t_buildspans *x, long seq) {
    if (seq != -1) {
        int cancelled = 0;
        systhread_mutex_lock(x->sequence_mutex);
        if (seq < x->last_clear_sequence) {
            cancelled = 1;
        }
        systhread_mutex_unlock(x->sequence_mutex);
        return cancelled;
    }
    return 0;
}

void buildspans_defer_output(t_buildspans *x, t_symbol *s, short argc, t_atom *argv) {
    if (s == gensym("track")) {
        outlet_anything(x->track_outlet, s, argc, argv);
    } else if (s == gensym("span")) {
        outlet_anything(x->span_outlet, s, argc, argv);
    } else if (s == gensym("bar_data")) {
        // Here argv[0] was the selector
        t_symbol *sel = atom_getsym(argv);
        outlet_anything(x->out_bar_data, sel, (short)(argc - 1), argv + 1);
    } else if (s == gensym("span_int")) {
        if (argc > 0) {
            outlet_int(x->span_outlet, atom_getlong(argv));
        }
    }
}

#define MAX_LOG_HISTORY_LINES 2000
#define MAX_LOG_LINE_LEN 512

void record_log_message(t_buildspans *x, const char *message) {
    critical_enter(0);
    if (!x->log_history) {
        x->log_history = (char **)sysmem_newptr(MAX_LOG_HISTORY_LINES * sizeof(char *));
        for (int i = 0; i < MAX_LOG_HISTORY_LINES; i++) {
            x->log_history[i] = (char *)sysmem_newptr(MAX_LOG_LINE_LEN);
            x->log_history[i][0] = '\0';
        }
        x->log_history_count = 0;
        x->log_history_write_ptr = 0;
    }

    strncpy(x->log_history[x->log_history_write_ptr], message, MAX_LOG_LINE_LEN - 1);
    x->log_history[x->log_history_write_ptr][MAX_LOG_LINE_LEN - 1] = '\0';

    x->log_history_write_ptr = (x->log_history_write_ptr + 1) % MAX_LOG_HISTORY_LINES;
    if (x->log_history_count < MAX_LOG_HISTORY_LINES) {
        x->log_history_count++;
    }
    critical_exit(0);
}

void get_object_directory(char *dir_out, size_t max_len) {
#if defined(WIN_VERSION) || defined(_WIN32)
    HMODULE hModule = NULL;
    if (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                           (LPCSTR)get_object_directory, &hModule)) {
        char path[MAX_PATH_CHARS];
        DWORD len = GetModuleFileNameA(hModule, path, MAX_PATH_CHARS);
        if (len > 0 && len < MAX_PATH_CHARS) {
            char *last_sep = strrchr(path, '\\');
            if (!last_sep) {
                last_sep = strrchr(path, '/');
            }
            if (last_sep) {
                *last_sep = '\0';
                strncpy(dir_out, path, max_len);
                dir_out[max_len - 1] = '\0';
                return;
            }
        }
    }
#else
    Dl_info info;
    if (dladdr((const void *)get_object_directory, &info) && info.dli_fname) {
        char path[MAX_PATH_CHARS];
        strncpy(path, info.dli_fname, MAX_PATH_CHARS - 1);
        path[MAX_PATH_CHARS - 1] = '\0';
        char *last_sep = strrchr(path, '/');
        if (last_sep) {
            *last_sep = '\0';
            strncpy(dir_out, path, max_len);
            dir_out[max_len - 1] = '\0';
            return;
        }
    }
#endif
    strncpy(dir_out, ".", max_len);
    dir_out[max_len - 1] = '\0';
}

void write_multibar_negative_rating_log(t_buildspans *x, t_symbol *palette_sym, t_symbol *track_sym, t_atomarray *span_array, double rating) {
    long span_size = 0;
    t_atom *span_atoms = NULL;
    atomarray_getatoms(span_array, &span_size, &span_atoms);
    if (span_size < 3 || rating >= 0.0) {
        return; // Criteria not met
    }

    char obj_dir[MAX_PATH_CHARS];
    get_object_directory(obj_dir, MAX_PATH_CHARS);

    char logs_dir[MAX_PATH_CHARS];
#if defined(WIN_VERSION) || defined(_WIN32)
    snprintf(logs_dir, MAX_PATH_CHARS, "%s\\logs", obj_dir);
    CreateDirectoryA(logs_dir, NULL);
#else
    snprintf(logs_dir, MAX_PATH_CHARS, "%s/logs", obj_dir);
    mkdir(logs_dir, 0777);
#endif

    struct tm tm_info;
    int ms = 0;
    char datetime_str[64];
#if defined(WIN_VERSION) || defined(_WIN32)
    SYSTEMTIME st;
    GetLocalTime(&st);
    tm_info.tm_year = st.wYear - 1900;
    tm_info.tm_mon = st.wMonth - 1;
    tm_info.tm_mday = st.wDay;
    tm_info.tm_hour = st.wHour;
    tm_info.tm_min = st.wMinute;
    tm_info.tm_sec = st.wSecond;
    ms = st.wMilliseconds;
#else
    struct timeval tv;
    gettimeofday(&tv, NULL);
    time_t t = tv.tv_sec;
    struct tm *local = localtime(&t);
    if (local) {
        tm_info = *local;
    } else {
        memset(&tm_info, 0, sizeof(struct tm));
    }
    ms = tv.tv_usec / 1000;
#endif

    snprintf(datetime_str, sizeof(datetime_str), "%04d%02d%02d_%02d%02d%02d_%03d",
             tm_info.tm_year + 1900, tm_info.tm_mon + 1, tm_info.tm_mday,
             tm_info.tm_hour, tm_info.tm_min, tm_info.tm_sec, ms);

    char file_path[MAX_PATH_CHARS];
#if defined(WIN_VERSION) || defined(_WIN32)
    snprintf(file_path, MAX_PATH_CHARS, "%s\\multibar_negative_rating_%s.txt", logs_dir, datetime_str);
#else
    snprintf(file_path, MAX_PATH_CHARS, "%s/multibar_negative_rating_%s.txt", logs_dir, datetime_str);
#endif

    FILE *f = fopen(file_path, "w");
    if (!f) {
        object_error((t_object *)x, "Failed to create log file: %s", file_path);
        return;
    }

    fprintf(f, "================================================================================\n");
    fprintf(f, "MULTIBAR NEGATIVE RATING SPAN LOG\n");
    fprintf(f, "================================================================================\n");
    fprintf(f, "Timestamp:       %04d-%02d-%02d %02d:%02d:%02d.%03d\n",
            tm_info.tm_year + 1900, tm_info.tm_mon + 1, tm_info.tm_mday,
            tm_info.tm_hour, tm_info.tm_min, tm_info.tm_sec, ms);
    fprintf(f, "Instance ID:     %ld\n", x->instance_id);
    fprintf(f, "Palette:         %s\n", palette_sym ? palette_sym->s_name : "N/A");
    fprintf(f, "Track Symbol:    %s\n", track_sym ? track_sym->s_name : "N/A");
    fprintf(f, "Span Rating:     %.4f\n", rating);
    fprintf(f, "Number of Bars:  %ld\n", span_size);
    fprintf(f, "Current Offset:  %.2f\n", x->current_offset);
    fprintf(f, "Loop Start:      %.2f\n", x->loop_start);
    fprintf(f, "Bar Length:      %.2f (ms)\n", x->local_bar_length);
    fprintf(f, "================================================================================\n\n");

    fprintf(f, "SPAN STRUCTURE DETAILS:\n");
    fprintf(f, "--------------------------------------------------------------------------------\n");
    for (long i = 0; i < span_size; i++) {
        long bar_ts = atom_getlong(&span_atoms[i]);
        fprintf(f, "Bar %ld:\n", bar_ts);
        char bar_str[32]; snprintf(bar_str, 32, "%ld", bar_ts);
        t_symbol *bar_sym = gensym(bar_str);

        // Get offset
        t_symbol *offset_key = generate_hierarchical_key(palette_sym, track_sym, bar_sym, gensym("offset"));
        t_atom offset_atom;
        if (dictionary_getatom(x->building, offset_key, &offset_atom) == MAX_ERR_NONE) {
            fprintf(f, "  - Offset: %.2f\n", atom_getfloat(&offset_atom));
        }

        // Get mean
        t_symbol *mean_key = generate_hierarchical_key(palette_sym, track_sym, bar_sym, gensym("mean"));
        t_atom mean_atom;
        if (dictionary_getatom(x->building, mean_key, &mean_atom) == MAX_ERR_NONE) {
            fprintf(f, "  - Mean score: %.4f\n", atom_getfloat(&mean_atom));
        }

        // Get rating
        t_symbol *rating_key = generate_hierarchical_key(palette_sym, track_sym, bar_sym, gensym("rating"));
        t_atom rating_atom;
        if (dictionary_getatom(x->building, rating_key, &rating_atom) == MAX_ERR_NONE) {
            fprintf(f, "  - Bar-level Rating: %.4f\n", atom_getfloat(&rating_atom));
        }

        // Get absolutes (notes that went into it)
        t_symbol *absolutes_key = generate_hierarchical_key(palette_sym, track_sym, bar_sym, gensym("absolutes"));
        t_atomarray *abs_aa = NULL;
        t_atom abs_atom;
        long abs_count = 0;
        t_atom *abs_atoms = NULL;
        if (dictionary_getatomarray(x->building, absolutes_key, (t_object **)&abs_aa) == MAX_ERR_NONE && abs_aa) {
            atomarray_getatoms(abs_aa, &abs_count, &abs_atoms);
        } else if (dictionary_getatom(x->building, absolutes_key, &abs_atom) == MAX_ERR_NONE) {
            abs_atoms = &abs_atom;
            abs_count = 1;
        }
        if (abs_count > 0) {
            fprintf(f, "  - Note Timestamps (Absolutes): [");
            for (long k = 0; k < abs_count; k++) {
                fprintf(f, "%.2f%s", atom_getfloat(abs_atoms + k), (k < abs_count - 1) ? ", " : "");
            }
            fprintf(f, "]\n");
        }

        // Get scores
        t_symbol *scores_key = generate_hierarchical_key(palette_sym, track_sym, bar_sym, gensym("scores"));
        t_atomarray *scores_aa = NULL;
        t_atom scores_atom;
        long scores_count = 0;
        t_atom *scores_atoms = NULL;
        if (dictionary_getatomarray(x->building, scores_key, (t_object **)&scores_aa) == MAX_ERR_NONE && scores_aa) {
            atomarray_getatoms(scores_aa, &scores_count, &scores_atoms);
        } else if (dictionary_getatom(x->building, scores_key, &scores_atom) == MAX_ERR_NONE) {
            scores_atoms = &scores_atom;
            scores_count = 1;
        }
        if (scores_count > 0) {
            fprintf(f, "  - Note Scores: [");
            for (long k = 0; k < scores_count; k++) {
                fprintf(f, "%.4f%s", atom_getfloat(scores_atoms + k), (k < scores_count - 1) ? ", " : "");
            }
            fprintf(f, "]\n");
        }
        fprintf(f, "\n");
    }

    fprintf(f, "EVENT LOG HISTORY (DECISIONS, CHECKS, ETC.):\n");
    fprintf(f, "--------------------------------------------------------------------------------\n");
    critical_enter(0);
    if (x->log_history && x->log_history_count > 0) {
        long start_idx = 0;
        if (x->log_history_count == MAX_LOG_HISTORY_LINES) {
            start_idx = x->log_history_write_ptr;
        }
        for (long i = 0; i < x->log_history_count; i++) {
            long idx = (start_idx + i) % MAX_LOG_HISTORY_LINES;
            if (x->log_history[idx] && x->log_history[idx][0] != '\0') {
                fprintf(f, "%s\n", x->log_history[idx]);
            }
        }
    } else {
        fprintf(f, "[No log history recorded]\n");
    }
    critical_exit(0);

    fclose(f);
    object_post((t_object *)x, "Created log file for multibar negative rating span: %s", file_path);
}

void buildspans_log(t_buildspans *x, const char *fmt, ...) {
    char buf[4096];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);

    // Record the log message in our history buffer
    record_log_message(x, buf);

    // Output using common_log
    common_log(x->log_outlet, x->log, "buildspans", "%s", buf);
}

#ifndef REBAR_INTERNAL_BINDING
t_class *buildspans_class;
#endif

// A single, consolidated function to get the bar length from the buffer.
// It returns -1 on any failure (buffer not set, not found, empty, or value <= 0).
// It does not post any messages to the console. The caller is responsible for that.
long buildspans_get_bar_length(t_buildspans *x) {
    if (x->local_bar_length > 0) {
        return (long)x->local_bar_length;
    }
    if (!x->buffer_ref) {
        return -1; // Buffer name not set.
    }

    t_buffer_obj *b = buffer_ref_getobject(x->buffer_ref);
    if (!b) {
        if (!x->bar_warn_sent) {
            object_warn((t_object *)x, "bar buffer~ not found, attempting to kick reference");
            x->bar_warn_sent = 1;
        }
        // Kick the buffer reference to force re-binding
        buffer_ref_set(x->buffer_ref, _sym_nothing);
        buffer_ref_set(x->buffer_ref, (x->s_buffer_name && x->s_buffer_name != _sym_nothing) ? x->s_buffer_name : gensym("bar"));
        b = buffer_ref_getobject(x->buffer_ref);
    }
    if (!b) {
        return -1; // Buffer object not found.
    }
    x->bar_warn_sent = 0; // Reset flag when buffer is successfully found

    long bar_length = 0;
    critical_enter(0);
    float *samples = buffer_locksamples(b);
    if (samples) {
        if (buffer_getframecount(b) > 0) {
            bar_length = (long)samples[0];
        }
        buffer_unlocksamples(b);
        critical_exit(0);
    } else {
        critical_exit(0);
    }

    if (bar_length <= 0) {
        return -1; // Value in buffer is not positive.
    }

    if (bar_length != (long)x->local_bar_length) {
        buildspans_log(x, "bar_length changed to %ld", bar_length);
        buildspans_log(x, "Retrieved bar length %ld from buffer and cached it.", bar_length);
    }
    x->local_bar_length = (double)bar_length; // Cache retrieved bar length

    return bar_length;
}

void buildspans_visualize_memory(t_buildspans *x) {
    if (!x->visualize) return;
    long num_keys;
    t_symbol **keys;
    dictionary_getkeys(x->building, &num_keys, &keys);

    // 1. Identify all unique palettes
    long unique_palette_count = 0;
    t_symbol **unique_palettes = (t_symbol **)sysmem_newptr(num_keys * sizeof(t_symbol *));
    if (keys) {
        for (long i = 0; i < num_keys; i++) {
            char *pal_str, *track_str, *bar_str, *prop_str;
            if (parse_hierarchical_key(keys[i], &pal_str, &track_str, &bar_str, &prop_str)) {
                int found = 0;
                for (long j = 0; j < unique_palette_count; j++) {
                    if (strcmp(unique_palettes[j]->s_name, pal_str) == 0) {
                        found = 1;
                        break;
                    }
                }
                if (!found) {
                    unique_palettes[unique_palette_count++] = gensym(pal_str);
                }
                sysmem_freeptr(pal_str);
                sysmem_freeptr(track_str);
                sysmem_freeptr(bar_str);
                sysmem_freeptr(prop_str);
            }
        }
    }

    // 2. Generate JSON
    long buffer_size = 262144;
    char *json_buffer = (char *)sysmem_newptr(buffer_size);
    long offset = 0;
    offset += snprintf(json_buffer + offset, buffer_size, "{\"palettes\":{");

    for (long p = 0; p < unique_palette_count; p++) {
        t_symbol *palette_sym = unique_palettes[p];
        if (p > 0) offset += snprintf(json_buffer + offset, buffer_size - offset, ",");

        // Identify unique tracks for this palette
        long unique_track_count = 0;
        t_symbol **unique_tracks = (t_symbol **)sysmem_newptr(num_keys * sizeof(t_symbol *));
        if (keys) {
            for (long i = 0; i < num_keys; i++) {
                char *pal_str, *track_str, *bar_str, *prop_str;
                if (parse_hierarchical_key(keys[i], &pal_str, &track_str, &bar_str, &prop_str)) {
                    if (strcmp(pal_str, palette_sym->s_name) == 0) {
                        int found = 0;
                        for (long j = 0; j < unique_track_count; j++) {
                            if (strcmp(unique_tracks[j]->s_name, track_str) == 0) {
                                found = 1;
                                break;
                            }
                        }
                        if (!found) {
                            unique_tracks[unique_track_count++] = gensym(track_str);
                        }
                    }
                    sysmem_freeptr(pal_str);
                    sysmem_freeptr(track_str);
                    sysmem_freeptr(bar_str);
                    sysmem_freeptr(prop_str);
                }
            }
        }

        offset += snprintf(json_buffer + offset, buffer_size - offset, "\"%s\":{\"building\":{", 
                            palette_sym->s_name);

        for (long i = 0; i < unique_track_count; i++) {
            t_symbol *track_sym = unique_tracks[i];
            if (i > 0) offset += snprintf(json_buffer + offset, buffer_size - offset, ",");
            
            offset += snprintf(json_buffer + offset, buffer_size - offset, "\"%s\":{\"absolutes\":[", track_sym->s_name);

            // a. Find and sort bars for this track
            long bar_count = 0;
            long *bar_timestamps = (long *)sysmem_newptr(num_keys * sizeof(long)); // Over-allocate
            if (keys) {
                for (long j = 0; j < num_keys; j++) {
                     char *pal_str, *track_str, *bar_str, *prop_str;
                     if (parse_hierarchical_key(keys[j], &pal_str, &track_str, &bar_str, &prop_str)) {
                         if (strcmp(pal_str, palette_sym->s_name) == 0 && strcmp(track_str, track_sym->s_name) == 0 && strcmp(prop_str, "mean") == 0) {
                             bar_timestamps[bar_count++] = atol(bar_str);
                         }
                         sysmem_freeptr(pal_str);
                         sysmem_freeptr(track_str);
                         sysmem_freeptr(bar_str);
                         sysmem_freeptr(prop_str);
                     }
                }
            }
            qsort(bar_timestamps, bar_count, sizeof(long), compare_longs);

            // b. Append absolutes
            int first_absolute = 1;
            for (long j = 0; j < bar_count; j++) {
                char bar_str[32]; snprintf(bar_str, 32, "%ld", bar_timestamps[j]);
                t_symbol* abs_key = generate_hierarchical_key(palette_sym, track_sym, gensym(bar_str), gensym("absolutes"));
                t_atom *av;
                long ac = 0;
                t_atomarray *aa = NULL;
                t_atom a;
                if (dictionary_getatomarray(x->building, abs_key, (t_object **)&aa) == MAX_ERR_NONE && aa) {
                    atomarray_getatoms(aa, &ac, &av);
                } else if (dictionary_getatom(x->building, abs_key, &a) == MAX_ERR_NONE) {
                    av = &a;
                    ac = 1;
                }
                for (long k = 0; k < ac; k++) {
                    if (!first_absolute) offset += snprintf(json_buffer + offset, buffer_size - offset, ",");
                    first_absolute = 0;
                    offset += snprintf(json_buffer + offset, buffer_size - offset, "%.2f", atom_getfloat(av+k));
                }
            }

            // b2. Append scores aligned with absolutes
            offset += snprintf(json_buffer + offset, buffer_size - offset, "],\"scores\":[");
            int first_score = 1;
            for (long j = 0; j < bar_count; j++) {
                char bar_str[32]; snprintf(bar_str, 32, "%ld", bar_timestamps[j]);
                t_symbol* scores_key = generate_hierarchical_key(palette_sym, track_sym, gensym(bar_str), gensym("scores"));
                t_atom *av;
                long ac = 0;
                t_atomarray *aa = NULL;
                t_atom a;
                if (dictionary_getatomarray(x->building, scores_key, (t_object **)&aa) == MAX_ERR_NONE && aa) {
                    atomarray_getatoms(aa, &ac, &av);
                } else if (dictionary_getatom(x->building, scores_key, &a) == MAX_ERR_NONE) {
                    av = &a;
                    ac = 1;
                }
                for (long k = 0; k < ac; k++) {
                    if (!first_score) offset += snprintf(json_buffer + offset, buffer_size - offset, ",");
                    first_score = 0;
                    offset += snprintf(json_buffer + offset, buffer_size - offset, "%.4f", atom_getfloat(av+k));
                }
            }

            offset += snprintf(json_buffer + offset, buffer_size - offset, "],\"offsets\":[");

            // c. Append offsets
            int first_offset = 1;
            for (long j = 0; j < bar_count; j++) {
                char bar_str[32]; snprintf(bar_str, 32, "%ld", bar_timestamps[j]);
                t_symbol* offset_key = generate_hierarchical_key(palette_sym, track_sym, gensym(bar_str), gensym("offset"));
                 if (dictionary_hasentry(x->building, offset_key)) {
                     if (!first_offset) offset += snprintf(json_buffer + offset, buffer_size - offset, ",");
                     first_offset = 0;
                     t_atom a;
                     dictionary_getatom(x->building, offset_key, &a);
                     offset += snprintf(json_buffer + offset, buffer_size - offset, "%.2f", atom_getfloat(&a));
                 }
            }

            // c2. Append ratings dictionary
            offset += snprintf(json_buffer + offset, buffer_size - offset, "],\"ratings\":{");
            int first_rating = 1;
            for (long j = 0; j < bar_count; j++) {
                char bar_str[32]; snprintf(bar_str, 32, "%ld", bar_timestamps[j]);
                t_symbol* rating_key = generate_hierarchical_key(palette_sym, track_sym, gensym(bar_str), gensym("rating"));
                if (dictionary_hasentry(x->building, rating_key)) {
                    t_atom a;
                    dictionary_getatom(x->building, rating_key, &a);
                    if (!first_rating) offset += snprintf(json_buffer + offset, buffer_size - offset, ",");
                    first_rating = 0;
                    offset += snprintf(json_buffer + offset, buffer_size - offset, "\"%ld\":%.4f", bar_timestamps[j], atom_getfloat(&a));
                }
            }

            offset += snprintf(json_buffer + offset, buffer_size - offset, "},\"span\":[");

            // d. Append span data
            int first_span = 1;
            // To avoid duplicates, find a representative span from the first bar
            if (bar_count > 0) {
                char first_bar_str[32];
                snprintf(first_bar_str, 32, "%ld", bar_timestamps[0]);
                t_symbol *span_key = generate_hierarchical_key(palette_sym, track_sym, gensym(first_bar_str), gensym("span"));

                t_atom *span_atoms;
                long span_count = 0;
                t_atomarray *span_aa = NULL;
                t_atom span_atom;
                if (dictionary_getatomarray(x->building, span_key, (t_object **)&span_aa) == MAX_ERR_NONE && span_aa) {
                    atomarray_getatoms(span_aa, &span_count, &span_atoms);
                } else if (dictionary_getatom(x->building, span_key, &span_atom) == MAX_ERR_NONE) {
                    span_atoms = &span_atom;
                    span_count = 1;
                }

                for (long k = 0; k < span_count; k++) {
                    if (!first_span) {
                        offset += snprintf(json_buffer + offset, buffer_size - offset, ",");
                    }
                    first_span = 0;
                    offset += snprintf(json_buffer + offset, buffer_size - offset, "%ld", atom_getlong(span_atoms + k));
                }
            }

            offset += snprintf(json_buffer + offset, buffer_size - offset, "]}");
            sysmem_freeptr(bar_timestamps);
        }
        offset += snprintf(json_buffer + offset, buffer_size - offset, "}}");
        sysmem_freeptr(unique_tracks);
    }
    long bar_length = buildspans_get_bar_length(x);
    offset += snprintf(json_buffer + offset, buffer_size - offset, "},\"current_offset\":%.2f,\"bar_length\":%ld,\"loop_start\":%.2f}", x->current_offset, bar_length, x->loop_start);

    visualize((t_object *)x, json_buffer);

    sysmem_freeptr(json_buffer);
    sysmem_freeptr(unique_palettes);
    if(keys) sysmem_freeptr(keys);
}


void ext_main(void *r) {
    t_class *c;

    common_symbols_init();

    c = class_new("buildspans", (method)buildspans_new, (method)buildspans_free, sizeof(t_buildspans), 0L, A_GIMME, 0);
    class_addmethod(c, (method)buildspans_clear, "clear", 0);
    class_addmethod(c, (method)buildspans_list, "list", A_GIMME, 0);
    class_addmethod(c, (method)buildspans_float, "float", A_FLOAT, 0);
    class_addmethod(c, (method)buildspans_offset, "ft1", A_FLOAT, 0);
    class_addmethod(c, (method)buildspans_track, "in2", A_LONG, 0);
    class_addmethod(c, (method)buildspans_anything, "anything", A_GIMME, 0);
    class_addmethod(c, (method)buildspans_assist, "assist", A_CANT, 0);
    class_addmethod(c, (method)buildspans_bang, "bang", 0);
    class_addmethod(c, (method)buildspans_set_bar_buffer, "set_bar_buffer", A_SYM, 0);
    class_addmethod(c, (method)buildspans_local_bar_length, "ft4", A_FLOAT, 0);
    class_addmethod(c, (method)buildspans_notify, "notify", A_CANT, 0);
    
    CLASS_ATTR_SYM(c, "bind", 0, t_buildspans, bind_name);
    CLASS_ATTR_LABEL(c, "bind", 0, "Bind to Crucible Name");
    CLASS_ATTR_ACCESSORS(c, "bind", NULL, (method)buildspans_attr_set_bind);

    CLASS_ATTR_LONG(c, "log", 0, t_buildspans, log);
    CLASS_ATTR_STYLE_LABEL(c, "log", 0, "onoff", "Enable Logging");
    CLASS_ATTR_DEFAULT(c, "log", 0, "0");
    CLASS_ATTR_ACCESSORS(c, "log", NULL, (method)buildspans_attr_set_log);

    CLASS_ATTR_LONG(c, "visualize", 0, t_buildspans, visualize);
    CLASS_ATTR_STYLE_LABEL(c, "visualize", 0, "onoff", "Enable Visualization");
    CLASS_ATTR_DEFAULT(c, "visualize", 0, "0");
    CLASS_ATTR_ACCESSORS(c, "visualize", NULL, (method)buildspans_attr_set_visualize);

    CLASS_ATTR_LONG(c, "defer", 0, t_buildspans, defer);
    CLASS_ATTR_STYLE_LABEL(c, "defer", 0, "onoff", "Deferred Execution");
    CLASS_ATTR_DEFAULT(c, "defer", 0, "0");

    CLASS_ATTR_LONG(c, "async", 0, t_buildspans, async);
    CLASS_ATTR_STYLE_LABEL(c, "async", 0, "onoff", "Asynchronous Execution");
    CLASS_ATTR_DEFAULT(c, "async", 0, "0");
    CLASS_ATTR_ACCESSORS(c, "async", NULL, (method)buildspans_attr_set_async);

    class_register(CLASS_BOX, c);
    buildspans_class = c;
}

void *buildspans_new(t_symbol *s, long argc, t_atom *argv) {
    t_buildspans *x = (t_buildspans *)object_alloc(buildspans_class);
    if (x) {
        x->building = dictionary_new();
        x->tracks_ended_in_current_event = dictionary_new();

        systhread_mutex_new(&x->sequence_mutex, 0);
        systhread_mutex_new(&x->state_mutex, 0);
        x->pending_sequences = linklist_new();
        x->enqueue_sequence = 0;
        x->last_clear_sequence = 0;
        x->current_task_seq = -1;
        x->current_track = 0;
        x->current_offset = 0.0;
        x->raw_offset = 0.0;
        x->loop_start = 0.0;
        x->most_negative_bar = 0.0;
        x->current_palette = gensym("");
        x->log_outlet = NULL;
        x->log = 0;
        x->visualize = 0;
        x->defer = 0;
        x->async = 0;
        x->worker = NULL;
        x->buffer_ref = NULL;
        x->s_buffer_name = NULL;
        x->local_bar_length = 0;
        x->instance_id = 1000 + (rand() % 9000);
        x->bar_warn_sent = 0;
        x->last_msg_type = gensym("none");
        x->last_note_calc = 0.0;
        x->last_note_store = 0.0;
        x->last_note_score = 0.0;
        x->bind_name = _sym_nothing;
        x->bound_crucible = NULL;
        x->bind_clock = clock_new(x, (method)buildspans_bind_clock_cb);
        x->bind_attempt_count = 0;

        x->log_history = NULL;
        x->log_history_count = 0;
        x->log_history_write_ptr = 0;

        // Process attributes before creating outlets
        attr_args_process(x, argc, argv);

        // Hardcode the default buffer name to "bar".
        buildspans_set_bar_buffer(x, gensym("bar"));

        // Inlets are created from right to left.
        floatin((t_object *)x, 4);  // Local bar length
        proxy_new((t_object *)x, 3, NULL); // Palette
        intin((t_object *)x, 2);    // Track Number
        proxy_new((t_object *)x, 1, NULL);  // Offset / Loop Start

        // Outlets are created from right to left
        x->log_outlet = outlet_new((t_object *)x, NULL);
        visualize_init();
        x->out_bar_data = outlet_new((t_object *)x, NULL); // Generic outlet for logs
        x->track_outlet = outlet_new((t_object *)x, NULL);
        x->span_outlet = outlet_new((t_object *)x, NULL);
    }
    return (x);
}

void buildspans_free(t_buildspans *x) {
    visualize_cleanup();
    if (x->pending_sequences) {
        linklist_chuck(x->pending_sequences);
    }
    systhread_mutex_free(x->sequence_mutex);
    systhread_mutex_free(x->state_mutex);
    if (x->worker) {
        async_worker_release(x->worker);
    }
    if (x->bind_clock) {
        object_free(x->bind_clock);
    }
    if (x->bound_crucible) {
        object_detach_byptr(x, x->bound_crucible);
    }
    if (x->building) {
        object_free(x->building);
    }
    if (x->tracks_ended_in_current_event) {
        object_free(x->tracks_ended_in_current_event);
    }
    if (x->buffer_ref) {
        object_free(x->buffer_ref);
    }
    if (x->log_history) {
        for (int i = 0; i < MAX_LOG_HISTORY_LINES; i++) {
            sysmem_freeptr(x->log_history[i]);
        }
        sysmem_freeptr(x->log_history);
    }
}

void buildspans_clear(t_buildspans *x) {
    systhread_mutex_lock(x->sequence_mutex);
    x->last_clear_sequence = x->enqueue_sequence;
    while (linklist_getsize(x->pending_sequences) > 0) {
        linklist_chuckindex(x->pending_sequences, 0);
    }
    systhread_mutex_unlock(x->sequence_mutex);

    if (x->worker) {
        async_worker_clear_queue(x->worker);
    }

    systhread_mutex_lock(x->state_mutex);
    buildspans_do_clear(x, NULL, 0, NULL);
    systhread_mutex_unlock(x->state_mutex);
}

void buildspans_do_clear(t_buildspans *x, t_symbol *s, long argc, t_atom *argv) {
    if (x->building) {
        object_free(x->building);
    }
    if (x->tracks_ended_in_current_event) {
        object_free(x->tracks_ended_in_current_event);
    }
    x->building = dictionary_new();
    x->tracks_ended_in_current_event = dictionary_new();
    x->current_track = 0;
    x->current_offset = 0.0;
    x->raw_offset = 0.0;
    x->loop_start = 0.0;
    x->most_negative_bar = 0.0;
    x->current_palette = gensym("");
    x->local_bar_length = 0;
    x->last_msg_type = gensym("clear");
    buildspans_log(x, "Decision: CLEAR state. Outcome: Deleting all currently open spans across all tracks/palettes, and resetting all global parameters (current_offset reset to 0.0).");

    if (x->bound_crucible) {
        crucible_anything((t_crucible *)x->bound_crucible, gensym("clear"), argc, argv);
    }

    buildspans_visualize_memory(x);
}

// Handler for float messages on the 2nd inlet (proxy #1, offset)
void buildspans_offset_deferred(t_buildspans *x, t_symbol *s, long argc, t_atom *argv) {
    double f = (argc > 0) ? atom_getfloat(argv) : 0.0;
    double loop_start = (argc >= 2) ? atom_getfloat(argv + 1) : 0.0;
    double most_neg = (argc >= 3) ? atom_getfloat(argv + 2) : 0.0;
    buildspans_do_offset(x, f, loop_start, most_neg);
}

void buildspans_offset(t_buildspans *x, double f) {
    if (x->async && x->worker && !async_worker_is_worker_thread(x->worker)) {
        t_atom a;
        atom_setfloat(&a, f);
        buildspans_enqueue_task(x, (method)buildspans_offset_deferred, NULL, 1, &a);
        return;
    }
    if (x->defer && !systhread_ismainthread()) {
        t_atom a;
        atom_setfloat(&a, f);
        defer(x, (method)buildspans_offset_deferred, NULL, 1, &a);
        return;
    }
    buildspans_do_offset(x, f, 0.0, 0.0);
}

void buildspans_do_offset(t_buildspans *x, double f, double loop_start, double most_negative_bar) {
    long seq = buildspans_get_task_sequence(x);
    x->current_task_seq = seq;
    int on_worker = (x->async && x->worker && async_worker_is_worker_thread(x->worker));
    if (on_worker) {
        systhread_mutex_lock(x->state_mutex);
    }
    if (buildspans_is_task_cancelled(x, seq)) {
        x->current_task_seq = -1;
        if (on_worker) {
            systhread_mutex_unlock(x->state_mutex);
        }
        return;
    }

    double clamped_most_neg = (most_negative_bar < 0.0) ? most_negative_bar : 0.0;
    x->most_negative_bar = clamped_most_neg;

    // raw_offset (f) is the absolute song timestamp when the offset was set.
    // stored_offset (f - loop_start) is the loop-relative offset stored in the transcript
    // key so downstream weaver~ can apply it directly to the loop-agnostic palette buffer.
    double stored_offset = f - loop_start;
    x->raw_offset = f;

    buildspans_log(x, "buildspans_do_offset received: raw_offset=%.2f, loop_start=%.2f, most_neg=%.2f -> stored_offset=%.2f", f, loop_start, clamped_most_neg, stored_offset);

    long bar_length = buildspans_get_bar_length(x);
    buildspans_log(x, "buildspans_do_offset: utilizing bar_length %ld", bar_length);

    long new_rounded_offset = (long)round(stored_offset);
    long old_rounded_offset = (long)round(x->current_offset);

    if (new_rounded_offset == old_rounded_offset) {
        x->current_offset = stored_offset;
        x->raw_offset = f;
        x->loop_start = loop_start;
        x->most_negative_bar = clamped_most_neg;
        buildspans_log(x, "Global offset updated to: %.2f (stored: %.2f, loop_start: %.2f, most_neg: %.2f). No duplication (rounded offset unchanged).", f, stored_offset, loop_start, clamped_most_neg);
        x->current_task_seq = -1;
        if (on_worker) {
            systhread_mutex_unlock(x->state_mutex);
        }
        return;
    }

    // Proceed with duplication
    double old_offset = x->current_offset;
    x->current_offset = stored_offset;
    x->raw_offset = f;
    x->loop_start = loop_start;
    x->most_negative_bar = clamped_most_neg;
    x->last_msg_type = gensym("offset");
    buildspans_log(x, "Global offset updated to: %.2f (rounded: %ld). Proceeding with duplication.", f, new_rounded_offset);

    // --- MODIFIED DISCONTIGUITY CHECK PHASE ---
    // Conduct a modified discontiguity check for every track across every palette BEFORE duplication.
    long num_keys_check;
    t_symbol **keys_check;
    dictionary_getkeys(x->building, &num_keys_check, &keys_check);
    if (keys_check) {
        t_dictionary *unique_pal_tracks = dictionary_new();
        for (long i = 0; i < num_keys_check; i++) {
            char *pal_str, *track_str, *bar_str, *prop_str;
            if (parse_hierarchical_key(keys_check[i], &pal_str, &track_str, &bar_str, &prop_str)) {
                char combined[512];
                snprintf(combined, 512, "%s::%s", pal_str, track_str);
                t_symbol *combined_sym = gensym(combined);
                if (!dictionary_hasentry(unique_pal_tracks, combined_sym)) {
                    dictionary_appendsym(unique_pal_tracks, combined_sym, _sym_nothing);
                    const char *dash = strchr(track_str, '-');
                    if (dash) {
                        double track_offset = (double)atol(dash + 1);
                        double relative_f = f - track_offset + x->loop_start;
                        buildspans_check_discontiguity(x, gensym(pal_str), gensym(track_str), relative_f);
                    }
                }
                sysmem_freeptr(pal_str); sysmem_freeptr(track_str); sysmem_freeptr(bar_str); sysmem_freeptr(prop_str);
            }
        }
        object_free(unique_pal_tracks);
        sysmem_freeptr(keys_check);
        buildspans_run_cleanup(x);
    }

    buildspans_log(x, "Duplicating one span for each active track on palette %s.", x->current_palette->s_name);

    long num_keys;
    t_symbol **keys;
    dictionary_getkeys(x->building, &num_keys, &keys);
    if (!keys) {
        x->current_task_seq = -1;
        if (on_worker) {
            systhread_mutex_unlock(x->state_mutex);
        }
        return;
    }

    // --- GATHER PHASE ---
    buildspans_log(x, "Gathering notes for span duplication.");
    // First, we gather all the notes that need to be duplicated into a temporary "manifest".
    // This avoids modifying the `building` dictionary while iterating over its keys.
    long manifest_capacity = 128;
    long manifest_count = 0;
    t_duplication_manifest_item *manifest = (t_duplication_manifest_item *)sysmem_newptr(manifest_capacity * sizeof(t_duplication_manifest_item));

    // 1. Identify all unique track numbers (the integer part of the track-offset key)
    long unique_track_num_count = 0;
    long *unique_track_nums = (long *)sysmem_newptr(num_keys * sizeof(long)); // Over-allocate
    for (long i = 0; i < num_keys; i++) {
        char *pal_str, *track_str, *bar_str, *prop_str;
        if (parse_hierarchical_key(keys[i], &pal_str, &track_str, &bar_str, &prop_str)) {
            if (strcmp(pal_str, x->current_palette->s_name) == 0) {
                long current_track_num;
                if (sscanf(track_str, "%ld-", &current_track_num) == 1) {
                    int found = 0;
                    for (long j = 0; j < unique_track_num_count; j++) {
                        if (unique_track_nums[j] == current_track_num) {
                            found = 1;
                            break;
                        }
                    }
                    if (!found) {
                        unique_track_nums[unique_track_num_count++] = current_track_num;
                    }
                }
            }
            sysmem_freeptr(pal_str);
            sysmem_freeptr(track_str);
            sysmem_freeptr(bar_str);
            sysmem_freeptr(prop_str);
        }
    }

    // 2. For each unique track, find the source span matching old_rounded_offset and add its notes to the manifest.
    for (long i = 0; i < unique_track_num_count; i++) {
        long track_num_to_process = unique_track_nums[i];

        // Construct the expected target track-offset identifier and check if it already exists
        char target_track_str[64];
        snprintf(target_track_str, 64, "%ld-%ld", track_num_to_process, new_rounded_offset);
        t_symbol *target_track_sym = gensym(target_track_str);

        int target_exists = 0;
        for (long j = 0; j < num_keys; j++) {
            char *p_str, *t_str, *b_str, *pr_str;
            if (parse_hierarchical_key(keys[j], &p_str, &t_str, &b_str, &pr_str)) {
                if (strcmp(p_str, x->current_palette->s_name) == 0 && strcmp(t_str, target_track_sym->s_name) == 0) {
                    target_exists = 1;
                    sysmem_freeptr(p_str);
                    sysmem_freeptr(t_str);
                    sysmem_freeptr(b_str);
                    sysmem_freeptr(pr_str);
                    break;
                }
                sysmem_freeptr(p_str);
                sysmem_freeptr(t_str);
                sysmem_freeptr(b_str);
                sysmem_freeptr(pr_str);
            }
        }

        if (target_exists) {
            buildspans_log(x, "Target span %s already exists on palette %s. Skipping duplication for this track.", target_track_sym->s_name, x->current_palette->s_name);
            continue;
        }

        // Construct the expected source track-offset identifier
        char source_track_str[64];
        snprintf(source_track_str, 64, "%ld-%ld", track_num_to_process, old_rounded_offset);
        t_symbol *source_track_sym = gensym(source_track_str);

        // Now iterate through all keys to find notes belonging to the source span
        for (long j = 0; j < num_keys; j++) {
            char *pal_str, *track_str, *bar_str, *prop_str;
            if (parse_hierarchical_key(keys[j], &pal_str, &track_str, &bar_str, &prop_str)) {
                if (strcmp(pal_str, x->current_palette->s_name) == 0 && strcmp(track_str, source_track_sym->s_name) == 0 && strcmp(prop_str, "absolutes") == 0) {
                    t_atom *abs_atoms = NULL;
                    long abs_count = 0;
                    t_atomarray *abs_aa = NULL;
                    t_atom abs_atom;
                    if (dictionary_getatomarray(x->building, keys[j], (t_object **)&abs_aa) == MAX_ERR_NONE && abs_aa) {
                        atomarray_getatoms(abs_aa, &abs_count, &abs_atoms);
                    } else if (dictionary_getatom(x->building, keys[j], &abs_atom) == MAX_ERR_NONE) {
                        abs_atoms = &abs_atom;
                        abs_count = 1;
                    }

                    t_symbol *scores_key = generate_hierarchical_key(x->current_palette, source_track_sym, gensym(bar_str), gensym("scores"));
                    t_atom *scores_atoms = NULL;
                    long scores_count = 0;
                    t_atomarray *scores_aa = NULL;
                    t_atom scores_atom;
                    if (dictionary_getatomarray(x->building, scores_key, (t_object **)&scores_aa) == MAX_ERR_NONE && scores_aa) {
                        atomarray_getatoms(scores_aa, &scores_count, &scores_atoms);
                    } else if (dictionary_getatom(x->building, scores_key, &scores_atom) == MAX_ERR_NONE) {
                        scores_atoms = &scores_atom;
                        scores_count = 1;
                    }

                    for (long k = 0; k < abs_count; k++) {
                        if (manifest_count >= manifest_capacity) {
                            manifest_capacity *= 2;
                            manifest = (t_duplication_manifest_item *)sysmem_resizeptr(manifest, manifest_capacity * sizeof(t_duplication_manifest_item));
                        }
                        manifest[manifest_count].track_number = track_num_to_process;
                        manifest[manifest_count].timestamp = atom_getfloat(abs_atoms + k);
                        manifest[manifest_count].score = atom_getfloat(scores_atoms + k);
                        manifest_count++;
                    }
                }
                sysmem_freeptr(pal_str);
                sysmem_freeptr(track_str);
                sysmem_freeptr(bar_str);
                sysmem_freeptr(prop_str);
            }
        }
    }
    sysmem_freeptr(unique_track_nums);

    // --- PROCESSING PHASE ---
    buildspans_log(x, "Processing %ld notes from duplication manifest.", manifest_count);
    // Now that we have all the notes, we can safely add them to the building dictionary.
    if (manifest_count > 0) {
        qsort(manifest, manifest_count, sizeof(t_duplication_manifest_item), compare_manifest_items);
        long bar_length = buildspans_get_bar_length(x);
        if (bar_length > 0) {
            long original_track = x->current_track;

            for (long k = 0; k < manifest_count; k++) {
                x->current_track = manifest[k].track_number;
                buildspans_process_and_add_note(x, manifest[k].timestamp, manifest[k].timestamp, manifest[k].score, f, stored_offset, bar_length);
            }

            x->current_track = original_track;
        } else {
             object_warn((t_object *)x, "Bar length is not positive. Cannot process duplicated notes.");
        }
    }

    sysmem_freeptr(manifest);
    if (keys) sysmem_freeptr(keys);
    buildspans_visualize_memory(x);
    x->current_task_seq = -1;
    if (on_worker) {
        systhread_mutex_unlock(x->state_mutex);
    }
}

// Handler for int messages on the 3rd inlet (proxy #2, track number)
void buildspans_track_deferred(t_buildspans *x, t_symbol *s, long argc, t_atom *argv) {
    if (argc > 0) buildspans_do_track(x, atom_getlong(argv));
}

void buildspans_track(t_buildspans *x, long n) {
    if (x->async && x->worker && !async_worker_is_worker_thread(x->worker)) {
        t_atom a;
        atom_setlong(&a, n);
        buildspans_enqueue_task(x, (method)buildspans_track_deferred, NULL, 1, &a);
        return;
    }
    if (x->defer && !systhread_ismainthread()) {
        t_atom a;
        atom_setlong(&a, n);
        defer(x, (method)buildspans_track_deferred, NULL, 1, &a);
        return;
    }

    buildspans_do_track(x, n);
}

void buildspans_do_track(t_buildspans *x, long n) {
    long seq = buildspans_get_task_sequence(x);
    x->current_task_seq = seq;
    int on_worker = (x->async && x->worker && async_worker_is_worker_thread(x->worker));
    if (on_worker) {
        systhread_mutex_lock(x->state_mutex);
    }
    if (buildspans_is_task_cancelled(x, seq)) {
        x->current_task_seq = -1;
        if (on_worker) {
            systhread_mutex_unlock(x->state_mutex);
        }
        return;
    }
    x->current_track = n;
    x->last_msg_type = gensym("track");
    buildspans_log(x, "Track updated to: %ld", n);
    x->current_task_seq = -1;
    if (on_worker) {
        systhread_mutex_unlock(x->state_mutex);
    }
}

// Handler for various messages, including palette symbol
void buildspans_anything(t_buildspans *x, t_symbol *s, long argc, t_atom *argv) {
    long inlet_num = proxy_getinlet((t_object *)x);

    if (x->async && x->worker && !async_worker_is_worker_thread(x->worker)) {
        t_atom *new_argv = (t_atom *)sysmem_newptr((argc + 1) * sizeof(t_atom));
        if (new_argv) {
            atom_setlong(new_argv, inlet_num);
            for (long i = 0; i < argc; i++) new_argv[i+1] = argv[i];
            buildspans_enqueue_task(x, (method)buildspans_anything_deferred, s, argc + 1, new_argv);
            sysmem_freeptr(new_argv);
        }
        return;
    }

    if (x->defer && !systhread_ismainthread()) {
        t_atom *new_argv = (t_atom *)sysmem_newptr((argc + 1) * sizeof(t_atom));
        if (new_argv) {
            atom_setlong(new_argv, inlet_num);
            for (long i = 0; i < argc; i++) new_argv[i+1] = argv[i];
            defer(x, (method)buildspans_anything_deferred, s, (short)(argc + 1), new_argv);
            sysmem_freeptr(new_argv);
        }
        return;
    }

    buildspans_do_anything(x, s, argc, argv, inlet_num);
}

void buildspans_anything_deferred(t_buildspans *x, t_symbol *s, long argc, t_atom *argv) {
    if (argc > 0) {
        long inlet_num = atom_getlong(argv);
        buildspans_do_anything(x, s, argc - 1, argv + 1, inlet_num);
    }
}

void buildspans_do_anything(t_buildspans *x, t_symbol *s, long argc, t_atom *argv, long inlet_num) {
    long seq = buildspans_get_task_sequence(x);
    x->current_task_seq = seq;
    int on_worker = (x->async && x->worker && async_worker_is_worker_thread(x->worker));
    if (on_worker) {
        systhread_mutex_lock(x->state_mutex);
    }
    if (buildspans_is_task_cancelled(x, seq)) {
        x->current_task_seq = -1;
        if (on_worker) {
            systhread_mutex_unlock(x->state_mutex);
        }
        return;
    }
    // Inlet 3 is the palette symbol inlet
    if (inlet_num == 3) {
        // A standalone symbol is a message with argc=0
        if (argc == 0) {
            x->current_palette = s;
            x->last_msg_type = gensym("palette");
            buildspans_log(x, "Palette set to: %s", s->s_name);
        } else {
            // If it has arguments, it's a list starting with a symbol, which we don't handle here.
            object_error((t_object *)x, "Palette inlet expects a single symbol, but received a list.");
        }
    } else if (inlet_num == 0) {
        if (s == gensym("flush") && argc > 0 && atom_gettype(argv) == A_LONG) {
            buildspans_flush_track(x, atom_getlong(argv));
        } else {
            object_error((t_object *)x, "Message '%s' not understood in inlet %ld.", s->s_name, inlet_num);
        }
    } else {
        // Post an error for unhandled messages on other inlets to avoid silent failures.
        object_error((t_object *)x, "Message '%s' not understood in inlet %ld.", s->s_name, inlet_num);
    }
    x->current_task_seq = -1;
    if (on_worker) {
        systhread_mutex_unlock(x->state_mutex);
    }
}


// Handler for float messages on all inlets
void buildspans_float(t_buildspans *x, double f) {
    long inlet_num = proxy_getinlet((t_object *)x);
    if (inlet_num == 1) {
        buildspans_offset(x, f);
    } else {
        // Fallback for other inlets if they are not already handled by specialized methods
        if (inlet_num == 0) {
             object_error((t_object *)x, "Float received in inlet 0, but list expected.");
        } else if (inlet_num == 2) {
             buildspans_track(x, (long)f);
        } else if (inlet_num == 4) {
             buildspans_local_bar_length(x, f);
        }
    }
}

// Handler for list messages on the main inlet and offset inlet
void buildspans_list(t_buildspans *x, t_symbol *s, long argc, t_atom *argv) {
    long inlet_num = proxy_getinlet((t_object *)x);

    if (x->async && x->worker && !async_worker_is_worker_thread(x->worker)) {
        if (inlet_num == 1) {
            buildspans_enqueue_task(x, (method)buildspans_offset_deferred, s, argc, argv);
        } else {
            buildspans_enqueue_task(x, (method)buildspans_do_list, s, argc, argv);
        }
        return;
    }

    if (x->defer && !systhread_ismainthread()) {
        if (inlet_num == 1) {
            defer(x, (method)buildspans_offset_deferred, s, (short)argc, argv);
        } else {
            defer(x, (method)buildspans_do_list, s, (short)argc, argv);
        }
        return;
    }

    if (inlet_num == 1) {
        int valid = 0;
        if (argc > 0 && (atom_gettype(argv) == A_FLOAT || atom_gettype(argv) == A_LONG)) {
            double f = atom_getfloat(argv);
            double loop_start = (argc >= 2 && (atom_gettype(argv + 1) == A_FLOAT || atom_gettype(argv + 1) == A_LONG)) ? atom_getfloat(argv + 1) : 0.0;
            double most_neg = (argc >= 3 && (atom_gettype(argv + 2) == A_FLOAT || atom_gettype(argv + 2) == A_LONG)) ? atom_getfloat(argv + 2) : 0.0;
            buildspans_do_offset(x, f, loop_start, most_neg);
            valid = 1;
        }

        if (!valid) {
            object_error((t_object *)x, "Offset inlet expects list [offset, loop_start, most_negative_bar] or float offset.");
        }
        return;
    }

    buildspans_do_list(x, s, argc, argv);
}

void buildspans_do_list(t_buildspans *x, t_symbol *s, long argc, t_atom *argv) {
    long seq = buildspans_get_task_sequence(x);
    x->current_task_seq = seq;
    int on_worker = (x->async && x->worker && async_worker_is_worker_thread(x->worker));
    if (on_worker) {
        systhread_mutex_lock(x->state_mutex);
    }
    if (buildspans_is_task_cancelled(x, seq)) {
        x->current_task_seq = -1;
        if (on_worker) {
            systhread_mutex_unlock(x->state_mutex);
        }
        return;
    }
    long bar_length = buildspans_get_bar_length(x);
    buildspans_log(x, "buildspans_list: utilizing bar_length %ld", bar_length);
    if (bar_length <= 0) {
        object_warn((t_object *)x, "Bar length is not positive. Ignoring input.");
        x->current_task_seq = -1;
        if (on_worker) {
            systhread_mutex_unlock(x->state_mutex);
        }
        return;
    }
    double raw_calc_absolute, raw_store_absolute, score;

    if (argc == 2 && atom_gettype(argv) == A_FLOAT && atom_gettype(argv + 1) == A_FLOAT) {
        raw_calc_absolute = atom_getfloat(argv);
        raw_store_absolute = raw_calc_absolute;
        score = atom_getfloat(argv + 1);
    } else if (argc == 3 && atom_gettype(argv) == A_FLOAT && atom_gettype(argv + 1) == A_FLOAT && atom_gettype(argv + 2) == A_FLOAT) {
        raw_calc_absolute = atom_getfloat(argv);
        score = atom_getfloat(argv + 1);
        raw_store_absolute = atom_getfloat(argv + 2);
    } else {
        object_error((t_object *)x, "Input must be a list of two floats (timestamp, score) or three floats (synth_timestamp, score, orig_timestamp).");
        x->current_task_seq = -1;
        if (on_worker) {
            systhread_mutex_unlock(x->state_mutex);
        }
        return;
    }

    double looped_calc_absolute = buildspans_calc_looped_absolute(x, raw_calc_absolute);
    double looped_store_absolute = buildspans_calc_looped_absolute(x, raw_store_absolute);

    buildspans_log(x, "--- New Timestamp-Score Pair Received ---");

    // EPHEMERAL AUTO-INITIALIZATION: If no global offset has been set (raw_offset == 0.0),
    // we use the current note's looped_calc_absolute as the effective offset for this processing cycle
    // without persisting it to x->raw_offset or x->current_offset.
    double effective_raw_offset;
    double effective_stored_offset;
    if (x->raw_offset == 0.0) {
        effective_raw_offset = looped_calc_absolute;
        effective_stored_offset = looped_calc_absolute - x->loop_start;
    } else {
        effective_raw_offset = x->raw_offset;
        effective_stored_offset = x->current_offset;
    }

    buildspans_log(x, "Palette: %s, Raw calc: %.2f, Looped calc: %.2f, Score: %.2f, Raw store: %.2f, Looped store: %.2f, Effective Stored Offset: %.2f",
                    x->current_palette->s_name, raw_calc_absolute, looped_calc_absolute, score, raw_store_absolute, looped_store_absolute, effective_stored_offset);

    // 1. Find all unique track symbols for the current track and CURRENT PALETTE.
    long num_keys;
    t_symbol **keys;
    dictionary_getkeys(x->building, &num_keys, &keys);

    long unique_tracks_count = 0;
    t_symbol **unique_track_syms = (t_symbol **)sysmem_newptr((num_keys + 1) * sizeof(t_symbol *));
    char track_prefix[32];
    snprintf(track_prefix, 32, "%ld-", x->current_track);

    if (keys) {
        for (long i = 0; i < num_keys; i++) {
            char *pal_str, *track_str, *bar_str, *prop_str;
            if (parse_hierarchical_key(keys[i], &pal_str, &track_str, &bar_str, &prop_str)) {
                if (strcmp(pal_str, x->current_palette->s_name) == 0 && strncmp(track_str, track_prefix, strlen(track_prefix)) == 0) {
                    t_symbol *current_track_sym = gensym(track_str);
                    int found = 0;
                    for (long j = 0; j < unique_tracks_count; j++) {
                        if (unique_track_syms[j] == current_track_sym) {
                            found = 1;
                            break;
                        }
                    }
                    if (!found) {
                        unique_track_syms[unique_tracks_count++] = current_track_sym;
                    }
                }
                sysmem_freeptr(pal_str);
                sysmem_freeptr(track_str);
                sysmem_freeptr(bar_str);
                sysmem_freeptr(prop_str);
            }
        }
    }

    // 2. Also consider the global current offset as a potential new span
    char current_track_str[64];
    snprintf(current_track_str, 64, "%ld-%ld", x->current_track, (long)round(effective_stored_offset));
    t_symbol *current_track_sym = gensym(current_track_str);
    int global_offset_found = 0;
    for (long i = 0; i < unique_tracks_count; i++) {
        if (unique_track_syms[i] == current_track_sym) {
            global_offset_found = 1;
            break;
        }
    }
    if (!global_offset_found) {
        unique_track_syms[unique_tracks_count++] = current_track_sym;
    }

    // 3. Add the note to each span (identified by its unique track symbol)
    char candidates_str[1024] = "";
    for (long i = 0; i < unique_tracks_count; i++) {
        strncat(candidates_str, unique_track_syms[i]->s_name, 1024 - strlen(candidates_str) - 1);
        if (i < unique_tracks_count - 1) strncat(candidates_str, ", ", 1024 - strlen(candidates_str) - 1);
    }
    buildspans_log(x, "Adding note to %ld span(s) on track %ld (palette %s): %s", 
                    unique_tracks_count, x->current_track, x->current_palette->s_name, candidates_str);

    for (long i = 0; i < unique_tracks_count; i++) {
        t_symbol *target_track_sym = unique_track_syms[i];

        // ACTUAL OFFSET RESOLUTION HIERARCHY:
        // stored_offset is the loop-relative offset saved in transcript entries.
        // raw_offset is stored_offset + loop_start, used to calculate relative_timestamp.
        double actual_stored_offset = 0.0;
        int offset_found = 0;

        for (long j = 0; j < num_keys; j++) {
            char *key_pal, *key_track, *key_bar, *key_prop;
            if (parse_hierarchical_key(keys[j], &key_pal, &key_track, &key_bar, &key_prop)) {
                if (strcmp(key_pal, x->current_palette->s_name) == 0 && strcmp(key_track, target_track_sym->s_name) == 0 && strcmp(key_prop, "offset") == 0) {
                    t_atom *off_atoms = NULL;
                    long off_count = 0;
                    t_atomarray *off_aa = NULL;
                    t_atom off_atom;
                    if (dictionary_getatomarray(x->building, keys[j], (t_object **)&off_aa) == MAX_ERR_NONE && off_aa) {
                        atomarray_getatoms(off_aa, &off_count, &off_atoms);
                    } else if (dictionary_getatom(x->building, keys[j], &off_atom) == MAX_ERR_NONE) {
                        off_atoms = &off_atom;
                        off_count = 1;
                    }
                    if (off_count > 0) actual_stored_offset = atom_getfloat(off_atoms);
                    offset_found = 1;
                    sysmem_freeptr(key_pal);
                    sysmem_freeptr(key_track);
                    sysmem_freeptr(key_bar);
                    sysmem_freeptr(key_prop);
                    break;
                }
                sysmem_freeptr(key_pal);
                sysmem_freeptr(key_track);
                sysmem_freeptr(key_bar);
                sysmem_freeptr(key_prop);
            }
        }

        if (!offset_found) {
            actual_stored_offset = effective_stored_offset;
        }

        double actual_raw_offset = actual_stored_offset + x->loop_start;

        buildspans_process_and_add_note(x, looped_calc_absolute, looped_store_absolute, score, actual_raw_offset, actual_stored_offset, bar_length);
    }

    if (keys) sysmem_freeptr(keys);
    sysmem_freeptr(unique_track_syms);

    x->last_note_calc = looped_calc_absolute;
    x->last_note_store = looped_store_absolute;
    x->last_note_score = score;
    x->last_msg_type = gensym("list");
    buildspans_run_cleanup(x);
    x->current_task_seq = -1;
    if (on_worker) {
        systhread_mutex_unlock(x->state_mutex);
    }
}

void buildspans_flush_track(t_buildspans *x, long track_num) {
    long bar_length = buildspans_get_bar_length(x);
    buildspans_log(x, "Decision: FLUSH track. Outcome: Flushing/ending currently open spans specifically for track %ld. Utilizing bar_length: %ld", track_num, bar_length);
    long num_keys;
    t_symbol **keys;
    dictionary_getkeys(x->building, &num_keys, &keys);
    if (!keys) return;

    // 1. Identify all unique tracks for this track number across all palettes
    long track_count = 0;
    t_symbol **track_syms = (t_symbol **)sysmem_newptr(num_keys * sizeof(t_symbol *));
    t_symbol **palette_syms = (t_symbol **)sysmem_newptr(num_keys * sizeof(t_symbol *));
    char track_prefix[32];
    snprintf(track_prefix, 32, "%ld-", track_num);

    for (long i = 0; i < num_keys; i++) {
        char *key_pal, *key_track, *key_bar, *key_prop;
        if (parse_hierarchical_key(keys[i], &key_pal, &key_track, &key_bar, &key_prop)) {
            if (strncmp(key_track, track_prefix, strlen(track_prefix)) == 0) {
                int found = 0;
                for(long j=0; j<track_count; ++j) {
                    if (strcmp(track_syms[j]->s_name, key_track) == 0 && strcmp(palette_syms[j]->s_name, key_pal) == 0) {
                        found = 1;
                        break;
                    }
                }
                if (!found) {
                    track_syms[track_count] = gensym(key_track);
                    palette_syms[track_count] = gensym(key_pal);
                    track_count++;
                }
            }
            sysmem_freeptr(key_pal);
            sysmem_freeptr(key_track);
            sysmem_freeptr(key_bar);
            sysmem_freeptr(key_prop);
        }
    }

    // 2. For each identified track, perform deferred rating check and end the span.
    for (long i = 0; i < track_count; i++) {
        t_symbol *track_sym = track_syms[i];
        t_symbol *palette_sym = palette_syms[i];

        // Find the last bar for this track.
        long last_bar_timestamp = -1;
        for (long j = 0; j < num_keys; j++) {
            char *key_pal, *key_track, *key_bar, *key_prop;
            if (parse_hierarchical_key(keys[j], &key_pal, &key_track, &key_bar, &key_prop)) {
                if (strcmp(key_pal, palette_sym->s_name) == 0 && strcmp(key_track, track_sym->s_name) == 0) {
                    long bar_val = atol(key_bar);
                    if (last_bar_timestamp == -1 || bar_val > last_bar_timestamp) {
                        last_bar_timestamp = bar_val;
                    }
                }
                sysmem_freeptr(key_pal);
                sysmem_freeptr(key_track);
                sysmem_freeptr(key_bar);
                sysmem_freeptr(key_prop);
            }
        }

        if (last_bar_timestamp != -1) {
            buildspans_deferred_rating_check(x, palette_sym, track_sym, last_bar_timestamp);
        }

        buildspans_end_track_span(x, palette_sym, track_sym);
    }

    sysmem_freeptr(track_syms);
    sysmem_freeptr(palette_syms);
    sysmem_freeptr(keys);

    x->last_msg_type = gensym("flush");
    buildspans_run_cleanup(x);
}


void buildspans_check_discontiguity(t_buildspans *x, t_symbol *palette_sym, t_symbol *track_sym, double relative_comparison_val) {
    long bar_length = buildspans_get_bar_length(x);
    if (bar_length <= 0) return;

    // Find the most recent bar for the current track
    long last_bar_timestamp = -1;
    long num_keys;
    t_symbol **keys;
    dictionary_getkeys(x->building, &num_keys, &keys);
    if (keys) {
        for (long i = 0; i < num_keys; i++) {
            char *key_pal, *key_track, *key_bar, *key_prop;
            if (parse_hierarchical_key(keys[i], &key_pal, &key_track, &key_bar, &key_prop)) {
                if (strcmp(key_pal, palette_sym->s_name) == 0 && strcmp(key_track, track_sym->s_name) == 0) {
                    long bar_val = atol(key_bar);
                    if (last_bar_timestamp == -1 || bar_val > last_bar_timestamp) {
                        last_bar_timestamp = bar_val;
                    }
                }
                sysmem_freeptr(key_pal);
                sysmem_freeptr(key_track);
                sysmem_freeptr(key_bar);
                sysmem_freeptr(key_prop);
            }
        }
        sysmem_freeptr(keys);
    }

    if (last_bar_timestamp != -1) {
        int was_pruned = buildspans_deferred_rating_check(x, palette_sym, track_sym, last_bar_timestamp);

        // Re-find the most recent bar after potential pruning
        long most_recent_bar_after_rating_check = last_bar_timestamp;
        if (was_pruned) {
            most_recent_bar_after_rating_check = -1;
            dictionary_getkeys(x->building, &num_keys, &keys);
            if (keys) {
                for (long i = 0; i < num_keys; i++) {
                    char *key_pal, *key_track, *key_bar, *key_prop;
                    if (parse_hierarchical_key(keys[i], &key_pal, &key_track, &key_bar, &key_prop)) {
                        if (strcmp(key_pal, palette_sym->s_name) == 0 && strcmp(key_track, track_sym->s_name) == 0) {
                            long bar_val = atol(key_bar);
                            if (most_recent_bar_after_rating_check == -1 || bar_val > most_recent_bar_after_rating_check) {
                                most_recent_bar_after_rating_check = bar_val;
                            }
                        }
                        sysmem_freeptr(key_pal);
                        sysmem_freeptr(key_track);
                        sysmem_freeptr(key_bar);
                        sysmem_freeptr(key_prop);
                    }
                }
                sysmem_freeptr(keys);
            }
        }

        if (most_recent_bar_after_rating_check != -1) {
            double gap_limit = (double)most_recent_bar_after_rating_check + 2.0 * (double)bar_length;
            int is_discontiguous = (relative_comparison_val > gap_limit);

            buildspans_log(x, "Discontiguity check: Assessing track %s on palette %s. Relative comparison value: %.2f, bar_length: %ld",
                            track_sym->s_name, palette_sym->s_name, relative_comparison_val, bar_length);
            buildspans_log(x, "  - Math: limit = most_recent_bar (%ld) + 2 * bar_length (%ld) = %.2f",
                            most_recent_bar_after_rating_check, bar_length, gap_limit);
            buildspans_log(x, "  - Comparison: (relative_comparison_val > limit) -> (%.2f > %.2f) ? %s",
                            relative_comparison_val, gap_limit, is_discontiguous ? "YES (Gap detected)" : "NO");

            if (is_discontiguous) {
                buildspans_log(x, "Decision: END span due to discontiguity. Outcome: Ending span for track %s on palette %s.",
                                track_sym->s_name, palette_sym->s_name);
                buildspans_end_track_span(x, palette_sym, track_sym);
            } else {
                buildspans_log(x, "Decision: CONTINUE span. Outcome: Span is contiguous. Math: relative_comparison_val (%.2f) <= limit (%.2f).",
                                relative_comparison_val, gap_limit);
            }
        } else {
            buildspans_log(x, "Discontiguity check: Re-assessing track %s on palette %s after rating check pruning. No previous bars remain. Decision: CONTINUE span.",
                            track_sym->s_name, palette_sym->s_name);
        }
    } else {
        buildspans_log(x, "Discontiguity check: Assessing track %s on palette %s. No previous bars found. Decision: CONTINUE span.",
                        track_sym->s_name, palette_sym->s_name);
    }
}

// Helper function to calculate a looped absolute timestamp from a raw absolute timestamp
double buildspans_calc_looped_absolute(t_buildspans *x, double raw_absolute) {
    return raw_absolute + x->loop_start + x->most_negative_bar;
}

void buildspans_process_and_add_note(t_buildspans *x, double looped_absolute, double store_timestamp, double score, double raw_offset, double stored_offset, long bar_length) {
    if (buildspans_is_task_cancelled(x, x->current_task_seq)) return;
    if (stored_offset == 0.0 && raw_offset == 0.0) {
        object_error((t_object *)x, "IMPORTANT: Span initialized with offset 0.0 on track %ld (palette %s)", x->current_track, x->current_palette->s_name);
        buildspans_log(x, "*** Span initialization/update with offset 0.0 detected!");
        buildspans_log(x, "*** This occurred during buildspans_process_and_add_note for track (%ld).", x->current_track);

        double effective_offset = (x->raw_offset == 0.0) ? looped_absolute : x->current_offset;
        buildspans_log(x, "*** Current effective_offset: %.2f", effective_offset);

        buildspans_log(x, "*** Global State: current_offset %.2f, loop_start %.2f", x->current_offset, x->loop_start);
        buildspans_log(x, "*** History: last_msg_type %s", x->last_msg_type->s_name);
        buildspans_log(x, "*** Last note parameters: looped_absolute (%.2f), store (%.2f), score (%.2f)", x->last_note_calc, x->last_note_store, x->last_note_score);
        buildspans_log(x, "*** Current note parameters: looped_absolute (%.2f), store (%.2f), score (%.2f)", looped_absolute, store_timestamp, score);

        // List active spans
        long num_keys;
        t_symbol **keys;
        dictionary_getkeys(x->building, &num_keys, &keys);
        if (keys) {
            char active_spans_str[2048] = "";
            long active_spans_count = 0;
            for (long i = 0; i < num_keys; i++) {
                char *pal_str, *track_str, *bar_str, *prop_str;
                if (parse_hierarchical_key(keys[i], &pal_str, &track_str, &bar_str, &prop_str)) {
                    if (strcmp(pal_str, x->current_palette->s_name) == 0 && strcmp(prop_str, "offset") == 0) {
                        if (active_spans_count > 0) strncat(active_spans_str, ", ", 2048 - strlen(active_spans_str) - 1);
                        strncat(active_spans_str, track_str, 2048 - strlen(active_spans_str) - 1);
                        active_spans_count++;
                    }
                    sysmem_freeptr(pal_str); sysmem_freeptr(track_str); sysmem_freeptr(bar_str); sysmem_freeptr(prop_str);
                }
            }
            buildspans_log(x, "*** Active spans on palette %s: %s", x->current_palette->s_name, active_spans_str);
            sysmem_freeptr(keys);
        }

        // Temporary Fix: Remove the entire span
        char target_track_str[64];
        snprintf(target_track_str, 64, "%ld-0", x->current_track);
        t_symbol *target_track_sym = gensym(target_track_str);

        object_error((t_object *)x, "TEMPORARY FIX: Removing invalid span %s from memory.", target_track_sym->s_name);
        buildspans_log(x, "*** TEMPORARY FIX: Removing all dictionary entries for span %s on palette %s.", target_track_sym->s_name, x->current_palette->s_name);

        dictionary_getkeys(x->building, &num_keys, &keys);
        if (keys) {
            for (long i = 0; i < num_keys; i++) {
                char *pal_str, *track_str, *bar_str, *prop_str;
                if (parse_hierarchical_key(keys[i], &pal_str, &track_str, &bar_str, &prop_str)) {
                    if (strcmp(pal_str, x->current_palette->s_name) == 0 && strcmp(track_str, target_track_sym->s_name) == 0) {
                        dictionary_deleteentry(x->building, keys[i]);
                    }
                    sysmem_freeptr(pal_str); sysmem_freeptr(track_str); sysmem_freeptr(bar_str); sysmem_freeptr(prop_str);
                }
            }
            sysmem_freeptr(keys);
        }
        buildspans_visualize_memory(x);
        return; // Abort processing for this note
    }
    buildspans_log(x, "buildspans_process_and_add_note: utilizing bar_length (%ld)", bar_length);

    // Grouping key uses rounded stored_offset (loop-relative offset)
    char track_str[64];
    snprintf(track_str, 64, "%ld-%ld", x->current_track, (long)round(stored_offset));
    t_symbol *track_sym = gensym(track_str);

    /*
     * TIMESTAMP RELATIONSHIPS:
     * 1. looped_absolute = raw_note_timestamp + loop_start + most_negative_bar
     * 2. raw_offset      = absolute song timestamp when offset was sent
     * 3. stored_offset   = raw_offset - loop_start (loop-relative offset stored in transcript)
     *
     * relative_timestamp subtracts raw_offset (not stored_offset) from looped_absolute
     * because loop_start is already baked into looped_absolute. Subtracting raw_offset
     * cancels loop_start cleanly:
     * relative_timestamp = (raw_note + loop_start + most_negative_bar) - (stored_offset + loop_start)
     *                    = raw_note + most_negative_bar - stored_offset
     *
     * Downstream, weaver~ calculates palette sample position via:
     * src_ms = stored_offset + current_scan
     * where current_scan = ramp_in + most_negative_bar.
     */
    double relative_timestamp = looped_absolute - raw_offset;
    buildspans_log(x, "Relative timestamp (looped_absolute (%.2f) - raw_offset (%.2f)): %.2f", looped_absolute, raw_offset, relative_timestamp);
    long bar_timestamp_val = floor(relative_timestamp / bar_length) * bar_length;
    buildspans_log(x, "Calculated bar timestamp (rounded down to nearest bar_length (%ld)): %ld", bar_length, bar_timestamp_val);

    // --- Find the most recent bar for the current track to see if this is a new bar ---
    long last_bar_timestamp = -1;
    long num_keys;
    t_symbol **keys;
    dictionary_getkeys(x->building, &num_keys, &keys);
    if (keys) {
        for (long i = 0; i < num_keys; i++) {
            char *key_pal, *key_track, *key_bar, *key_prop;
            if (parse_hierarchical_key(keys[i], &key_pal, &key_track, &key_bar, &key_prop)) {
                if (strcmp(key_pal, x->current_palette->s_name) == 0 && strcmp(key_track, track_sym->s_name) == 0) {
                    long bar_val = atol(key_bar);
                    if (last_bar_timestamp == -1 || bar_val > last_bar_timestamp) {
                        last_bar_timestamp = bar_val;
                    }
                }
                sysmem_freeptr(key_pal);
                sysmem_freeptr(key_track);
                sysmem_freeptr(key_bar);
                sysmem_freeptr(key_prop);
            }
        }
        sysmem_freeptr(keys);
    }

    int is_new_bar = (last_bar_timestamp == -1 || bar_timestamp_val > last_bar_timestamp);

    // --- Deferred span ending logic (only if a new bar is detected) ---
    if (is_new_bar && last_bar_timestamp != -1) {
        buildspans_check_discontiguity(x, x->current_palette, track_sym, relative_timestamp);
    }

    // --- ADD OR UPDATE BAR ---
    char bar_str[32];
    snprintf(bar_str, 32, "%ld", bar_timestamp_val);
    t_symbol *bar_sym = gensym(bar_str);

    // Update stored offset in transcript (stored_offset is loop-relative offset for weaver~)
    t_symbol *offset_key = generate_hierarchical_key(x->current_palette, track_sym, bar_sym, gensym("offset"));
    if (dictionary_hasentry(x->building, offset_key)) dictionary_deleteentry(x->building, offset_key);
    dictionary_appendfloat(x->building, offset_key, stored_offset);
    buildspans_log(x, "%s %.2f", offset_key->s_name, stored_offset);
    t_atom offset_atom;
    atom_setfloat(&offset_atom, stored_offset);

    // Update palette
    t_symbol *palette_key = generate_hierarchical_key(x->current_palette, track_sym, bar_sym, gensym("palette"));
    if (dictionary_hasentry(x->building, palette_key)) dictionary_deleteentry(x->building, palette_key);
    dictionary_appendsym(x->building, palette_key, x->current_palette);
    buildspans_log(x, "%s %s", palette_key->s_name, x->current_palette->s_name);
    t_atom palette_atom;
    atom_setsym(&palette_atom, x->current_palette);

    // Update absolutes array
    t_symbol *absolutes_key = generate_hierarchical_key(x->current_palette, track_sym, bar_sym, gensym("absolutes"));
    t_atomarray *absolutes_array = NULL;
    if (dictionary_getatomarray(x->building, absolutes_key, (t_object **)&absolutes_array) != MAX_ERR_NONE || !absolutes_array) {
        // If not found or if it was a single atom, create a new atomarray
        t_atom existing_atom;
        if (dictionary_getatom(x->building, absolutes_key, &existing_atom) == MAX_ERR_NONE) {
            absolutes_array = atomarray_new(1, &existing_atom);
        } else {
            absolutes_array = atomarray_new(0, NULL);
        }
        t_atom a; atom_setobj(&a, (t_object *)absolutes_array);
        if (dictionary_hasentry(x->building, absolutes_key)) dictionary_deleteentry(x->building, absolutes_key);
        dictionary_appendatom(x->building, absolutes_key, &a);
    }
    t_atom new_absolute; atom_setfloat(&new_absolute, store_timestamp);
    atomarray_appendatom(absolutes_array, &new_absolute);
    char *abs_str = atomarray_to_string(absolutes_array);
    if (abs_str) {
        buildspans_log(x, "%s %s", absolutes_key->s_name, abs_str);
        sysmem_freeptr(abs_str);
    }

    // Update scores array
    t_symbol *scores_key = generate_hierarchical_key(x->current_palette, track_sym, bar_sym, gensym("scores"));
    t_atomarray *scores_array = NULL;
    if (dictionary_getatomarray(x->building, scores_key, (t_object **)&scores_array) != MAX_ERR_NONE || !scores_array) {
        // If not found or if it was a single atom, create a new atomarray
        t_atom existing_atom;
        if (dictionary_getatom(x->building, scores_key, &existing_atom) == MAX_ERR_NONE) {
            scores_array = atomarray_new(1, &existing_atom);
        } else {
            scores_array = atomarray_new(0, NULL);
        }
        t_atom a; atom_setobj(&a, (t_object *)scores_array);
        if (dictionary_hasentry(x->building, scores_key)) dictionary_deleteentry(x->building, scores_key);
        dictionary_appendatom(x->building, scores_key, &a);
    }
    t_atom new_score; atom_setfloat(&new_score, score);
    atomarray_appendatom(scores_array, &new_score);
    char *scores_str = atomarray_to_string(scores_array);
    if (scores_str) {
        buildspans_log(x, "%s %s", scores_key->s_name, scores_str);
        sysmem_freeptr(scores_str);
    }

    // Update mean
    long scores_count = atomarray_getsize(scores_array);
    if (scores_count > 0) {
        double sum = 0.0;
        long count; t_atom *atoms;
        atomarray_getatoms(scores_array, &count, &atoms);
        for (long i = 0; i < count; i++) sum += atom_getfloat(&atoms[i]);
        double mean = sum / count;

        t_symbol *mean_key = generate_hierarchical_key(x->current_palette, track_sym, bar_sym, gensym("mean"));
        if (dictionary_hasentry(x->building, mean_key)) dictionary_deleteentry(x->building, mean_key);
        dictionary_appendfloat(x->building, mean_key, mean);
        buildspans_log(x, "%s %.2f", mean_key->s_name, mean);
        t_atom mean_atom;
        atom_setfloat(&mean_atom, mean);
    }

    // --- UPDATE AND BACK-PROPAGATE SPAN ---
    // 1. Get all bar timestamps for the current track AND PALETTE.
    dictionary_getkeys(x->building, &num_keys, &keys);
    long bar_timestamps_count = 0;
    long *bar_timestamps = (long *)sysmem_newptr(num_keys * sizeof(long)); // Over-allocate, then count
    if (keys) {
        for (long i = 0; i < num_keys; i++) {
            char *key_pal, *key_track, *key_bar, *key_prop;
            if (parse_hierarchical_key(keys[i], &key_pal, &key_track, &key_bar, &key_prop)) {
                if (strcmp(key_pal, x->current_palette->s_name) == 0 && strcmp(key_track, track_sym->s_name) == 0) {
                    // To avoid duplicates, only add when we see the 'mean' property
                    if (strcmp(key_prop, "mean") == 0) {
                        bar_timestamps[bar_timestamps_count++] = atol(key_bar);
                    }
                }
                sysmem_freeptr(key_pal);
                sysmem_freeptr(key_track);
                sysmem_freeptr(key_bar);
                sysmem_freeptr(key_prop);
            }
        }
        sysmem_freeptr(keys);
    }
    qsort(bar_timestamps, bar_timestamps_count, sizeof(long), compare_longs);

    // 2. Create the NEW span array and link it to all bars in the track.
    t_atomarray *new_span_array = atomarray_new(0, NULL);
    for (long i = 0; i < bar_timestamps_count; i++) {
        t_atom a; atom_setlong(&a, bar_timestamps[i]);
        atomarray_appendatom(new_span_array, &a);
    }
    char *span_str = atomarray_to_string(new_span_array);
    if (span_str) {
        for (long i = 0; i < bar_timestamps_count; i++) {
            char temp_bar_str[32]; snprintf(temp_bar_str, 32, "%ld", bar_timestamps[i]);
            t_symbol *temp_bar_sym = gensym(temp_bar_str);
            t_symbol *span_key = generate_hierarchical_key(x->current_palette, track_sym, temp_bar_sym, gensym("span"));
            
            // Create a deep copy for each bar to ensure no shared ownership
            t_atomarray *span_copy = atomarray_deep_copy(new_span_array);
            t_atom span_copy_atom;
            atom_setobj(&span_copy_atom, (t_object *)span_copy);
            dictionary_appendatom(x->building, span_key, &span_copy_atom);

            // Logging
            char log_buffer[512];
            snprintf(log_buffer, 512, "%s %s", span_key->s_name, span_str);
            buildspans_log(x, "%s", log_buffer);
        }
        sysmem_freeptr(span_str);
    }
    object_free(new_span_array); // Free the original master array

    // --- RATING CALCULATION & BACK-PROPAGATION ---
    double final_lowest_mean = -1.0;
    for (long i = 0; i < bar_timestamps_count; i++) {
        char temp_bar_str[32]; snprintf(temp_bar_str, 32, "%ld", bar_timestamps[i]);
        t_symbol *temp_bar_sym = gensym(temp_bar_str);
        t_symbol *mean_key = generate_hierarchical_key(x->current_palette, track_sym, temp_bar_sym, gensym("mean"));
        t_atom *m_atoms = NULL;
        long m_count = 0;
        t_atomarray *m_aa = NULL;
        t_atom m_atom;
        if (dictionary_getatomarray(x->building, mean_key, (t_object **)&m_aa) == MAX_ERR_NONE && m_aa) {
            atomarray_getatoms(m_aa, &m_count, &m_atoms);
        } else if (dictionary_getatom(x->building, mean_key, &m_atom) == MAX_ERR_NONE) {
            m_atoms = &m_atom;
            m_count = 1;
        }
        if (m_count > 0) {
            double current_bar_mean = atom_getfloat(m_atoms);
            if (final_lowest_mean == -1.0 || current_bar_mean < final_lowest_mean) {
                final_lowest_mean = current_bar_mean;
            }
        }
    }
    if (final_lowest_mean != -1.0) {
        double final_rating = final_lowest_mean * bar_timestamps_count;
        for (long i = 0; i < bar_timestamps_count; i++) {
            char temp_bar_str[32]; snprintf(temp_bar_str, 32, "%ld", bar_timestamps[i]);
            t_symbol *temp_bar_sym = gensym(temp_bar_str);
            t_symbol *rating_key = generate_hierarchical_key(x->current_palette, track_sym, temp_bar_sym, gensym("rating"));
            if (dictionary_hasentry(x->building, rating_key)) dictionary_deleteentry(x->building, rating_key);
            dictionary_appendfloat(x->building, rating_key, final_rating);
            buildspans_log(x, "%s %.2f", rating_key->s_name, final_rating);
        }
        buildspans_log(x, "Final rating for span: %.2f (final_lowest_mean (%.2f) * bar_timestamps_count (%ld))", final_rating, final_lowest_mean, bar_timestamps_count);
    }

    sysmem_freeptr(bar_timestamps);
    buildspans_visualize_memory(x);
}

void buildspans_end_track_span(t_buildspans *x, t_symbol *palette_sym, t_symbol *track_sym) {
    if (buildspans_is_task_cancelled(x, x->current_task_seq)) return;
    long num_keys;
    t_symbol **keys;
    dictionary_getkeys(x->building, &num_keys, &keys);
    if (!keys) return;

    // 1. Find the first 'span' atomarray for the track. They are all shared.
    t_atomarray *span_to_output = NULL;
    t_atomarray *span_aa = NULL;
    t_atom span_atom;
    int span_found_robustly = 0;

    if (keys) {
        for (long i = 0; i < num_keys; i++) {
            char *key_pal, *key_track, *key_bar, *key_prop;
            if (parse_hierarchical_key(keys[i], &key_pal, &key_track, &key_bar, &key_prop)) {
                if (strcmp(key_pal, palette_sym->s_name) == 0 && strcmp(key_track, track_sym->s_name) == 0 && strcmp(key_prop, "span") == 0) {
                    if (dictionary_getatomarray(x->building, keys[i], (t_object **)&span_aa) == MAX_ERR_NONE && span_aa) {
                        span_to_output = span_aa;
                        span_found_robustly = 1;
                    } else if (dictionary_getatom(x->building, keys[i], &span_atom) == MAX_ERR_NONE) {
                        span_to_output = atomarray_new(1, &span_atom);
                        span_found_robustly = 1;
                    }
                    sysmem_freeptr(key_pal);
                    sysmem_freeptr(key_track);
                    sysmem_freeptr(key_bar);
                    sysmem_freeptr(key_prop);
                    if (span_found_robustly) break; // Found it.
                }
                sysmem_freeptr(key_pal);
                sysmem_freeptr(key_track);
                sysmem_freeptr(key_bar);
                sysmem_freeptr(key_prop);
            }
        }
    }

    // 2. If no span was found (e.g., single bar), create one locally.
    int local_span_created = 0;
    if (!span_to_output && keys) {
        local_span_created = 1;
        span_to_output = atomarray_new(0, NULL);
        long bar_count = 0;
        long *bar_timestamps = (long *)sysmem_newptr(num_keys * sizeof(long));
        for (long i = 0; i < num_keys; i++) {
            char *key_pal, *key_track, *key_bar, *key_prop;
             if (parse_hierarchical_key(keys[i], &key_pal, &key_track, &key_bar, &key_prop)) {
                if (strcmp(key_pal, palette_sym->s_name) == 0 && strcmp(key_track, track_sym->s_name) == 0 && strcmp(key_prop, "mean") == 0) {
                     bar_timestamps[bar_count++] = atol(key_bar);
                }
                sysmem_freeptr(key_pal);
                sysmem_freeptr(key_track);
                sysmem_freeptr(key_bar);
                sysmem_freeptr(key_prop);
            }
        }
        qsort(bar_timestamps, bar_count, sizeof(long), compare_longs);
        for(long i=0; i<bar_count; ++i) {
            t_atom a;
            atom_setlong(&a, bar_timestamps[i]);
            atomarray_appendatom(span_to_output, &a);
        }
        sysmem_freeptr(bar_timestamps);
    }


    // 3. Calculate rating and output.
    if (span_to_output) {
        if (buildspans_validate_span_before_output(x, palette_sym, track_sym, span_to_output)) {
            long span_size;
            t_atom *span_atoms;
            atomarray_getatoms(span_to_output, &span_size, &span_atoms);

            double lowest_mean = -1.0;
            if (span_size > 0) {
                for (long i = 0; i < span_size; i++) {
                    long bar_ts = atom_getlong(&span_atoms[i]);
                    char bar_str[32]; snprintf(bar_str, 32, "%ld", bar_ts);
                    t_symbol *bar_sym = gensym(bar_str);
                    t_symbol *mean_key = generate_hierarchical_key(palette_sym, track_sym, bar_sym, gensym("mean"));
                    t_atom *m_atoms = NULL;
                    long m_count = 0;
                    t_atomarray *m_aa = NULL;
                    t_atom m_atom;
                    if (dictionary_getatomarray(x->building, mean_key, (t_object **)&m_aa) == MAX_ERR_NONE && m_aa) {
                        atomarray_getatoms(m_aa, &m_count, &m_atoms);
                    } else if (dictionary_getatom(x->building, mean_key, &m_atom) == MAX_ERR_NONE) {
                        m_atoms = &m_atom;
                        m_count = 1;
                    }
                    if (m_count > 0) {
                        double bar_mean = atom_getfloat(m_atoms);
                        if (lowest_mean == -1.0 || bar_mean < lowest_mean) {
                            lowest_mean = bar_mean;
                        }
                    }
                }
            }
            double final_rating = (lowest_mean != -1.0) ? (lowest_mean * span_size) : 0.0;
            buildspans_log(x, "Ending span for track %s on palette %s with rating %.2f (%.2f * %ld)", track_sym->s_name, palette_sym->s_name, final_rating, lowest_mean, span_size);

            long track_num_to_output;
            sscanf(track_sym->s_name, "%ld-", &track_num_to_output);

            // Write log if log is enabled
            if (x->log) {
                write_multibar_negative_rating_log(x, palette_sym, track_sym, span_to_output, final_rating);
            }

            // Outlet 3: Detailed span data
            buildspans_output_span_data(x, palette_sym, track_sym, span_to_output);

            // Outlet 2: Track number
            t_atom t_atom_track;
            atom_setlong(&t_atom_track, track_num_to_output);
            if (x->bound_crucible) {
                crucible_anything((t_crucible *)x->bound_crucible, gensym("track"), 1, &t_atom_track);
            } else {
                if (!x->async || systhread_ismainthread()) {
                    outlet_anything(x->track_outlet, gensym("track"), 1, &t_atom_track);
                } else {
                    defer(x, (method)buildspans_defer_output, gensym("track"), 1, &t_atom_track);
                }
            }

            // Outlet 1: Span list
            if (x->bound_crucible) {
                crucible_anything((t_crucible *)x->bound_crucible, gensym("span"), (short)span_size, span_atoms);
            } else {
                if (!x->async || systhread_ismainthread()) {
                    outlet_anything(x->span_outlet, gensym("span"), (short)span_size, span_atoms);
                } else {
                    defer(x, (method)buildspans_defer_output, gensym("span"), (short)span_size, span_atoms);
                }
            }
        }

        if (local_span_created || (span_found_robustly && span_to_output != span_aa)) {
            object_free(span_to_output);
        }
    }

    // 4. Delete all keys associated with the track AND palette.
    if (keys) {
        t_symbol **keys_to_delete = (t_symbol**)sysmem_newptr(num_keys * sizeof(t_symbol*));
        long delete_count = 0;
        for(long i=0; i<num_keys; ++i) {
            char *key_pal, *key_track, *key_bar, *key_prop;
            if (parse_hierarchical_key(keys[i], &key_pal, &key_track, &key_bar, &key_prop)) {
                 if (strcmp(key_pal, palette_sym->s_name) == 0 && strcmp(key_track, track_sym->s_name) == 0) {
                     keys_to_delete[delete_count++] = keys[i];
                 }
                 sysmem_freeptr(key_pal);
                 sysmem_freeptr(key_track);
                 sysmem_freeptr(key_bar);
                 sysmem_freeptr(key_prop);
             }
        }
        for(long i=0; i<delete_count; ++i) {
            dictionary_deleteentry(x->building, keys_to_delete[i]);
        }
        sysmem_freeptr(keys_to_delete);
        sysmem_freeptr(keys);
    }

    buildspans_visualize_memory(x);
    // Defer the cleanup check by adding the track to a temporary dictionary.
    // We'll store it as palette::track to be sure
    char deferred_key[256];
    snprintf(deferred_key, 256, "%s::%s", palette_sym->s_name, track_sym->s_name);
    dictionary_appendsym(x->tracks_ended_in_current_event, gensym(deferred_key), 0);
}

void buildspans_run_cleanup(t_buildspans *x) {
    long num_ended_tracks;
    t_symbol **ended_track_keys;
    dictionary_getkeys(x->tracks_ended_in_current_event, &num_ended_tracks, &ended_track_keys);
    if (ended_track_keys) {
        for (long i = 0; i < num_ended_tracks; i++) {
            // Re-parse the palette and track from the deferred key "pal::track"
            char *pal_str = NULL;
            char *track_str = strstr(ended_track_keys[i]->s_name, "::");
            if (track_str) {
                size_t pal_len = track_str - ended_track_keys[i]->s_name;
                pal_str = (char *)sysmem_newptr(pal_len + 1);
                strncpy(pal_str, ended_track_keys[i]->s_name, pal_len);
                pal_str[pal_len] = '\0';
                track_str += 2;
                buildspans_cleanup_track_offset_if_needed(x, gensym(pal_str), gensym(track_str));
                sysmem_freeptr(pal_str);
            }
        }
        sysmem_freeptr(ended_track_keys);
    }
    dictionary_clear(x->tracks_ended_in_current_event);
}


void buildspans_bang(t_buildspans *x) {
    if (x->async && x->worker && !async_worker_is_worker_thread(x->worker)) {
        buildspans_enqueue_task(x, (method)buildspans_do_bang, NULL, 0, NULL);
        return;
    }
    if (x->defer && !systhread_ismainthread()) {
        defer(x, (method)buildspans_do_bang, NULL, 0, NULL);
        return;
    }

    buildspans_do_bang(x, NULL, 0, NULL);
}

void buildspans_do_bang(t_buildspans *x, t_symbol *s, long argc, t_atom *argv) {
    long seq = buildspans_get_task_sequence(x);
    x->current_task_seq = seq;
    int on_worker = (x->async && x->worker && async_worker_is_worker_thread(x->worker));
    if (on_worker) {
        systhread_mutex_lock(x->state_mutex);
    }
    if (buildspans_is_task_cancelled(x, seq)) {
        x->current_task_seq = -1;
        if (on_worker) {
            systhread_mutex_unlock(x->state_mutex);
        }
        return;
    }
    if (x->bound_crucible) {
        if (!x->async || systhread_ismainthread()) {
            outlet_int(x->span_outlet, 1);
        } else {
            t_atom a;
            atom_setlong(&a, 1);
            defer(x, (method)buildspans_defer_output, gensym("span_int"), 1, &a);
        }
    }

    long bar_length = buildspans_get_bar_length(x);
    buildspans_log(x, "Decision: BANG flush. Outcome: Flush triggered by bang. Ending/flushing all currently open spans across all tracks/palettes. Utilizing bar_length: %ld", bar_length);

    long num_keys;
    t_symbol **keys;
    dictionary_getkeys(x->building, &num_keys, &keys);

    if (keys) {
        long unique_palette_count = 0;
        t_symbol **unique_palettes = (t_symbol **)sysmem_newptr(num_keys * sizeof(t_symbol *));

        for (long i = 0; i < num_keys; i++) {
            char *pal_str, *track_str, *bar_str, *prop_str;
            if (parse_hierarchical_key(keys[i], &pal_str, &track_str, &bar_str, &prop_str)) {
                int found = 0;
                for (long j = 0; j < unique_palette_count; j++) {
                    if (strcmp(unique_palettes[j]->s_name, pal_str) == 0) {
                        found = 1;
                        break;
                    }
                }
                if (!found) {
                    unique_palettes[unique_palette_count++] = gensym(pal_str);
                }
                sysmem_freeptr(pal_str);
                sysmem_freeptr(track_str);
                sysmem_freeptr(bar_str);
                sysmem_freeptr(prop_str);
            }
        }

        for (long i = 0; i < unique_palette_count; i++) {
            buildspans_flush(x, unique_palettes[i]);
        }

        sysmem_freeptr(unique_palettes);
        sysmem_freeptr(keys);
    }

    if (x->bound_crucible) {
        if (!x->async || systhread_ismainthread()) {
            outlet_int(x->span_outlet, 0);
        } else {
            t_atom a;
            atom_setlong(&a, 0);
            defer(x, (method)buildspans_defer_output, gensym("span_int"), 1, &a);
        }
    }

    x->last_msg_type = gensym("bang");
    x->current_task_seq = -1;
    if (on_worker) {
        systhread_mutex_unlock(x->state_mutex);
    }
}

void buildspans_flush(t_buildspans *x, t_symbol *palette_sym) {
    long bar_length = buildspans_get_bar_length(x);
    buildspans_log(x, "buildspans_flush: utilizing bar_length %ld", bar_length);
    long num_keys;
    t_symbol **keys;
    dictionary_getkeys(x->building, &num_keys, &keys);
    if (!keys) return;

    // 1. Identify all unique tracks FOR THIS PALETTE.
    long track_count = 0;
    t_symbol **track_syms = (t_symbol **)sysmem_newptr(num_keys * sizeof(t_symbol *));
    for (long i = 0; i < num_keys; i++) {
        char *key_pal, *key_track, *key_bar, *key_prop;
        if (parse_hierarchical_key(keys[i], &key_pal, &key_track, &key_bar, &key_prop)) {
            if (strcmp(key_pal, palette_sym->s_name) == 0) {
                int found = 0;
                for(long j=0; j<track_count; ++j) {
                    if (strcmp(track_syms[j]->s_name, key_track) == 0) {
                        found = 1;
                        break;
                    }
                }
                if (!found) {
                    track_syms[track_count++] = gensym(key_track);
                }
            }
            sysmem_freeptr(key_pal);
            sysmem_freeptr(key_track);
            sysmem_freeptr(key_bar);
            sysmem_freeptr(key_prop);
        }
    }

    // 2. For each track, perform deferred rating check and end the span.
    for (long i = 0; i < track_count; i++) {
        t_symbol *track_sym = track_syms[i];

        // Find the last bar for this track.
        long last_bar_timestamp = -1;
        for (long j = 0; j < num_keys; j++) {
            char *key_pal, *key_track, *key_bar, *key_prop;
            if (parse_hierarchical_key(keys[j], &key_pal, &key_track, &key_bar, &key_prop)) {
                if (strcmp(key_pal, palette_sym->s_name) == 0 && strcmp(key_track, track_sym->s_name) == 0) {
                    long bar_val = atol(key_bar);
                    if (last_bar_timestamp == -1 || bar_val > last_bar_timestamp) {
                        last_bar_timestamp = bar_val;
                    }
                }
                sysmem_freeptr(key_pal);
                sysmem_freeptr(key_track);
                sysmem_freeptr(key_bar);
                sysmem_freeptr(key_prop);
            }
        }

        if (last_bar_timestamp != -1) {
            buildspans_deferred_rating_check(x, palette_sym, track_sym, last_bar_timestamp);
        }

        buildspans_end_track_span(x, palette_sym, track_sym);
    }

    sysmem_freeptr(track_syms);
    sysmem_freeptr(keys);

    x->last_msg_type = gensym("flush");
    buildspans_run_cleanup(x);
}


void buildspans_assist(t_buildspans *x, void *b, long m, long a, char *s) {
    if (m == ASSIST_INLET) {
        switch (a) {
            case 0:
                sprintf(s, "Inlet 1: (list) note data, (bang) flush, (flush) flush track, (clear) clear, (log/visualize/bind/async) attributes.");
                break;
            case 1:
                sprintf(s, "Inlet 2: (list/float) Offset Timestamp, [Offset, Loop Start, Most Negative Bar]");
                break;
            case 2:
                sprintf(s, "Inlet 3: (int) Track Number");
                break;
            case 3:
                sprintf(s, "Inlet 4: (symbol) Palette");
                break;
            case 4:
                sprintf(s, "Inlet 5: (float) Local Bar Length");
                break;
        }
    } else { // ASSIST_OUTLET
        switch (a) {
            case 0: sprintf(s, "Outlet 1: Span Data (span list). Bypassed if @bind is active, but outputs a 1 before a bang flush begins and a 0 once it is complete when @bind is active."); break;
            case 1: sprintf(s, "Outlet 2: Track Number (track int). Bypassed if @bind is active."); break;
            case 2: sprintf(s, "Outlet 3: Bar Data for Ended Spans (anything). Bypassed if @bind is active."); break;
            case 3: sprintf(s, "Outlet 4: Logging & Visualization Outlet"); break;
        }
    }
}

void buildspans_set_bar_buffer(t_buildspans *x, t_symbol *s) {
    if (s && s->s_name) {
        x->s_buffer_name = s;
        if (x->buffer_ref) {
            buffer_ref_set(x->buffer_ref, s);
        } else {
            x->buffer_ref = buffer_ref_new((t_object *)x, s);
        }
        buildspans_log(x, "Buffer set to: %s", s->s_name);
        if (s == gensym("bar") && !buffer_ref_getobject(x->buffer_ref)) {
            object_error((t_object *)x, "bar buffer~ not found");
        }
    } else {
        object_error((t_object *)x, "set_bar_buffer requires a valid buffer name.");
    }
}

void buildspans_local_bar_length(t_buildspans *x, double f) {
    if (x->async && x->worker && !async_worker_is_worker_thread(x->worker)) {
        t_atom a;
        atom_setfloat(&a, f);
        buildspans_enqueue_task(x, (method)buildspans_do_local_bar_length, NULL, 1, &a);
        return;
    }
    if (x->defer && !systhread_ismainthread()) {
        t_atom a;
        atom_setfloat(&a, f);
        defer(x, (method)buildspans_do_local_bar_length, NULL, 1, &a);
        return;
    }
    t_atom a;
    atom_setfloat(&a, f);
    buildspans_do_local_bar_length(x, NULL, 1, &a);
}

void buildspans_do_local_bar_length(t_buildspans *x, t_symbol *s, long argc, t_atom *argv) {
    long seq = buildspans_get_task_sequence(x);
    x->current_task_seq = seq;
    int on_worker = (x->async && x->worker && async_worker_is_worker_thread(x->worker));
    if (on_worker) {
        systhread_mutex_lock(x->state_mutex);
    }
    if (buildspans_is_task_cancelled(x, seq)) {
        x->current_task_seq = -1;
        if (on_worker) {
            systhread_mutex_unlock(x->state_mutex);
        }
        return;
    }
    double f = atom_getfloat(argv);
    long old_bar_length = (long)x->local_bar_length;
    if (f <= 0) {
        x->local_bar_length = 0;
    } else {
        x->local_bar_length = f;
    }
    if ((long)x->local_bar_length != old_bar_length) {
        buildspans_log(x, "bar_length changed to %ld", (long)x->local_bar_length);
        if (x->bound_crucible) {
            crucible_local_bar_length((t_crucible *)x->bound_crucible, f);
        }
    }
    buildspans_log(x, "Local bar length set to: %.2f", x->local_bar_length);
    x->current_task_seq = -1;
    if (on_worker) {
        systhread_mutex_unlock(x->state_mutex);
    }
}

t_max_err buildspans_attr_set_async(t_buildspans *x, void *attr, long ac, t_atom *av) {
    if (ac && av) {
        x->async = atom_getlong(av);
        if (x->async) {
            if (!x->worker) x->worker = async_worker_create();
            // If already bound to an async crucible, sync worker
            if (x->bound_crucible) {
                t_crucible *c = (t_crucible *)x->bound_crucible;
                if (c->async && c->worker && c->worker != x->worker) {
                    async_worker_release(x->worker);
                    x->worker = c->worker;
                    async_worker_retain(x->worker);
                    buildspans_log(x, "Synced background worker with already bound crucible.");
                }
            }
        } else if (x->worker) {
            async_worker_release(x->worker);
            x->worker = NULL;
        }
    }
    return MAX_ERR_NONE;
}

t_max_err buildspans_attr_set_log(t_buildspans *x, void *attr, long ac, t_atom *av) {
    if (ac && av) {
        x->log = atom_getlong(av);
        buildspans_log(x, "log attribute set to %ld", x->log);
    }
    return MAX_ERR_NONE;
}

static t_object *buildspans_find_crucible_recursive(t_object *patcher, t_symbol *bind_name) {
    if (!patcher) return NULL;
    t_object *box = NULL;
    for (box = jpatcher_get_firstobject(patcher); box; box = jbox_get_nextobject(box)) {
        if (!box) continue;
        t_object *obj = jbox_get_object(box);
        if (!obj) continue;

        t_symbol *varname = (t_symbol *)object_attr_getsym(box, gensym("varname"));
        if (varname == bind_name) {
            if (object_classname_compare(obj, gensym("crucible")) ||
                object_classname_compare(obj, gensym("rebar_crucible_internal"))) {
                t_symbol *clsname = object_classname(obj);
                if (class_findbyname(CLASS_BOX, clsname) || class_findbyname(CLASS_NOBOX, clsname)) {
                    return obj;
                }
            }
        }

        // Search subpatchers or bpatchers if present
        t_symbol *clsname = object_classname(obj);
        if (clsname == gensym("jpatcher") || clsname == gensym("patcher") || clsname == gensym("bpatcher")) {
            t_object *subpatcher = NULL;
            if (object_classname_compare(obj, gensym("jpatcher"))) {
                subpatcher = obj;
            } else {
                object_obex_lookup(obj, gensym("#P"), &subpatcher);
                if (!subpatcher) {
                    subpatcher = object_attr_getobj(obj, gensym("patcher"));
                }
            }
            if (subpatcher && subpatcher != patcher) {
                t_object *found = buildspans_find_crucible_recursive(subpatcher, bind_name);
                if (found) return found;
            }
        }
    }
    return NULL;
}

void buildspans_bind_resolve(t_buildspans *x) {
    t_object *patcher = NULL;

    if (x->bind_name == _sym_nothing || x->bind_name == gensym("")) {
        if (x->bound_crucible) {
            object_detach_byptr(x, x->bound_crucible);
            x->bound_crucible = NULL;
        }
        x->bind_attempt_count = 0;
        return;
    }

    object_obex_lookup(x, gensym("#P"), &patcher);
    if (!patcher) {
        // If we can't find the patcher yet, retry in a bit
        if (x->bind_clock) clock_delay(x->bind_clock, 100);
        return;
    }

    // Walk up to top-level root patcher
    t_object *top = patcher;
    t_object *parent = (t_object *)object_attr_getobj(top, gensym("parentpatcher"));
    while (parent) {
        top = parent;
        parent = (t_object *)object_attr_getobj(top, gensym("parentpatcher"));
    }

    x->bind_attempt_count++;

    t_object *obj = buildspans_find_crucible_recursive(top, x->bind_name);
    if (obj) {
        if (x->bound_crucible && x->bound_crucible != obj) {
            object_detach_byptr(x, x->bound_crucible);
        }

        x->bound_crucible = obj;
        object_attach_byptr(x, x->bound_crucible);

        if (x->bind_attempt_count > 1) {
            object_post((t_object *)x, "Re-attempting bind to crucible '%s': SUCCESS (Attempt %ld)", x->bind_name->s_name, x->bind_attempt_count);
        } else {
            object_post((t_object *)x, "Bind to crucible '%s': SUCCESS", x->bind_name->s_name);
        }
        buildspans_log(x, "Bound to crucible: %s", x->bind_name->s_name);

        // Sync worker if both are async
        if (x->async) {
            t_crucible *c = (t_crucible *)obj;
            if (c->async && c->worker) {
                if (x->worker) async_worker_release(x->worker);
                x->worker = c->worker;
                async_worker_retain(x->worker);
                buildspans_log(x, "Synced background worker with bound crucible.");
            }
        }

        x->bind_attempt_count = 0;
        return;
    }

    // Not found
    if (x->bound_crucible) {
        object_detach_byptr(x, x->bound_crucible);
    }
    x->bound_crucible = NULL;

    if (x->bind_attempt_count == 1) {
        object_error((t_object *)x, "Bind to crucible '%s' FAILED immediately. Retrying...", x->bind_name->s_name);
    } else {
        object_warn((t_object *)x, "Re-attempting bind to crucible '%s': STILL FAILED (Attempt %ld)", x->bind_name->s_name, x->bind_attempt_count);
    }

    // If we have a bind name but didn't find the object, retry periodically
    if (x->bind_clock) clock_delay(x->bind_clock, 1000);
}

void buildspans_bind_clock_cb(t_buildspans *x) {
    if (x->bind_name != _sym_nothing && x->bind_name != gensym("") && !x->bound_crucible) {
        buildspans_bind_resolve(x);
    }
}

void buildspans_notify(t_buildspans *x, t_symbol *s, t_symbol *msg, void *sender, void *data) {
    if (msg == gensym("free") && sender == x->bound_crucible) {
        x->bound_crucible = NULL;
        buildspans_log(x, "Bound crucible freed, unbinding.");
    }
}

t_max_err buildspans_attr_set_bind(t_buildspans *x, void *attr, long ac, t_atom *av) {
    if (ac && av) {
        x->bind_name = atom_getsym(av);
        x->bind_attempt_count = 0; // Reset for new name
        buildspans_log(x, "bind attribute set to %s", x->bind_name->s_name);
        buildspans_bind_resolve(x);
    }
    return MAX_ERR_NONE;
}

t_max_err buildspans_attr_set_visualize(t_buildspans *x, void *attr, long ac, t_atom *av) {
    if (ac && av) {
        x->visualize = atom_getlong(av);
        buildspans_log(x, "visualize attribute set to %ld", x->visualize);
    }
    return MAX_ERR_NONE;
}

void buildspans_prune_span(t_buildspans *x, t_symbol *palette_sym, t_symbol *track_sym, long bar_to_keep) {
    if (buildspans_is_task_cancelled(x, x->current_task_seq)) return;
    long num_keys;
    t_symbol **keys;
    dictionary_getkeys(x->building, &num_keys, &keys);
    if (!keys) return;

    // 1. Identify all bars to end.
    long end_count = 0;
    long *bars_to_end_vals = (long *)sysmem_newptr(num_keys * sizeof(long));

    for (long i = 0; i < num_keys; i++) {
        char *key_pal, *key_track, *key_bar, *key_prop;
        if (parse_hierarchical_key(keys[i], &key_pal, &key_track, &key_bar, &key_prop)) {
            if (strcmp(key_pal, palette_sym->s_name) == 0 && strcmp(key_track, track_sym->s_name) == 0 && strcmp(key_prop, "mean") == 0) {
                long bar_val = atol(key_bar);
                if (bar_val != bar_to_keep) {
                    bars_to_end_vals[end_count++] = bar_val;
                }
            }
            sysmem_freeptr(key_pal);
            sysmem_freeptr(key_track);
            sysmem_freeptr(key_bar);
            sysmem_freeptr(key_prop);
        }
    }

    // 2. Finalize the state of the ended bars and then output.
    if (end_count > 0) {
        buildspans_log(x, "Pruning span for track %s on palette %s, keeping bar %ld", track_sym->s_name, palette_sym->s_name, bar_to_keep);
        qsort(bars_to_end_vals, end_count, sizeof(long), compare_longs);

        // Create the list of ended bars
        t_atomarray *ended_span_array = atomarray_new(0, NULL);
        for(long i = 0; i < end_count; ++i) {
            t_atom a; atom_setlong(&a, bars_to_end_vals[i]);
            atomarray_appendatom(ended_span_array, &a);
        }

        // Finalize the span data *before* outputting
        buildspans_log(x, "Finalizing ended span...");
        buildspans_finalize_and_log_span(x, palette_sym, track_sym, ended_span_array);

        // Validate and output the finalized data
        if (buildspans_validate_span_before_output(x, palette_sym, track_sym, ended_span_array)) {
            long span_size;
            t_atom *span_atoms;
            atomarray_getatoms(ended_span_array, &span_size, &span_atoms);

            double lowest_mean = -1.0;
            if (span_size > 0) {
                for (long i = 0; i < span_size; i++) {
                    long bar_ts = atom_getlong(&span_atoms[i]);
                    char bar_str[32]; snprintf(bar_str, 32, "%ld", bar_ts);
                    t_symbol *bar_sym = gensym(bar_str);
                    t_symbol *mean_key = generate_hierarchical_key(palette_sym, track_sym, bar_sym, gensym("mean"));
                    t_atom *m_atoms = NULL;
                    long m_count = 0;
                    t_atomarray *m_aa = NULL;
                    t_atom m_atom;
                    if (dictionary_getatomarray(x->building, mean_key, (t_object **)&m_aa) == MAX_ERR_NONE && m_aa) {
                        atomarray_getatoms(m_aa, &m_count, &m_atoms);
                    } else if (dictionary_getatom(x->building, mean_key, &m_atom) == MAX_ERR_NONE) {
                        m_atoms = &m_atom;
                        m_count = 1;
                    }
                    if (m_count > 0) {
                        double bar_mean = atom_getfloat(m_atoms);
                        if (lowest_mean == -1.0 || bar_mean < lowest_mean) {
                            lowest_mean = bar_mean;
                        }
                    }
                }
            }
            double final_rating = (lowest_mean != -1.0) ? (lowest_mean * span_size) : 0.0;

            long track_num_to_output;
            sscanf(track_sym->s_name, "%ld-", &track_num_to_output);

            // Write log if log is enabled
            if (x->log) {
                write_multibar_negative_rating_log(x, palette_sym, track_sym, ended_span_array, final_rating);
            }

            // Outlet 3: Detailed span data
            buildspans_output_span_data(x, palette_sym, track_sym, ended_span_array);

            // Outlet 2: Track number
            t_atom t_atom_track;
            atom_setlong(&t_atom_track, track_num_to_output);
            if (x->bound_crucible) {
                crucible_anything((t_crucible *)x->bound_crucible, gensym("track"), 1, &t_atom_track);
            } else {
                if (!x->async || systhread_ismainthread()) {
                    outlet_anything(x->track_outlet, gensym("track"), 1, &t_atom_track);
                } else {
                    defer(x, (method)buildspans_defer_output, gensym("track"), 1, &t_atom_track);
                }
            }

            // Outlet 1: Span list
            if (x->bound_crucible) {
                crucible_anything((t_crucible *)x->bound_crucible, gensym("span"), (short)span_size, span_atoms);
            } else {
                if (!x->async || systhread_ismainthread()) {
                    outlet_anything(x->span_outlet, gensym("span"), (short)span_size, span_atoms);
                } else {
                    defer(x, (method)buildspans_defer_output, gensym("span"), (short)span_size, span_atoms);
                }
            }
        }
        object_free(ended_span_array);
    }

    // 4. Delete keys for ended bars.
    t_symbol **keys_to_delete = (t_symbol**)sysmem_newptr(num_keys * sizeof(t_symbol*));
    long delete_count = 0;
    for (long j = 0; j < num_keys; j++) {
        char *key_pal, *key_track, *key_bar, *key_prop;
        if (parse_hierarchical_key(keys[j], &key_pal, &key_track, &key_bar, &key_prop)) {
            if (strcmp(key_pal, palette_sym->s_name) == 0 && strcmp(key_track, track_sym->s_name) == 0) {
                long bar_val = atol(key_bar);
                if (bar_val != bar_to_keep) {
                    keys_to_delete[delete_count++] = keys[j];
                }
            }
            sysmem_freeptr(key_pal);
            sysmem_freeptr(key_track);
            sysmem_freeptr(key_bar);
            sysmem_freeptr(key_prop);
        }
    }
    for(long i=0; i<delete_count; ++i) {
        dictionary_deleteentry(x->building, keys_to_delete[i]);
    }

    sysmem_freeptr(keys_to_delete);
    sysmem_freeptr(bars_to_end_vals);
    sysmem_freeptr(keys);

    char bar_to_keep_str[32];
    snprintf(bar_to_keep_str, 32, "%ld", bar_to_keep);
    buildspans_log(x, "Resetting kept bar...");
    buildspans_reset_bar_to_standalone(x, palette_sym, track_sym, gensym(bar_to_keep_str));

    // Since a span was ended, we need to schedule a cleanup check.
    if (end_count > 0) {
        char deferred_key[256];
        snprintf(deferred_key, 256, "%s::%s", palette_sym->s_name, track_sym->s_name);
        dictionary_appendsym(x->tracks_ended_in_current_event, gensym(deferred_key), 0);
    }

    buildspans_visualize_memory(x);
}


void buildspans_reset_bar_to_standalone(t_buildspans *x, t_symbol *palette_sym, t_symbol *track_sym, t_symbol *bar_sym) {
    // Update rating to mean
    t_symbol *mean_key = generate_hierarchical_key(palette_sym, track_sym, bar_sym, gensym("mean"));
    t_atom *m_atoms = NULL;
    long m_count = 0;
    t_atomarray *m_aa = NULL;
    t_atom m_atom;
    if (dictionary_getatomarray(x->building, mean_key, (t_object **)&m_aa) == MAX_ERR_NONE && m_aa) {
        atomarray_getatoms(m_aa, &m_count, &m_atoms);
    } else if (dictionary_getatom(x->building, mean_key, &m_atom) == MAX_ERR_NONE) {
        m_atoms = &m_atom;
        m_count = 1;
    }

    if (m_count > 0) {
        double mean_val = atom_getfloat(m_atoms);

        t_symbol *rating_key = generate_hierarchical_key(palette_sym, track_sym, bar_sym, gensym("rating"));
        if (dictionary_hasentry(x->building, rating_key)) dictionary_deleteentry(x->building, rating_key);
        dictionary_appendfloat(x->building, rating_key, mean_val);
        buildspans_log(x, "%s %.2f", rating_key->s_name, mean_val);
    }

    // Update span to be only itself
    t_atomarray *new_span_array = atomarray_new(0, NULL);
    t_atom new_bar_atom;
    atom_setlong(&new_bar_atom, atol(bar_sym->s_name));
    atomarray_appendatom(new_span_array, &new_bar_atom);

    t_atom new_span_atom;
    atom_setobj(&new_span_atom, (t_object *)new_span_array);

    t_symbol *span_key = generate_hierarchical_key(palette_sym, track_sym, bar_sym, gensym("span"));
    dictionary_appendatom(x->building, span_key, &new_span_atom);

    char *span_str = atomarray_to_string(new_span_array);
    if (span_str) {
        buildspans_log(x, "%s %s", span_key->s_name, span_str);
        sysmem_freeptr(span_str);
    }
}


void buildspans_finalize_and_log_span(t_buildspans *x, t_symbol *palette_sym, t_symbol *track_sym, t_atomarray *span_array) {
    if (!span_array) return;

    long span_size = 0;
    t_atom *span_atoms = NULL;
    atomarray_getatoms(span_array, &span_size, &span_atoms);
    if (span_size == 0) return;

    // 1. Calculate the final rating for this span.
    double lowest_mean = -1.0;
    for (long i = 0; i < span_size; i++) {
        long bar_ts = atom_getlong(&span_atoms[i]);
        char bar_str[32]; snprintf(bar_str, 32, "%ld", bar_ts);
        t_symbol *bar_sym = gensym(bar_str);
        t_symbol *mean_key = generate_hierarchical_key(palette_sym, track_sym, bar_sym, gensym("mean"));
        t_atom *m_atoms = NULL;
        long m_count = 0;
        t_atomarray *m_aa = NULL;
        t_atom m_atom;
        if (dictionary_getatomarray(x->building, mean_key, (t_object **)&m_aa) == MAX_ERR_NONE && m_aa) {
            atomarray_getatoms(m_aa, &m_count, &m_atoms);
        } else if (dictionary_getatom(x->building, mean_key, &m_atom) == MAX_ERR_NONE) {
            m_atoms = &m_atom;
            m_count = 1;
        }
        if (m_count > 0) {
            double bar_mean = atom_getfloat(m_atoms);
            if (lowest_mean == -1.0 || bar_mean < lowest_mean) {
                lowest_mean = bar_mean;
            }
        }
    }
    double final_rating = (lowest_mean != -1.0) ? (lowest_mean * span_size) : 0.0;

    // 2. Back-propagate the final rating and span to all bars in the span.
    t_atom rating_atom;
    atom_setfloat(&rating_atom, final_rating);
    char *span_str = atomarray_to_string(span_array);

    for (long i = 0; i < span_size; i++) {
        long bar_ts = atom_getlong(&span_atoms[i]);
        char bar_str[32]; snprintf(bar_str, 32, "%ld", bar_ts);
        t_symbol *bar_sym = gensym(bar_str);

        t_symbol *rating_key = generate_hierarchical_key(palette_sym, track_sym, bar_sym, gensym("rating"));
        if(dictionary_hasentry(x->building, rating_key)) dictionary_deleteentry(x->building, rating_key);
        dictionary_appendatom(x->building, rating_key, &rating_atom);
        buildspans_log(x, "%s %.2f", rating_key->s_name, final_rating);

        // Create a deep copy for each bar to ensure no shared ownership
        t_atomarray *span_copy = atomarray_deep_copy(span_array);
        t_atom span_copy_atom;
        atom_setobj(&span_copy_atom, (t_object *)span_copy);
        t_symbol *span_key = generate_hierarchical_key(palette_sym, track_sym, bar_sym, gensym("span"));
        if (dictionary_hasentry(x->building, span_key)) dictionary_deleteentry(x->building, span_key);
        dictionary_appendatom(x->building, span_key, &span_copy_atom);

        if (span_str) {
            buildspans_log(x, "%s %s", span_key->s_name, span_str);
        }
    }
    if (span_str) sysmem_freeptr(span_str);
}


int buildspans_deferred_rating_check(t_buildspans *x, t_symbol *palette_sym, t_symbol *track_sym, long last_bar_timestamp) {
    long num_keys;
    t_symbol **keys;
    dictionary_getkeys(x->building, &num_keys, &keys);
    if (!keys) return 0;

    // 1. Get all bars for the track AND PALETTE
    long bar_count = 0;
    long *bar_timestamps = (long *)sysmem_newptr(num_keys * sizeof(long));
    for (long i = 0; i < num_keys; i++) {
        char *key_pal, *key_track, *key_bar, *key_prop;
        if (parse_hierarchical_key(keys[i], &key_pal, &key_track, &key_bar, &key_prop)) {
            if (strcmp(key_pal, palette_sym->s_name) == 0 && strcmp(key_track, track_sym->s_name) == 0 && strcmp(key_prop, "mean") == 0) {
                bar_timestamps[bar_count++] = atol(key_bar);
            }
            sysmem_freeptr(key_pal);
            sysmem_freeptr(key_track);
            sysmem_freeptr(key_bar);
            sysmem_freeptr(key_prop);
        }
    }
    
    int prune_span = 0;
    if (bar_count > 1) {
        // 2. RATING WITH LAST BAR
        double lowest_mean_with = -1.0;
        for (long i = 0; i < bar_count; i++) {
            char bar_str[32]; snprintf(bar_str, 32, "%ld", bar_timestamps[i]);
            t_symbol *bar_sym = gensym(bar_str);
            t_symbol *mean_key = generate_hierarchical_key(palette_sym, track_sym, bar_sym, gensym("mean"));
            t_atom *m_atoms = NULL;
            long m_count = 0;
            t_atomarray *m_aa = NULL;
            t_atom m_atom;
            if (dictionary_getatomarray(x->building, mean_key, (t_object **)&m_aa) == MAX_ERR_NONE && m_aa) {
                atomarray_getatoms(m_aa, &m_count, &m_atoms);
            } else if (dictionary_getatom(x->building, mean_key, &m_atom) == MAX_ERR_NONE) {
                m_atoms = &m_atom;
                m_count = 1;
            }
            if (m_count > 0) {
                double bar_mean = atom_getfloat(m_atoms);
                if (lowest_mean_with == -1.0 || bar_mean < lowest_mean_with) {
                    lowest_mean_with = bar_mean;
                }
            }
        }
        double rating_with = lowest_mean_with * bar_count;

        // 3. RATING WITHOUT LAST BAR
        double lowest_mean_without = -1.0;
        long bars_without_count = 0;
        double last_bar_mean = 0.0;
        for (long i = 0; i < bar_count; i++) {
            char bar_str[32]; snprintf(bar_str, 32, "%ld", bar_timestamps[i]);
            t_symbol *bar_sym = gensym(bar_str);
            t_symbol *mean_key = generate_hierarchical_key(palette_sym, track_sym, bar_sym, gensym("mean"));
            t_atom *m_atoms = NULL;
            long m_count = 0;
            t_atomarray *m_aa = NULL;
            t_atom m_atom;
            if (dictionary_getatomarray(x->building, mean_key, (t_object **)&m_aa) == MAX_ERR_NONE && m_aa) {
                atomarray_getatoms(m_aa, &m_count, &m_atoms);
            } else if (dictionary_getatom(x->building, mean_key, &m_atom) == MAX_ERR_NONE) {
                m_atoms = &m_atom;
                m_count = 1;
            }
            if (m_count > 0) {
                double bar_mean = atom_getfloat(m_atoms);
                if (bar_timestamps[i] == last_bar_timestamp) {
                    last_bar_mean = bar_mean;
                } else {
                     if (lowest_mean_without == -1.0 || bar_mean < lowest_mean_without) {
                        lowest_mean_without = bar_mean;
                    }
                    bars_without_count++;
                }
            }
        }
        double rating_without = (bars_without_count > 0) ? (lowest_mean_without * bars_without_count) : 0.0;
        
        if (rating_with < rating_without) {
            buildspans_log(x, "Deferred rating check: Including bar %ld decreased rating (%.2f -> %.2f). Pruning span.", last_bar_timestamp, rating_without, rating_with);
            prune_span = 1;
        } else if (last_bar_mean > rating_with) {
            buildspans_log(x, "Deferred rating check: Bar %ld's individual rating (%.2f) is higher than span rating if included (%.2f). Pruning span.", last_bar_timestamp, last_bar_mean, rating_with);
            prune_span = 1;
        } else {
            buildspans_log(x, "Deferred rating check: Including bar %ld did not decrease rating (%.2f -> %.2f) and is not better on its own. Continuing span.", last_bar_timestamp, rating_without, rating_with);
        }

        if (prune_span) {
            buildspans_prune_span(x, palette_sym, track_sym, last_bar_timestamp);
        }
    }
    
    sysmem_freeptr(bar_timestamps);
    sysmem_freeptr(keys);
    return prune_span;
}

// New comparison function for doubles
int compare_doubles(const void *a, const void *b) {
    double da = *(const double *)a;
    double db = *(const double *)b;
    return (da > db) - (da < db);
}

double find_next_offset(t_buildspans *x, t_symbol *palette_sym, long track_num_to_check, double offset_val_to_check) {
    long num_keys;
    t_symbol **keys;
    dictionary_getkeys(x->building, &num_keys, &keys);
    if (!keys) return -1.0;

    t_dictionary *unique_offsets_dict = dictionary_new();
    char track_prefix[32];
    snprintf(track_prefix, 32, "%ld-", track_num_to_check);

    for (long i = 0; i < num_keys; i++) {
        char *pal_str, *track_str, *bar_str, *prop_str;
        if (parse_hierarchical_key(keys[i], &pal_str, &track_str, &bar_str, &prop_str)) {
            if (strcmp(pal_str, palette_sym->s_name) == 0 && strncmp(track_str, track_prefix, strlen(track_prefix)) == 0 && strcmp(prop_str, "offset") == 0) {
                t_atom *off_atoms = NULL;
                long off_count = 0;
                t_atomarray *off_aa = NULL;
                t_atom off_atom;
                if (dictionary_getatomarray(x->building, keys[i], (t_object **)&off_aa) == MAX_ERR_NONE && off_aa) {
                    atomarray_getatoms(off_aa, &off_count, &off_atoms);
                } else if (dictionary_getatom(x->building, keys[i], &off_atom) == MAX_ERR_NONE) {
                    off_atoms = &off_atom;
                    off_count = 1;
                }
                if (off_count > 0) {
                    double current_offset = atom_getfloat(off_atoms);
                    char offset_key_str[64];
                    snprintf(offset_key_str, 64, "%.2f", current_offset);
                    dictionary_appendfloat(unique_offsets_dict, gensym(offset_key_str), current_offset);
                }
            }
            sysmem_freeptr(pal_str);
            sysmem_freeptr(track_str);
            sysmem_freeptr(bar_str);
            sysmem_freeptr(prop_str);
        }
    }
    if (keys) sysmem_freeptr(keys);

    long num_unique_offsets;
    t_symbol **offset_keys;
    dictionary_getkeys(unique_offsets_dict, &num_unique_offsets, &offset_keys);
    if (!offset_keys) {
        object_free(unique_offsets_dict);
        return -1.0;
    }

    double *offsets = (double *)sysmem_newptr(num_unique_offsets * sizeof(double));
    for(long i = 0; i < num_unique_offsets; i++) {
        t_atom a;
        dictionary_getatom(unique_offsets_dict, offset_keys[i], &a);
        offsets[i] = atom_getfloat(&a);
    }
    
    qsort(offsets, num_unique_offsets, sizeof(double), compare_doubles);
    
    double next_offset_time = -1.0;
    for (long i = 0; i < num_unique_offsets; i++) {
        if (offsets[i] > offset_val_to_check) {
            next_offset_time = offsets[i];
            break;
        }
    }

    sysmem_freeptr(offsets);
    sysmem_freeptr(offset_keys);
    object_free(unique_offsets_dict);

    return next_offset_time;
}

int buildspans_validate_span_before_output(t_buildspans *x, t_symbol *palette_sym, t_symbol *track_sym, t_atomarray *span_to_output) {
    // Validation is bypassed to return 1 unconditionally (supporting valid negative bars without removing valid spans)
    return 1;

    long track_num;
    double offset_val = 0.0;

    if (sscanf(track_sym->s_name, "%ld-", &track_num) != 1) {
        return 0; // Should not happen
    }

    // Retrieve actual double offset from dictionary (pick first bar)
    long ac_span; t_atom *av_span;
    atomarray_getatoms(span_to_output, &ac_span, &av_span);
    if (ac_span > 0) {
        long first_bar_ts = atom_getlong(av_span);
        char bar_str[32]; snprintf(bar_str, 32, "%ld", first_bar_ts);
        t_symbol *offset_key = generate_hierarchical_key(palette_sym, track_sym, gensym(bar_str), gensym("offset"));
        t_atom a;
        if (dictionary_getatom(x->building, offset_key, &a) == MAX_ERR_NONE) {
            offset_val = atom_getfloat(&a);
        } else {
            // Fallback: parse from symbol if dictionary lookup fails
            const char *offset_part = strchr(track_sym->s_name, '-');
            if (offset_part) offset_val = (double)atol(offset_part+1);
        }
    }

    double next_offset = find_next_offset(x, palette_sym, track_num, offset_val);

    double earliest_absolute = -1.0;
    double latest_absolute = -1.0;

    long span_size;
    t_atom *span_atoms;
    atomarray_getatoms(span_to_output, &span_size, &span_atoms);

    for (long i = 0; i < span_size; i++) {
        long bar_ts = atom_getlong(&span_atoms[i]);
        char bar_str[32];
        snprintf(bar_str, 32, "%ld", bar_ts);
        t_symbol *bar_sym = gensym(bar_str);
        t_symbol *absolutes_key = generate_hierarchical_key(palette_sym, track_sym, bar_sym, gensym("absolutes"));

        t_atom *av = NULL;
        long ac = 0;
        t_atomarray *aa = NULL;
        t_atom a;
        if (dictionary_getatomarray(x->building, absolutes_key, (t_object **)&aa) == MAX_ERR_NONE && aa) {
            atomarray_getatoms(aa, &ac, &av);
        } else if (dictionary_getatom(x->building, absolutes_key, &a) == MAX_ERR_NONE) {
            av = &a;
            ac = 1;
        }

        if (ac > 0) {
            for (long k = 0; k < ac; k++) {
                double current_time = atom_getfloat(av + k);
                if (earliest_absolute == -1.0 || current_time < earliest_absolute) {
                    earliest_absolute = current_time;
                }
                if (latest_absolute == -1.0 || current_time > latest_absolute) {
                    latest_absolute = current_time;
                }
            }
        }
    }

    if (earliest_absolute == -1.0) { // No notes in span
        buildspans_log(x, "Validation: Span %s has no notes. Aborting.", track_sym->s_name);
        return 0;
    }

    double looped_offset_val = buildspans_calc_looped_absolute(x, offset_val);
    double looped_next_offset = (next_offset != -1.0) ? buildspans_calc_looped_absolute(x, next_offset) : -1.0;

    if (latest_absolute < looped_offset_val) {
        buildspans_log(x, "Validation failed for %s: latest absolute (%.2f) is strictly before its own looped offset (%.2f). Aborting.", track_sym->s_name, latest_absolute, looped_offset_val);
        return 0;
    }

    if (looped_next_offset != -1.0 && earliest_absolute > looped_next_offset) {
        buildspans_log(x, "Validation failed for %s: earliest absolute (%.2f) is after the next looped offset (%.2f). Aborting.", track_sym->s_name, earliest_absolute, looped_next_offset);
        return 0;
    }

    buildspans_log(x, "Validation successful for %s (earliest: %.2f, latest: %.2f, looped_offset: %.2f, looped_next_offset: %.2f)", track_sym->s_name, earliest_absolute, latest_absolute, looped_offset_val, looped_next_offset);
    return 1;
}

void buildspans_output_span_data(t_buildspans *x, t_symbol *palette_sym, t_symbol *track_sym, t_atomarray *span_atom_array) {
    if (buildspans_is_task_cancelled(x, x->current_task_seq)) return;
    if (!span_atom_array) return;

    long track_num_to_output;
    if (sscanf(track_sym->s_name, "%ld-", &track_num_to_output) != 1) {
        return; // Failed to parse track number
    }

    long span_size;
    t_atom *span_atoms;
    atomarray_getatoms(span_atom_array, &span_size, &span_atoms);

    const char* properties_to_output[] = {
        "absolutes", "scores", "mean", "offset", "palette", "rating", "span"
    };
    int num_properties = sizeof(properties_to_output) / sizeof(properties_to_output[0]);

    for (long i = 0; i < span_size; i++) {
        long bar_ts = atom_getlong(&span_atoms[i]);
        char bar_str[32];
        snprintf(bar_str, 32, "%ld", bar_ts);
        t_symbol *bar_sym = gensym(bar_str);

        for (int j = 0; j < num_properties; j++) {
            t_symbol *prop_sym = gensym(properties_to_output[j]);
            t_symbol *hierarchical_key = generate_hierarchical_key(palette_sym, track_sym, bar_sym, prop_sym);

            t_atom *av = NULL;
            long ac = 0;
            t_atomarray *aa = NULL;
            t_atom a;

            if (dictionary_getatomarray(x->building, hierarchical_key, (t_object **)&aa) == MAX_ERR_NONE && aa) {
                atomarray_getatoms(aa, &ac, &av);
            } else if (dictionary_getatom(x->building, hierarchical_key, &a) == MAX_ERR_NONE) {
                av = &a;
                ac = 1;
            }

            if (ac > 0) {
                char output_key_str[256];
                snprintf(output_key_str, 256, "%ld::%s::%s", track_num_to_output, bar_sym->s_name, prop_sym->s_name);
                t_symbol *output_key_sym = gensym(output_key_str);
                if (x->bound_crucible) {
                    crucible_anything((t_crucible *)x->bound_crucible, output_key_sym, (short)ac, av);
                } else {
                    if (!x->async || systhread_ismainthread()) {
                        outlet_anything(x->out_bar_data, output_key_sym, (short)ac, av);
                    } else {
                        t_atom *new_argv = (t_atom *)sysmem_newptr((ac + 1) * sizeof(t_atom));
                        if (new_argv) {
                            atom_setsym(new_argv, output_key_sym);
                            for (int k = 0; k < ac; k++) new_argv[k+1] = av[k];
                            defer(x, (method)buildspans_defer_output, gensym("bar_data"), (short)(ac + 1), new_argv);
                            sysmem_freeptr(new_argv);
                        }
                    }
                }
            }
        }
    }
}


void buildspans_cleanup_track_offset_if_needed(t_buildspans *x, t_symbol *palette_sym, t_symbol *track_offset_sym) {
    // 1. Parse the track and offset from the input symbol.
    long track_num_to_check;
    double offset_val_to_check = 0.0;

    if (sscanf(track_offset_sym->s_name, "%ld-", &track_num_to_check) != 1) {
        return; // Not a valid track-offset symbol
    }

    long num_keys;
    t_symbol **keys;
    dictionary_getkeys(x->building, &num_keys, &keys);
    if (!keys) return;

    // Retrieve actual double offset from dictionary for this track AND palette
    for (long i = 0; i < num_keys; i++) {
        char *pal_str, *track_str, *bar_str, *prop_str;
        if (parse_hierarchical_key(keys[i], &pal_str, &track_str, &bar_str, &prop_str)) {
            if (strcmp(pal_str, palette_sym->s_name) == 0 && strcmp(track_str, track_offset_sym->s_name) == 0 && strcmp(prop_str, "offset") == 0) {
                t_atom a;
                dictionary_getatom(x->building, keys[i], &a);
                offset_val_to_check = atom_getfloat(&a);
                sysmem_freeptr(pal_str);
                sysmem_freeptr(track_str);
                sysmem_freeptr(bar_str);
                sysmem_freeptr(prop_str);
                break;
            }
            sysmem_freeptr(pal_str);
            sysmem_freeptr(track_str);
            sysmem_freeptr(bar_str);
            sysmem_freeptr(prop_str);
        }
    }

    buildspans_log(x, "--- Cleanup Check for %s on palette %s (Precision offset: %.2f) ---", track_offset_sym->s_name, palette_sym->s_name, offset_val_to_check);

    // --- Single Pass ---
    // In one loop, we will:
    // a) Find the oldest absolute time for the specific track-offset we are checking.
    // b) Collect all keys that belong to the track-offset to be checked.
    double oldest_absolute_time = -1.0;
    t_symbol **keys_to_delete = (t_symbol **)sysmem_newptr(num_keys * sizeof(t_symbol *));
    long delete_count = 0;
    
    for (long i = 0; i < num_keys; i++) {
        char *pal_str, *track_str, *bar_str, *prop_str;
        if (parse_hierarchical_key(keys[i], &pal_str, &track_str, &bar_str, &prop_str)) {
            // Check if it's the specific track-offset and palette we are interested in
            if (strcmp(pal_str, palette_sym->s_name) == 0 && strcmp(track_str, track_offset_sym->s_name) == 0) {
                // b) Collect this key for potential deletion
                keys_to_delete[delete_count++] = keys[i];

                // a) Find the oldest absolute time
                if (strcmp(prop_str, "absolutes") == 0) {
                    t_atom *av = NULL;
                    long ac = 0;
                    t_atomarray *aa = NULL;
                    t_atom a;
                    if (dictionary_getatomarray(x->building, keys[i], (t_object **)&aa) == MAX_ERR_NONE && aa) {
                        atomarray_getatoms(aa, &ac, &av);
                    } else if (dictionary_getatom(x->building, keys[i], &a) == MAX_ERR_NONE) {
                        av = &a;
                        ac = 1;
                    }
                    for (long k = 0; k < ac; k++) {
                        double current_time = atom_getfloat(av + k);
                        if (oldest_absolute_time == -1.0 || current_time < oldest_absolute_time) {
                            oldest_absolute_time = current_time;
                        }
                    }
                }
            }

            sysmem_freeptr(pal_str);
            sysmem_freeptr(track_str);
            sysmem_freeptr(bar_str);
            sysmem_freeptr(prop_str);
        }
    }

    // --- Process Collected Data ---
    
    // 2. Find the next chronological offset from our unique set.
    double next_offset_time = find_next_offset(x, palette_sym, track_num_to_check, offset_val_to_check);

    if (next_offset_time == -1.0) {
        buildspans_log(x, "Cleanup: No subsequent offset found for track %ld on palette %s. No action taken.", track_num_to_check, palette_sym->s_name);
        goto cleanup;
    }
    buildspans_log(x, "Cleanup: Next offset for track %ld on palette %s is %.2f.", track_num_to_check, palette_sym->s_name, next_offset_time);

    if (oldest_absolute_time == -1.0) {
        buildspans_log(x, "Cleanup: No absolute timestamps found for %s on palette %s. No action taken.", track_offset_sym->s_name, palette_sym->s_name);
        goto cleanup;
    }
    buildspans_log(x, "Cleanup: Oldest absolute time for %s on palette %s is %.2f.", track_offset_sym->s_name, palette_sym->s_name, oldest_absolute_time);

    // 3. Compare and potentially delete.
    if (oldest_absolute_time >= next_offset_time) {
        buildspans_log(x, "Cleanup: Condition met (%.2f >= %.2f). Deleting %ld keys for %s on palette %s.", oldest_absolute_time, next_offset_time, delete_count, track_offset_sym->s_name, palette_sym->s_name);

        for (long i = 0; i < delete_count; i++) {
            dictionary_deleteentry(x->building, keys_to_delete[i]);
        }
        buildspans_visualize_memory(x);
    } else {
        buildspans_log(x, "Cleanup: Condition not met (%.2f < %.2f). No action taken.", oldest_absolute_time, next_offset_time);
    }

cleanup:
    sysmem_freeptr(keys_to_delete);
    if(keys) sysmem_freeptr(keys);
}
