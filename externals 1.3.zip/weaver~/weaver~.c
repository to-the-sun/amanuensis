#include "ext.h"
#include "ext_obex.h"
#include "ext_hashtab.h"
#include "ext_buffer.h"
#include "ext_critical.h"
#include "ext_systhread.h"
#include "ext_dictionary.h"
#include "ext_dictobj.h"
#include "ext_atomarray.h"
#include "z_dsp.h"
#include "../shared/logging.h"
#include "../shared/crossfade.h"
#include "../shared/visualize.h"

#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <ctype.h>

typedef struct _bar_cache {
    double value;
    t_symbol *sym;
} t_bar_cache;

#define TYPE_DATA 0
#define TYPE_SWEEP 1
#define TYPE_LOOP 2

typedef struct _fifo_entry {
    t_bar_cache bar;
    double rel_time;
    double range_end; // For SWEEP
    long type; // 0 for DATA, 1 for SWEEP
    long track_id;
    int song_loop;
} t_fifo_entry;

typedef struct _rating_entry {
    double timestamp;
    double rating;
} t_rating_entry;

#define MAX_ROLLING_RATINGS 65536

typedef struct _weaver_track {
    t_crossfade_state xf;
    t_symbol *palette[2];
    double offset[2];
    double dict_offset[2];
    double rating[2];
    double slot_most_negative[2];
    double pending_most_negative;
    double track_most_negative;
    double control;
    int busy;
    t_buffer_ref *src_refs[2];
    t_buffer_ref *dest_ref;
    long dest_found;
    long dest_warn_sent;
    long src_found[2];
    long src_error_sent[2];
    double track_length;
    double last_track_scan;
    long long last_f_dest;
    double last_visualize_ms;

    // Thread-safe state handover
    t_symbol *pending_palette;
    double pending_offset;
    t_symbol *pending_bar_symbol;
    int has_pending_data;
    int waiting_for_dict;

    // Visualization state
    double viz_f1;
    double viz_f2;
    t_symbol *viz_palette;
    double viz_offset;
    t_symbol *viz_bar_symbol;
    double viz_ms;
    int viz_dirty;
    int viz_trigger_dirty;
    int dirty_dest;
    double viz_control;
    double viz_track_length;

    int last_busy_logged;
    int viz_busy;
    double last_viz_sent_ms;
    double viz_absolute_ms;
    double pending_rating;
    double gain[2];
    double viz_gain[2];

} t_weaver_track;

#define MAX_WEAVER_TRACKS 256

typedef enum {
    WEAVER_LOG_MSG,
    WEAVER_LOG_DIRTY,
    WEAVER_LOG_FINISH
} t_weaver_log_type;

typedef struct _weaver_log_entry {
    t_weaver_log_type type;
    char message[256];
    t_buffer_obj *buffer;
    void *job;
    struct _weaver_log_entry *next;
} t_weaver_log_entry;

typedef struct _weaver_log_queue {
    t_weaver_log_entry *head;
    t_weaver_log_entry *tail;
    t_critical lock;
} t_weaver_log_queue;

typedef struct _weaver_consolidate_job {
    struct _weaver *x;
    t_symbol *audio_dict_name;
    t_symbol *poly_prefix;
    double bar_length;
    double low_ms;
    double high_ms;
} t_weaver_consolidate_job;

struct _weaver;
typedef struct _weaver t_weaver;

void *weaver_consolidate_worker(t_weaver_consolidate_job *job);

typedef struct _weaver {
    t_pxobject t_obj;
    t_symbol *poly_prefix;
    long log;
    long visualize;
    void *log_outlet;
    void *bang_outlet;
    void *loop_outlet;
    t_buffer_ref *bar_buffer_ref;
    t_buffer_ref *track1_ref;

    t_symbol *audio_dict_name;
    double last_scan_val;
    double last_ramp_in_val;
    t_fifo_entry hit_bars[4096];
    int fifo_head;
    int fifo_tail;
    t_qelem *audio_qelem;
    t_critical lock;
    t_weaver_log_queue log_queue;
    t_systhread consolidate_thread;
    int consolidate_running;
    int consolidate_stop;

    long max_tracks;
    t_weaver_track *track_cache[MAX_WEAVER_TRACKS];
    long track_cache_count;
    void *proxy;
    long proxy_id;
    long bar_found;
    long bar_error_sent;
    long dict_found;
    long dict_error_sent;
    long poly_found;
    long poly_warn_sent;

    t_hashtab *track_states;
    double low_ms;
    double high_ms;

    double last_viz_check_ms;
    double most_negative_bar;
    long dynamic_gain;
    double lowest_rating_seen;

    // Rolling rating window fields
    double song_length;
    double accumulated_ms;
    t_rating_entry *rolling_ratings;
    int rolling_head;
    int rolling_tail;
} t_weaver;

int compare_doubles(const void *a, const void *b) {
    double arg1 = *(const double*)a;
    double arg2 = *(const double*)b;
    if (arg1 < arg2) return -1;
    if (arg1 > arg2) return 1;
    return 0;
}

void weaver_add_rating(t_weaver *x, double timestamp, double rating) {
    if (!x->rolling_ratings) return;
    int next_tail = (x->rolling_tail + 1) % MAX_ROLLING_RATINGS;
    if (next_tail == x->rolling_head) {
        // Buffer full, advance head to overwrite oldest
        x->rolling_head = (x->rolling_head + 1) % MAX_ROLLING_RATINGS;
    }
    x->rolling_ratings[x->rolling_tail].timestamp = timestamp;
    x->rolling_ratings[x->rolling_tail].rating = rating;
    x->rolling_tail = next_tail;
}

void weaver_expire_ratings(t_weaver *x, double current_time) {
    if (!x->rolling_ratings) return;
    double limit = current_time - x->song_length;
    while (x->rolling_head != x->rolling_tail) {
        if (x->rolling_ratings[x->rolling_head].timestamp < limit) {
            x->rolling_head = (x->rolling_head + 1) % MAX_ROLLING_RATINGS;
        } else {
            break;
        }
    }
}

double weaver_get_rolling_min_rating(t_weaver *x) {
    weaver_expire_ratings(x, x->accumulated_ms);
    if (!x->rolling_ratings || x->rolling_head == x->rolling_tail) {
        return 0.0;
    }
    double min_val = 0.0;
    int idx = x->rolling_head;
    int first = 1;
    while (idx != x->rolling_tail) {
        double r = x->rolling_ratings[idx].rating;
        if (first) {
            min_val = r;
            first = 0;
        } else if (r < min_val) {
            min_val = r;
        }
        idx = (idx + 1) % MAX_ROLLING_RATINGS;
    }
    return min_val;
}

void weaver_recalculate_song_length(t_weaver *x) {
    double max_len = 0.0;
    for (long t = 0; t < x->track_cache_count; t++) {
        if (x->track_cache[t] && x->track_cache[t]->track_length > max_len) {
            max_len = x->track_cache[t]->track_length;
        }
    }
    x->song_length = max_len;
}

void weaver_update_most_negative_bar(t_weaver *x);
void *weaver_new(t_symbol *s, long argc, t_atom *argv);
void weaver_free(t_weaver *x);
void weaver_list(t_weaver *x, t_symbol *s, long argc, t_atom *argv);
void weaver_tracks(t_weaver *x, long n);
t_max_err weaver_attr_set_visualize(t_weaver *x, void *attr, long ac, t_atom *av);
t_max_err weaver_attr_set_log(t_weaver *x, void *attr, long ac, t_atom *av);
t_max_err weaver_attr_set_dynamic_gain(t_weaver *x, void *attr, long ac, t_atom *av);
t_max_err weaver_attr_set_low(t_weaver *x, void *attr, long ac, t_atom *av);
t_max_err weaver_attr_set_high(t_weaver *x, void *attr, long ac, t_atom *av);
t_max_err weaver_notify(t_weaver *x, t_symbol *s, t_symbol *msg, void *sender, void *data);
void weaver_assist(t_weaver *x, void *b, long m, long a, char *s);
void weaver_log(t_weaver *x, const char *fmt, ...);
void weaver_queue_log(t_weaver *x, const char *fmt, ...);
void weaver_queue_dirty(t_weaver *x, t_buffer_obj *b);
void weaver_queue_finish(t_weaver *x, t_weaver_consolidate_job *job);
void weaver_update_track_metadata(t_weaver *x, t_atom_long track, t_symbol *palette, double bar_ms, double offset_ms, t_symbol *bar_symbol, double absolute_ms, double rating, int found_in_dict);
void weaver_check_attachments(t_weaver *x);
double weaver_get_bar_length(t_weaver *x);
void weaver_dsp64(t_weaver *x, t_object *dsp64, short *count, double samplerate, long maxvectorsize, long flags);
void weaver_perform64(t_weaver *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam);
void weaver_process_vector(t_weaver *x, double *ramp_in, long sampleframes);
void weaver_audio_qtask(t_weaver *x);

void *weaver_consolidate_worker(t_weaver_consolidate_job *job) {
    t_weaver *x = job->x;
    t_dictionary *dict = dictobj_findregistered_retain(job->audio_dict_name);
    if (!dict) {
        weaver_queue_log(x, "Consolidate failed: dictionary %s not found", job->audio_dict_name->s_name);
        x->consolidate_running = 0;
        weaver_queue_finish(x, job);
        return NULL;
    }

    // 1. Determine Song and Track Lengths from Transcript
    double song_length = 0;
    long num_tracks_in_dict = 0;
    t_symbol **track_keys = NULL;
    dictionary_getkeys(dict, &num_tracks_in_dict, &track_keys);

    double local_most_negative = 0.0;
    for (long i = 0; i < num_tracks_in_dict; i++) {
        t_dictionary *track_dict = NULL;
        if (dictionary_getdictionary(dict, track_keys[i], (t_object **)&track_dict) == MAX_ERR_NONE && track_dict) {
            long num_bars = 0;
            t_symbol **bar_keys = NULL;
            dictionary_getkeys(track_dict, &num_bars, &bar_keys);
            for (long j = 0; j < num_bars; j++) {
                double bar_ts = atof(bar_keys[j]->s_name);
                if (bar_ts < local_most_negative) {
                    local_most_negative = bar_ts;
                }
            }
            if (bar_keys) sysmem_freeptr(bar_keys);
        }
    }

    if (local_most_negative > 0.0) local_most_negative = 0.0;

    critical_enter(x->lock);
    x->most_negative_bar = local_most_negative;
    // Reset all track lengths first
    for (long t = 0; t < x->track_cache_count; t++) {
        x->track_cache[t]->track_length = 0.0;
    }

    for (long i = 0; i < num_tracks_in_dict; i++) {
        t_dictionary *track_dict = NULL;
        long track_id = atol(track_keys[i]->s_name);
        if (track_id > 0 && track_id <= x->track_cache_count &&
            dictionary_getdictionary(dict, track_keys[i], (t_object **)&track_dict) == MAX_ERR_NONE && track_dict) {

            double track_length = 0;
            long num_bars = 0;
            t_symbol **bar_keys = NULL;
            dictionary_getkeys(track_dict, &num_bars, &bar_keys);
            for (long j = 0; j < num_bars; j++) {
                double bar_ts = atof(bar_keys[j]->s_name);
                if (bar_ts + job->bar_length > track_length) {
                    track_length = bar_ts + job->bar_length;
                }
            }
            if (bar_keys) sysmem_freeptr(bar_keys);

            double absolute_track_length = track_length - local_most_negative;
            x->track_cache[track_id - 1]->track_length = absolute_track_length;
            if (absolute_track_length > song_length) song_length = absolute_track_length;
        }
    }
    x->song_length = song_length;
    critical_exit(x->lock);

    weaver_queue_log(x, "Consolidate started (Worker: %p). Song length: %.2f ms, Bar length: %.2f ms", systhread_self(), song_length, job->bar_length);

    // 2. Simulated Ramp Processing
    const int vector_size = 512;
    double sr = sys_getsr();
    if (sr <= 0) sr = 44100.0;
    double ms_per_vector = (double)vector_size * 1000.0 / sr;

    double simulated_ramp[512];
    x->last_scan_val = -1.0;

    // Reset track internal states for consolidation run
    critical_enter(x->lock);
    for (long t = 0; t < x->track_cache_count; t++) {
        t_weaver_track *tr = x->track_cache[t];
        tr->last_track_scan = -1.0;
        tr->last_f_dest = -1;
        tr->busy = 0;
        tr->waiting_for_dict = 0;
        tr->has_pending_data = 0;
        // Keep existing crossfade state, or reset? Resetting is safer for consistency.
        crossfade_init(&tr->xf, sr, job->low_ms, job->high_ms);
    }
    critical_exit(x->lock);

    double current_time_ms = 0;
    while (current_time_ms < song_length || x->fifo_head != x->fifo_tail) {
        if (x->consolidate_stop) break;

        // Fill simulated vector
        for (int i = 0; i < vector_size; i++) {
            simulated_ramp[i] = current_time_ms + ((double)i * 1000.0 / sr);
        }

        // Process vector (detects bars, fills FIFO)
        weaver_process_vector(x, simulated_ramp, vector_size);

        // Wait for main thread (qtask) to process FIFO if needed
        while (x->fifo_head != x->fifo_tail) {
             if (x->consolidate_stop) break;
             systhread_sleep(1); // Yield to main thread
        }

        current_time_ms += ms_per_vector;

        // Check if we are past song_length but tracks are still busy (fading)
        if (current_time_ms >= song_length) {
            int any_busy = 0;
            for (long t = 0; t < x->track_cache_count; t++) {
                if (x->track_cache[t]->busy) {
                    any_busy = 1;
                    break;
                }
            }
            if (!any_busy) break;

            // Limit overrun to prevent infinite loop if something goes wrong
            if (current_time_ms > song_length + 10000.0) break;
        }
    }

    if (track_keys) sysmem_freeptr(track_keys);
    dictobj_release(dict);
    weaver_queue_log(x, "Consolidate complete. Processed %.2f ms of audio.", current_time_ms);
    x->consolidate_running = 0;
    weaver_queue_finish(x, job);
    return NULL;
}
t_weaver_track *weaver_get_track_state(t_weaver *x, t_atom_long track_id);
void weaver_clear_track_states(t_weaver *x);
void weaver_clear(t_weaver *x);
void weaver_consolidate(t_weaver *x);
void weaver_update_track_cache(t_weaver *x);
static t_class *weaver_class;
static t_symbol *_sym_dash;
static t_symbol *_sym_0;
static t_symbol *_sym_buffer;


t_weaver_track *weaver_get_track_state(t_weaver *x, t_atom_long track_id) {
    t_weaver_track *tr = NULL;
    char tstr[64];
    snprintf(tstr, 64, "%lld", (long long)track_id);
    t_symbol *s_track = gensym(tstr);

    if (hashtab_lookup(x->track_states, s_track, (t_object **)&tr) != MAX_ERR_NONE) {
        tr = (t_weaver_track *)sysmem_newptr(sizeof(t_weaver_track));
        if (tr) {
            crossfade_init(&tr->xf, sys_getsr(), x->low_ms, x->high_ms);
            tr->palette[0] = gensym("-");
            tr->offset[0] = -1.0;
            tr->dict_offset[0] = -1.0;
            tr->rating[0] = 1.0;
            tr->palette[1] = gensym("-");
            tr->offset[1] = -1.0;
            tr->dict_offset[1] = -1.0;
            tr->rating[1] = 1.0;
            tr->slot_most_negative[0] = 0.0;
            tr->slot_most_negative[1] = 0.0;
            tr->pending_most_negative = 0.0;
            tr->track_most_negative = 0.0;
            tr->control = 0.0;
            tr->busy = 0;
            tr->src_refs[0] = buffer_ref_new((t_object *)x, _sym_nothing);
            tr->src_refs[1] = buffer_ref_new((t_object *)x, _sym_nothing);

            char bufname[256];
            snprintf(bufname, 256, "%s.%lld", x->poly_prefix->s_name, (long long)track_id);
            tr->dest_ref = buffer_ref_new((t_object *)x, gensym(bufname));

            tr->dest_found = 0;
            tr->dest_warn_sent = 0;
            tr->src_found[0] = 0;
            tr->src_found[1] = 0;
            tr->src_error_sent[0] = 0;
            tr->src_error_sent[1] = 0;
            tr->track_length = 1000.0;
            tr->last_track_scan = -1.0;
            tr->last_f_dest = -1;
            tr->last_visualize_ms = -1000.0;
            tr->pending_rating = 1.0;
            tr->gain[0] = 1.0;
            tr->gain[1] = 1.0;
            tr->viz_gain[0] = 1.0;
            tr->viz_gain[1] = 1.0;

            // Thread-safe state handover init
            tr->pending_palette = _sym_nothing;
            tr->pending_offset = 0.0;
            tr->pending_bar_symbol = _sym_nothing;
            tr->has_pending_data = 0;
            tr->waiting_for_dict = 0;

            // Visualization state init
            tr->viz_f1 = 0.0;
            tr->viz_f2 = 0.0;
            tr->viz_palette = _sym_nothing;
            tr->viz_offset = 0.0;
            tr->viz_bar_symbol = _sym_nothing;
            tr->viz_ms = 0.0;
            tr->viz_dirty = 0;
            tr->viz_trigger_dirty = 0;
            tr->dirty_dest = 0;
            tr->viz_control = 0.0;
            tr->viz_track_length = 1000.0;
            tr->last_busy_logged = -1;
            tr->viz_busy = 0;
            tr->last_viz_sent_ms = -1000.0;
            tr->viz_absolute_ms = 0.0;

            hashtab_store(x->track_states, s_track, (t_object *)tr);
        }
    }
    return tr;
}

void weaver_update_track_cache(t_weaver *x) {
    if (critical_tryenter(x->lock) == MAX_ERR_NONE) {
        x->track_cache_count = 0;
        long limit = (x->max_tracks > MAX_WEAVER_TRACKS) ? MAX_WEAVER_TRACKS : x->max_tracks;
        for (long i = 1; i <= limit; i++) {
            x->track_cache[x->track_cache_count++] = weaver_get_track_state(x, (t_atom_long)i);
        }
        critical_exit(x->lock);
    }
}


void weaver_clear_track_states(t_weaver *x) {
    if (!x->track_states) return;
    long num_items = 0;
    t_symbol **keys = NULL;
    hashtab_getkeys(x->track_states, &num_items, &keys);
    for (long i = 0; i < num_items; i++) {
        t_weaver_track *tr = NULL;
        hashtab_lookup(x->track_states, keys[i], (t_object **)&tr);
        if (tr) {
            if (tr->src_refs[0]) object_free(tr->src_refs[0]);
            if (tr->src_refs[1]) object_free(tr->src_refs[1]);
            if (tr->dest_ref) object_free(tr->dest_ref);
            sysmem_freeptr(tr);
        }
    }
    if (keys) sysmem_freeptr(keys);
    hashtab_clear(x->track_states);
}


// Helper function to send verbose log messages with prefix
void weaver_log(t_weaver *x, const char *fmt, ...) {
    va_list args;
    va_start(args, fmt);
    vcommon_log(x->log_outlet, x->log, "weaver~", fmt, args);
    va_end(args);
}

void weaver_queue_log(t_weaver *x, const char *fmt, ...) {
    va_list args;
    char buf[256];
    va_start(args, fmt);
    vsnprintf(buf, 256, fmt, args);
    va_end(args);

    t_weaver_log_entry *entry = (t_weaver_log_entry *)sysmem_newptr(sizeof(t_weaver_log_entry));
    if (entry) {
        entry->type = WEAVER_LOG_MSG;
        strncpy(entry->message, buf, 256);
        entry->buffer = NULL;
        entry->next = NULL;
        critical_enter(x->log_queue.lock);
        if (x->log_queue.tail) {
            x->log_queue.tail->next = entry;
            x->log_queue.tail = entry;
        } else {
            x->log_queue.head = entry;
            x->log_queue.tail = entry;
        }
        critical_exit(x->log_queue.lock);
        qelem_set(x->audio_qelem);
    }
}

void weaver_queue_dirty(t_weaver *x, t_buffer_obj *b) {
    t_weaver_log_entry *entry = (t_weaver_log_entry *)sysmem_newptr(sizeof(t_weaver_log_entry));
    if (entry) {
        entry->type = WEAVER_LOG_DIRTY;
        entry->buffer = b;
        entry->job = NULL;
        entry->next = NULL;
        critical_enter(x->log_queue.lock);
        if (x->log_queue.tail) {
            x->log_queue.tail->next = entry;
            x->log_queue.tail = entry;
        } else {
            x->log_queue.head = entry;
            x->log_queue.tail = entry;
        }
        critical_exit(x->log_queue.lock);
        qelem_set(x->audio_qelem);
    }
}

void weaver_queue_finish(t_weaver *x, t_weaver_consolidate_job *job) {
    t_weaver_log_entry *entry = (t_weaver_log_entry *)sysmem_newptr(sizeof(t_weaver_log_entry));
    if (entry) {
        entry->type = WEAVER_LOG_FINISH;
        entry->buffer = NULL;
        entry->job = job;
        entry->next = NULL;
        critical_enter(x->log_queue.lock);
        if (x->log_queue.tail) {
            x->log_queue.tail->next = entry;
            x->log_queue.tail = entry;
        } else {
            x->log_queue.head = entry;
            x->log_queue.tail = entry;
        }
        critical_exit(x->log_queue.lock);
        qelem_set(x->audio_qelem);
    }
}

void weaver_update_most_negative_bar(t_weaver *x) {
    if (x->audio_dict_name == _sym_nothing) {
        x->most_negative_bar = 0.0;
        return;
    }
    t_dictionary *d = dictobj_findregistered_retain(x->audio_dict_name);
    if (!d) {
        return;
    }

    long num_tracks = 0;
    t_symbol **track_keys = NULL;
    dictionary_getkeys(d, &num_tracks, &track_keys);

    double local_most_negative = 0.0;

    for (long i = 0; i < num_tracks; i++) {
        t_dictionary *track_dict = NULL;
        if (dictionary_getdictionary(d, track_keys[i], (t_object **)&track_dict) != MAX_ERR_NONE || !track_dict) continue;

        long num_bars = 0;
        t_symbol **bar_keys = NULL;
        dictionary_getkeys(track_dict, &num_bars, &bar_keys);

        for (long j = 0; j < num_bars; j++) {
            double bar_ts = atof(bar_keys[j]->s_name);
            if (bar_ts < local_most_negative) {
                local_most_negative = bar_ts;
            }
        }
        if (bar_keys) sysmem_freeptr(bar_keys);
    }

    if (track_keys) sysmem_freeptr(track_keys);
    dictobj_release(d);

    if (local_most_negative > 0.0) local_most_negative = 0.0;

    if (local_most_negative != x->most_negative_bar) {
        weaver_log(x, "most_negative_bar updated to %.2f ms", local_most_negative);
        critical_enter(x->lock);
        x->most_negative_bar = local_most_negative;
        critical_exit(x->lock);
    }
}

void weaver_check_attachments(t_weaver *x) {
    weaver_update_most_negative_bar(x);
    // Dictionary check
    if (x->audio_dict_name != _sym_nothing) {
        t_dictionary *d = dictobj_findregistered_retain(x->audio_dict_name);
        if (d) {
            if (!x->dict_found) {
                weaver_log(x, "successfully found dictionary '%s'", x->audio_dict_name->s_name);
                x->dict_found = 1;
                x->dict_error_sent = 0;
            }
            dictobj_release(d);
        } else {
            x->dict_found = 0;
            if (!x->dict_error_sent) {
                object_error((t_object *)x, "dictionary '%s' not found", x->audio_dict_name->s_name);
                x->dict_error_sent = 1;

                // Kick for dictionary name symbol
                t_symbol *tmp = x->audio_dict_name;
                x->audio_dict_name = _sym_nothing;
                x->audio_dict_name = tmp;
            }
        }
    }

    // Polybuffer check (via track1_ref)
    if (x->poly_prefix != _sym_nothing) {
        char t1name[256];
        snprintf(t1name, 256, "%s.1", x->poly_prefix->s_name);
        t_symbol *s_t1name = gensym(t1name);

        t_buffer_obj *b = buffer_ref_getobject(x->track1_ref);
        if (!b) {
            if (!x->poly_warn_sent) {
                object_warn((t_object *)x, "polybuffer~ '%s' not found (via %s). Kicking...", x->poly_prefix->s_name, s_t1name->s_name);
                buffer_ref_set(x->track1_ref, _sym_nothing);
                buffer_ref_set(x->track1_ref, s_t1name);
                b = buffer_ref_getobject(x->track1_ref);
                if (!b) {
                    x->poly_found = 0;
                    object_error((t_object *)x, "polybuffer~ '%s' still NOT FOUND after kick.", x->poly_prefix->s_name);
                    x->poly_warn_sent = 1;
                }
            }
        }

        if (b) {
            if (!x->poly_found) {
                weaver_log(x, "successfully found polybuffer~ '%s' (via %s)", x->poly_prefix->s_name, s_t1name->s_name);
                x->poly_found = 1;
                x->poly_warn_sent = 0;
            }
        }
    }

    // Bar buffer check
    t_buffer_obj *b_bar = buffer_ref_getobject(x->bar_buffer_ref);
    if (!b_bar) {
        if (!x->bar_error_sent) {
            object_warn((t_object *)x, "bar buffer~ not found. Kicking...");
            buffer_ref_set(x->bar_buffer_ref, _sym_nothing);
            buffer_ref_set(x->bar_buffer_ref, gensym("bar"));
            b_bar = buffer_ref_getobject(x->bar_buffer_ref);
            if (!b_bar) {
                x->bar_found = 0;
                object_error((t_object *)x, "bar buffer~ still NOT FOUND after kick.");
                x->bar_error_sent = 1;
            }
        }
    }

    if (b_bar) {
        if (!x->bar_found) {
            weaver_log(x, "successfully found buffer~ 'bar'");
            x->bar_found = 1;
            x->bar_error_sent = 0;
        }
    }
}

void ext_main(void *r) {
    common_symbols_init();
    _sym_dash = gensym("-");
    _sym_0 = gensym("0");
    _sym_buffer = gensym("buffer");
    t_class *c = class_new("weaver~", (method)weaver_new, (method)weaver_free, sizeof(t_weaver), 0L, A_GIMME, 0);

    class_addmethod(c, (method)weaver_tracks, "tracks", A_LONG, 0);
    class_addmethod(c, (method)weaver_clear, "clear", 0);
    class_addmethod(c, (method)weaver_consolidate, "consolidate", 0);
    class_addmethod(c, (method)weaver_list, "list", A_GIMME, 0);
    class_addmethod(c, (method)weaver_dsp64, "dsp64", A_CANT, 0);
    class_addmethod(c, (method)weaver_notify, "notify", A_CANT, 0);
    class_addmethod(c, (method)weaver_assist, "assist", A_CANT, 0);

    CLASS_ATTR_LONG(c, "visualize", 0, t_weaver, visualize);
    CLASS_ATTR_STYLE_LABEL(c, "visualize", 0, "onoff", "Enable Visualization");
    CLASS_ATTR_DEFAULT(c, "visualize", 0, "0");
    CLASS_ATTR_ACCESSORS(c, "visualize", NULL, (method)weaver_attr_set_visualize);

    CLASS_ATTR_LONG(c, "tracks", 0, t_weaver, max_tracks);
    CLASS_ATTR_LABEL(c, "tracks", 0, "Number of Tracks");
    CLASS_ATTR_DEFAULT(c, "tracks", 0, "4");

    CLASS_ATTR_LONG(c, "log", 0, t_weaver, log);
    CLASS_ATTR_STYLE_LABEL(c, "log", 0, "onoff", "Enable Logging");
    CLASS_ATTR_DEFAULT(c, "log", 0, "0");
    CLASS_ATTR_ACCESSORS(c, "log", NULL, (method)weaver_attr_set_log);

    CLASS_ATTR_LONG(c, "dynamic_gain", 0, t_weaver, dynamic_gain);
    CLASS_ATTR_STYLE_LABEL(c, "dynamic_gain", 0, "onoff", "Enable Dynamic Gain");
    CLASS_ATTR_DEFAULT(c, "dynamic_gain", 0, "1");
    CLASS_ATTR_ACCESSORS(c, "dynamic_gain", NULL, (method)weaver_attr_set_dynamic_gain);

    CLASS_ATTR_DOUBLE(c, "low", 0, t_weaver, low_ms);
    CLASS_ATTR_LABEL(c, "low", 0, "Low Limit (ms)");
    CLASS_ATTR_DEFAULT(c, "low", 0, "22.653");
    CLASS_ATTR_ACCESSORS(c, "low", NULL, (method)weaver_attr_set_low);

    CLASS_ATTR_DOUBLE(c, "high", 0, t_weaver, high_ms);
    CLASS_ATTR_LABEL(c, "high", 0, "High Limit (ms)");
    CLASS_ATTR_DEFAULT(c, "high", 0, "4999.0");
    CLASS_ATTR_ACCESSORS(c, "high", NULL, (method)weaver_attr_set_high);

    class_dspinit(c);
    class_register(CLASS_BOX, c);
    weaver_class = c;
}

void *weaver_new(t_symbol *s, long argc, t_atom *argv) {
    t_weaver *x = (t_weaver *)object_alloc(weaver_class);

    if (x) {
        visualize_init();
        x->poly_prefix = _sym_nothing;
        x->log = 0;
        x->visualize = 0;
        x->audio_dict_name = _sym_nothing;
        x->last_scan_val = -1.0;
        x->last_ramp_in_val = -1.0;
        x->fifo_head = 0;
        x->fifo_tail = 0;
        x->dict_found = 0;
        x->dict_error_sent = 0;
        x->poly_found = 0;
        x->poly_warn_sent = 0;
        x->bar_found = 0;
        x->bar_error_sent = 0;
        x->max_tracks = 4;
        x->low_ms = 22.653;
        x->high_ms = 4999.0;
        x->track_cache_count = 0;
        x->last_viz_check_ms = 0;
        x->most_negative_bar = 0.0;
        x->dynamic_gain = 1;
        x->lowest_rating_seen = 0.0;

        // Rolling window fields initialization
        x->song_length = 0.0;
        x->accumulated_ms = 0.0;
        x->rolling_head = 0;
        x->rolling_tail = 0;
        x->rolling_ratings = (t_rating_entry *)sysmem_newptr(sizeof(t_rating_entry) * MAX_ROLLING_RATINGS);

        // 1. Initialize core structures and sync objects early
        critical_new(&x->lock);
        critical_new(&x->log_queue.lock);
        _sym_buffer = gensym("buffer");
        _sym_dash = gensym("-");
        _sym_0 = gensym("0");
        x->log_queue.head = NULL;
        x->log_queue.tail = NULL;
        x->consolidate_running = 0;
        x->consolidate_thread = NULL;

        x->track_states = hashtab_new(0);
        x->bar_buffer_ref = buffer_ref_new((t_object *)x, gensym("bar"));

        // 2. Create outlets (before any logging happens)
        x->log_outlet = outlet_new((t_object *)x, NULL);
        x->bang_outlet = outlet_new((t_object *)x, NULL);
        x->loop_outlet = outlet_new((t_object *)x, NULL);

        // 3. Process Arguments
        // Argument 1: dictionary name
        if (argc > 0 && atom_gettype(argv) == A_SYM && atom_getsym(argv)->s_name[0] != '@') {
            x->audio_dict_name = atom_getsym(argv);
            argc--;
            argv++;
        } else {
            object_error((t_object *)x, "missing mandatory dictionary name argument");
        }

        // Argument 2: polybuffer name
        if (argc > 0 && atom_gettype(argv) == A_SYM && atom_getsym(argv)->s_name[0] != '@') {
            x->poly_prefix = atom_getsym(argv);
            argc--;
            argv++;
        } else {
            object_error((t_object *)x, "missing mandatory polybuffer~ name argument");
        }

        // 4. Initialize polybuffer tracking
        if (x->poly_prefix != _sym_nothing) {
            char t1name[256];
            snprintf(t1name, 256, "%s.1", x->poly_prefix->s_name);
            x->track1_ref = buffer_ref_new((t_object *)x, gensym(t1name));
        } else {
            x->track1_ref = buffer_ref_new((t_object *)x, _sym_nothing);
        }

        attr_args_process(x, argc, argv);

        // 5. Setup initial state dependent on initialized refs and locks
        weaver_update_track_cache(x);
        weaver_check_attachments(x);
        weaver_recalculate_song_length(x);

        x->proxy = proxy_new((t_object *)x, 1, &x->proxy_id);

        dsp_setup((t_pxobject *)x, 1);
        x->audio_qelem = qelem_new(x, (method)weaver_audio_qtask);
    }
    return x;
}

void weaver_free(t_weaver *x) {
    dsp_free((t_pxobject *)x);
    visualize_cleanup();

    if (x->consolidate_running && x->consolidate_thread) {
        x->consolidate_stop = 1;
        unsigned int ret;
        systhread_join(x->consolidate_thread, &ret);
        x->consolidate_thread = NULL;
    }

    if (x->audio_qelem) qelem_free(x->audio_qelem);
    if (x->proxy) object_free(x->proxy);

    if (x->bar_buffer_ref) {
        object_free(x->bar_buffer_ref);
    }
    if (x->track1_ref) {
        object_free(x->track1_ref);
    }
    weaver_clear_track_states(x);
    if (x->track_states) object_free(x->track_states);

    // Free log queue
    critical_enter(x->log_queue.lock);
    t_weaver_log_entry *entry = x->log_queue.head;
    while (entry) {
        t_weaver_log_entry *next = entry->next;
        sysmem_freeptr(entry);
        entry = next;
    }
    critical_exit(x->log_queue.lock);
    critical_free(x->log_queue.lock);

    if (x->rolling_ratings) {
        sysmem_freeptr(x->rolling_ratings);
        x->rolling_ratings = NULL;
    }

    if (x->lock) critical_free(x->lock);
}

t_max_err weaver_notify(t_weaver *x, t_symbol *s, t_symbol *msg, void *sender, void *data) {
    if (x->track_states) {
        long num_items = 0;
        t_symbol **keys = NULL;
        hashtab_getkeys(x->track_states, &num_items, &keys);
        for (long i = 0; i < num_items; i++) {
            t_weaver_track *tr = NULL;
            hashtab_lookup(x->track_states, keys[i], (t_object **)&tr);
            if (tr) {
                if (tr->src_refs[0]) buffer_ref_notify(tr->src_refs[0], s, msg, sender, data);
                if (tr->src_refs[1]) buffer_ref_notify(tr->src_refs[1], s, msg, sender, data);
                if (tr->dest_ref) buffer_ref_notify(tr->dest_ref, s, msg, sender, data);
            }
        }
        if (keys) sysmem_freeptr(keys);
    }
    if (x->bar_buffer_ref) {
        buffer_ref_notify(x->bar_buffer_ref, s, msg, sender, data);
    }
    if (x->track1_ref) {
        buffer_ref_notify(x->track1_ref, s, msg, sender, data);
    }
    return MAX_ERR_NONE;
}

t_max_err weaver_attr_set_dynamic_gain(t_weaver *x, void *attr, long ac, t_atom *av) {
    if (ac && av) {
        x->dynamic_gain = atom_getlong(av);
        weaver_log(x, "dynamic_gain attribute set to %ld", x->dynamic_gain);
    }
    return MAX_ERR_NONE;
}

void weaver_assist(t_weaver *x, void *b, long m, long a, char *s) {
    if (m == ASSIST_INLET) {
        switch (a) {
            case 0: sprintf(s, "Control (clear, consolidate, visualize, log, low, high) and Sync Ramp"); break;
            case 1: sprintf(s, "Inlet 2 (list): [track_id, length]"); break;
        }
    } else { // ASSIST_OUTLET
        switch (a) {
            case 0: sprintf(s, "Outlet 1 (int): Track ID on Loop"); break;
            case 1: sprintf(s, "Outlet 2 (bang): Consolidate Complete"); break;
            case 2: sprintf(s, "Outlet 3 (anything): Logging Outlet"); break;
        }
    }
}

double weaver_get_bar_length(t_weaver *x) {
    double bar_length = 0;
    t_buffer_obj *b = buffer_ref_getobject(x->bar_buffer_ref);
    if (b) {
        float *samples = buffer_locksamples(b);
        if (samples) {
            if (buffer_getframecount(b) > 0) {
                bar_length = (double)samples[0];
            }
            buffer_unlocksamples(b);
        }
    }
    return bar_length;
}


void weaver_update_track_metadata(t_weaver *x, t_atom_long track, t_symbol *palette, double bar_ms, double offset_ms, t_symbol *bar_symbol, double absolute_ms, double rating, int found_in_dict) {
    t_weaver_track *tr = weaver_get_track_state(x, track);
    if (!tr) return;

    critical_enter(x->lock);
    tr->pending_palette = palette;
    tr->pending_offset = offset_ms;
    tr->pending_bar_symbol = bar_symbol;
    tr->pending_rating = rating;
    tr->pending_most_negative = x->most_negative_bar;
    tr->viz_ms = bar_ms; // Trigger timestamp for playback and viz
    tr->viz_absolute_ms = absolute_ms; // Absolute timeline position for viz
    if (x->visualize) {
        tr->viz_control = tr->control;
        tr->viz_track_length = tr->track_length;
    }

    // Target buffer_ref_set to the inactive slot (other) so the active slot (active)
    // continues playing its outgoing buffer during the crossfade.
    int active = (int)round(tr->control);
    int other = 1 - active;
    if (palette != _sym_nothing && palette != gensym("-")) {
        buffer_ref_set(tr->src_refs[other], palette);
    } else {
        buffer_ref_set(tr->src_refs[other], _sym_nothing);
    }

    tr->has_pending_data = 1;
    critical_exit(x->lock);
}


void weaver_list(t_weaver *x, t_symbol *s, long argc, t_atom *argv) {
    long inlet = proxy_getinlet((t_object *)x);
    if (inlet == 1) {
        if (argc >= 2) {
            long track_id = atom_getlong(argv);
            double length = round(atom_getfloat(argv + 1));
            if (track_id > 0) {
                t_weaver_track *tr = weaver_get_track_state(x, track_id);
                if (tr) {
                    critical_enter(x->lock);
                    tr->track_length = length;
                    if (x->visualize) {
                        tr->viz_track_length = length;
                        tr->viz_dirty = 1;
                    }
                    weaver_recalculate_song_length(x);
                    critical_exit(x->lock);
                    weaver_log(x, "Track %ld length manually updated to %.2f ms", track_id, length);
                }
            }
        }
    }
}

void weaver_consolidate(t_weaver *x) {
    if (x->consolidate_running) {
        object_error((t_object *)x, "consolidate is already running");
        return;
    }

    double bar_len = round(weaver_get_bar_length(x));
    if (bar_len <= 0) {
        object_error((t_object *)x, "invalid or missing bar length buffer 'bar'. Kicking...");
        buffer_ref_set(x->bar_buffer_ref, _sym_nothing);
        buffer_ref_set(x->bar_buffer_ref, gensym("bar"));
        bar_len = round(weaver_get_bar_length(x));
        if (bar_len <= 0) {
            object_error((t_object *)x, "bar length buffer 'bar' still not found after kick.");
            return;
        }
    }

    if (x->audio_dict_name == _sym_nothing) {
        object_error((t_object *)x, "missing transcript dictionary");
        return;
    }

    t_weaver_consolidate_job *job = (t_weaver_consolidate_job *)sysmem_newptr(sizeof(t_weaver_consolidate_job));
    if (job) {
        job->x = x;
        job->audio_dict_name = x->audio_dict_name;
        job->poly_prefix = x->poly_prefix;
        job->bar_length = bar_len;
        job->low_ms = x->low_ms;
        job->high_ms = x->high_ms;

        x->consolidate_running = 1;
        x->consolidate_stop = 0;
        systhread_create((method)weaver_consolidate_worker, job, 0, 0, 0, &x->consolidate_thread);
    }
}

void weaver_clear(t_weaver *x) {
    critical_enter(x->lock);
    x->last_scan_val = -1.0;
    x->last_ramp_in_val = -1.0;
    x->fifo_head = 0;
    x->fifo_tail = 0;
    x->most_negative_bar = 0.0;
    x->lowest_rating_seen = 0.0;
    x->song_length = 0.0;
    x->accumulated_ms = 0.0;
    x->rolling_head = 0;
    x->rolling_tail = 0;

    x->dict_found = 0;
    x->dict_error_sent = 0;
    x->poly_found = 0;
    x->poly_warn_sent = 0;
    x->bar_found = 0;
    x->bar_error_sent = 0;

    for (long t = 0; t < x->track_cache_count; t++) {
        t_weaver_track *tr = x->track_cache[t];
        if (tr) {
            tr->track_length = 0.0;
            tr->viz_track_length = 0.0;
            tr->last_track_scan = -1.0;
            tr->last_f_dest = -1;
            tr->busy = 0;
            tr->has_pending_data = 0;
            tr->waiting_for_dict = 0;
            tr->pending_rating = 1.0;
            tr->gain[0] = 1.0;
            tr->gain[1] = 1.0;
            tr->viz_gain[0] = 1.0;
            tr->viz_gain[1] = 1.0;

            tr->palette[0] = _sym_dash;
            tr->palette[1] = _sym_dash;
            tr->offset[0] = -1.0;
            tr->offset[1] = -1.0;
            tr->dict_offset[0] = -1.0;
            tr->dict_offset[1] = -1.0;
            tr->rating[0] = 1.0;
            tr->rating[1] = 1.0;
            tr->slot_most_negative[0] = 0.0;
            tr->slot_most_negative[1] = 0.0;
            tr->pending_most_negative = 0.0;
            tr->track_most_negative = 0.0;
            tr->control = 0.0;

            tr->dest_found = 0;
            tr->dest_warn_sent = 0;
            tr->src_found[0] = 0;
            tr->src_found[1] = 0;
            tr->src_error_sent[0] = 0;
            tr->src_error_sent[1] = 0;

            crossfade_init(&tr->xf, sys_getsr(), x->low_ms, x->high_ms);

            // Kick dest_ref
            if (x->poly_prefix != _sym_nothing) {
                char bufname[256];
                snprintf(bufname, 256, "%s.%lld", x->poly_prefix->s_name, (long long)t + 1);
                buffer_ref_set(tr->dest_ref, _sym_nothing);
                buffer_ref_set(tr->dest_ref, gensym(bufname));
            } else {
                buffer_ref_set(tr->dest_ref, _sym_nothing);
            }

            // Reset src_refs
            buffer_ref_set(tr->src_refs[0], _sym_nothing);
            buffer_ref_set(tr->src_refs[1], _sym_nothing);
        }
    }

    // Global kicks
    if (x->poly_prefix != _sym_nothing) {
        char t1name[256];
        snprintf(t1name, 256, "%s.1", x->poly_prefix->s_name);
        buffer_ref_set(x->track1_ref, _sym_nothing);
        buffer_ref_set(x->track1_ref, gensym(t1name));
    } else {
        buffer_ref_set(x->track1_ref, _sym_nothing);
    }
    buffer_ref_set(x->bar_buffer_ref, _sym_nothing);
    buffer_ref_set(x->bar_buffer_ref, gensym("bar"));

    weaver_check_attachments(x);
    critical_exit(x->lock);

    if (x->visualize) visualize((t_object *)x, "{\"clear\": 1}");
    weaver_log(x, "cleared all track states and lengths, and reset buffer bindings");
}

void weaver_tracks(t_weaver *x, long n) {
    if (proxy_getinlet((t_object *)x) != 0) return;
    x->max_tracks = n;
    weaver_update_track_cache(x);
}

t_max_err weaver_attr_set_visualize(t_weaver *x, void *attr, long ac, t_atom *av) {
    if (ac && av) {
        x->visualize = atom_getlong(av);
        weaver_log(x, "visualize attribute set to %ld", x->visualize);
    }
    return MAX_ERR_NONE;
}

t_max_err weaver_attr_set_log(t_weaver *x, void *attr, long ac, t_atom *av) {
    if (ac && av) {
        x->log = atom_getlong(av);
        weaver_log(x, "log attribute set to %ld", x->log);
    }
    return MAX_ERR_NONE;
}

t_max_err weaver_attr_set_low(t_weaver *x, void *attr, long ac, t_atom *av) {
    if (ac && av) {
        x->low_ms = atom_getfloat(av);
        weaver_log(x, "low attribute set to %.2f", x->low_ms);
    }
    return MAX_ERR_NONE;
}

t_max_err weaver_attr_set_high(t_weaver *x, void *attr, long ac, t_atom *av) {
    if (ac && av) {
        x->high_ms = atom_getfloat(av);
        weaver_log(x, "high attribute set to %.2f", x->high_ms);
    }
    return MAX_ERR_NONE;
}

void weaver_dsp64(t_weaver *x, t_object *dsp64, short *count, double samplerate, long maxvectorsize, long flags) {
    if (count[0]) {
        weaver_log(x, "DSP ON: tracking signal ramp");
        weaver_update_track_cache(x);
        dsp_add64(dsp64, (t_object *)x, (t_perfroutine64)weaver_perform64, 0, NULL);
    }
}

typedef struct {
    float *samples_dest;
    long long n_frames_dest;
    long n_chans_dest;
    double sr_dest;

    float *samples_src[2];
    long long n_frames_src[2];
    long n_chans_src[2];
    double sr_src[2];
    t_buffer_obj *buf_src[2];
    t_buffer_obj *buf_dest;
} t_track_buffers;

void weaver_process_vector(t_weaver *x, double *ramp_in, long sampleframes) {
    double last_scan = x->last_scan_val;
    double last_ramp_in = x->last_ramp_in_val;
    double bar_len = round(weaver_get_bar_length(x));

    t_track_buffers tb[MAX_WEAVER_TRACKS];
    memset(tb, 0, sizeof(tb));

    // 1. Handover and Buffer Acquisition
    int has_lock = 0;
    if (x->consolidate_running) {
        critical_enter(x->lock);
        has_lock = 1;
    } else {
        has_lock = (critical_tryenter(x->lock) == MAX_ERR_NONE);
    }

    if (has_lock) {
        double sr = sys_getsr();
        if (sr <= 0) sr = 44100.0;
        double vector_ms = (double)sampleframes * 1000.0 / sr;
        x->accumulated_ms += vector_ms;
    }

    for (long t = 0; t < x->track_cache_count; t++) {
        t_weaver_track *tr = x->track_cache[t];
        if (!tr) continue;

        if (has_lock && tr->has_pending_data) {
            int active = (int)round(tr->control);
            int change = (tr->pending_palette != tr->palette[active] ||
                          tr->pending_offset != tr->dict_offset[active] ||
                          tr->pending_bar_symbol == _sym_0 ||
                          (x->dynamic_gain && tr->pending_rating != tr->rating[active]));

            if (change) {
                int other = 1 - active;
                tr->palette[other] = tr->pending_palette;
                tr->dict_offset[other] = tr->pending_offset;
                tr->offset[other] = tr->pending_offset;
                tr->slot_most_negative[other] = tr->pending_most_negative;
                tr->rating[other] = tr->pending_rating;

                // Sync track_most_negative and compensate last_track_scan at bar handover
                double old_tr_mn = tr->track_most_negative;
                double new_tr_mn = tr->pending_most_negative;
                if (new_tr_mn != old_tr_mn) {
                    double delta = new_tr_mn - old_tr_mn;
                    if (tr->last_track_scan != -1.0) {
                        tr->last_track_scan += delta;
                    }
                    tr->track_most_negative = new_tr_mn;
                }

                tr->control = (double)other;
                tr->xf.direction = tr->control - tr->xf.last_control;

                double target_gain = 1.0;
                if (x->dynamic_gain) {
                    weaver_expire_ratings(x, x->accumulated_ms);
                    weaver_add_rating(x, x->accumulated_ms, tr->pending_rating);
                    double min_rating = weaver_get_rolling_min_rating(x);

                    if (tr->pending_rating < 0.0) {
                        if (min_rating < 0.0) {
                            target_gain = 1.0 - (tr->pending_rating / min_rating);
                        }
                    }
                }
                tr->gain[other] = target_gain;
            }
            if (x->visualize) {
                tr->viz_palette = tr->pending_palette;
                tr->viz_offset = tr->pending_offset;
                tr->viz_bar_symbol = tr->pending_bar_symbol;
                tr->viz_trigger_dirty = 1;
            }
            tr->has_pending_data = 0;
            tr->waiting_for_dict = 0;
        }

        // 2. Lock Buffers
        t_buffer_obj *dest_buf = buffer_ref_getobject(tr->dest_ref);
        if (dest_buf) {
            tb[t].samples_dest = buffer_locksamples(dest_buf);
            if (tb[t].samples_dest) {
                tb[t].buf_dest = dest_buf;
                tb[t].n_frames_dest = buffer_getframecount(dest_buf);
                tb[t].n_chans_dest = buffer_getchannelcount(dest_buf);
                tb[t].sr_dest = buffer_getsamplerate(dest_buf);
                if (tb[t].sr_dest <= 0) tb[t].sr_dest = sys_getsr();
            }
        }

        for (int j = 0; j < 2; j++) {
            if (tr->palette[j] != _sym_nothing && tr->palette[j] != _sym_dash) {
                t_buffer_obj *src_buf = buffer_ref_getobject(tr->src_refs[j]);
                if (src_buf) {
                    tb[t].samples_src[j] = buffer_locksamples(src_buf);
                    if (tb[t].samples_src[j]) {
                        tb[t].buf_src[j] = src_buf;
                        tb[t].n_frames_src[j] = buffer_getframecount(src_buf);
                        tb[t].n_chans_src[j] = buffer_getchannelcount(src_buf);
                        tb[t].sr_src[j] = buffer_getsamplerate(src_buf);
                        if (tb[t].sr_src[j] <= 0) tb[t].sr_src[j] = sys_getsr();
                    }
                }
            }
        }
        crossfade_update_params(&tr->xf, tb[t].sr_dest > 0 ? tb[t].sr_dest : sys_getsr(), x->low_ms, x->high_ms);
    }

    if (has_lock) critical_exit(x->lock);

    // 3. Sample Loop (Unlocked)
    for (int i = 0; i < sampleframes; i++) {
        double current_ramp_in = ramp_in[i];
        double current_scan = current_ramp_in + x->most_negative_bar;
        int main_looped = (last_ramp_in != -1.0 && current_ramp_in < last_ramp_in);

        if (main_looped) {
            x->fifo_head = x->fifo_tail;
            for (long t = 0; t < x->track_cache_count; t++) {
                t_weaver_track *tr = x->track_cache[t];
                if (tr) {
                    tr->busy = 0;
                    tr->waiting_for_dict = 0;
                    tr->has_pending_data = 0;

                    // Snap ramps to done
                    tr->xf.ramp1.go = (double)tr->xf.elapsed - tr->xf.ramp1.length;
                    tr->xf.ramp2.go = (double)tr->xf.elapsed - tr->xf.ramp2.length;

                    // Reset slots to force a hard jump on re-trigger
                    tr->palette[0] = _sym_dash;
                    tr->palette[1] = _sym_dash;
                    tr->offset[0] = -1.0;
                    tr->offset[1] = -1.0;
                    tr->dict_offset[0] = -1.0;
                    tr->dict_offset[1] = -1.0;
                    tr->rating[0] = 1.0;
                    tr->rating[1] = 1.0;
                    tr->slot_most_negative[0] = 0.0;
                    tr->slot_most_negative[1] = 0.0;
                    tr->pending_most_negative = 0.0;
                    tr->track_most_negative = 0.0;
                    tr->control = 0.0;
                    tr->xf.last_control = 0.0;

                    // Enqueue TYPE_LOOP before resetting last_track_scan
                    int nt_loop = (x->fifo_tail + 1) % 4096;
                    if (nt_loop != x->fifo_head) {
                        x->hit_bars[x->fifo_tail].type = TYPE_LOOP;
                        x->hit_bars[x->fifo_tail].track_id = t + 1;
                        x->hit_bars[x->fifo_tail].song_loop = 1;
                        x->fifo_tail = nt_loop;
                    }

                    tr->track_most_negative = x->most_negative_bar;
                    tr->pending_most_negative = x->most_negative_bar;

                    // Force re-entry into initial bar trigger logic
                    tr->last_track_scan = -1.0;

                    // Sync internal timer with the loop destination
                    tr->last_f_dest = -1;

                    // Clear visualization flags
                    tr->viz_trigger_dirty = 0;
                    tr->viz_dirty = 0;
                }
            }
        }

        for (long t = 0; t < x->track_cache_count; t++) {
            t_weaver_track *tr = x->track_cache[t];
            if (!tr) continue;
            if (tr->track_length <= 0.0) {
                tr->last_track_scan = -1.0;
                continue;
            }

            // 2. Continuous Bar Hit Detection (Outside samples_dest check)
            double tr_scan = current_ramp_in + tr->track_most_negative;
            long r_scan = (long)floor(tr_scan);
            long r_last = (long)floor(tr->last_track_scan);

            if (tr->last_track_scan != -1.0) {
                if (main_looped) {
                    int nt_loop = (x->fifo_tail + 1) % 4096;
                    if (nt_loop != x->fifo_head) {
                        x->hit_bars[x->fifo_tail].type = TYPE_LOOP;
                        x->hit_bars[x->fifo_tail].track_id = t + 1;
                        x->hit_bars[x->fifo_tail].song_loop = 1;
                        x->fifo_tail = nt_loop;
                    }
                }

                if ((!tr->busy || main_looped) && !tr->waiting_for_dict && r_scan != r_last && bar_len > 0) {
                    long long start = r_last + 1;
                    long long end = r_scan;
                    long long latest_j;
                    if (end >= 0) {
                        latest_j = (end / (long long)bar_len) * (long long)bar_len;
                    } else {
                        if (end % (long long)bar_len == 0) {
                            latest_j = (end / (long long)bar_len) * (long long)bar_len;
                        } else {
                            latest_j = ((end / (long long)bar_len) - 1) * (long long)bar_len;
                        }
                    }

                    if (latest_j >= start) {
                        int nt = (x->fifo_tail + 1) % 4096;
                        if (nt != x->fifo_head) {
                            x->hit_bars[x->fifo_tail].bar.sym = NULL;
                            x->hit_bars[x->fifo_tail].rel_time = (double)latest_j;
                            x->hit_bars[x->fifo_tail].bar.value = tr_scan;
                            x->hit_bars[x->fifo_tail].type = TYPE_DATA;
                            x->hit_bars[x->fifo_tail].track_id = t + 1;
                            x->fifo_tail = nt;
                            tr->waiting_for_dict = 1;
                            tr->busy = 1;
                        }
                    }
                }
            } else if (bar_len > 0) {
                // Initial Bar Trigger
                double initial_bar = floor(tr_scan / bar_len) * bar_len;
                int nt_init = (x->fifo_tail + 1) % 4096;
                if (nt_init != x->fifo_head) {
                    x->hit_bars[x->fifo_tail].bar.sym = NULL;
                    x->hit_bars[x->fifo_tail].rel_time = initial_bar;
                    x->hit_bars[x->fifo_tail].bar.value = tr_scan;
                    x->hit_bars[x->fifo_tail].type = TYPE_DATA;
                    x->hit_bars[x->fifo_tail].track_id = t + 1;
                    x->fifo_tail = nt_init;
                    tr->waiting_for_dict = 1;
                    tr->busy = 1;
                }
            }

            // 3. Gap-filling audio weaving (Inside samples_dest check)
            if (!tb[t].samples_dest) {
                tr->last_track_scan = tr_scan;
                continue;
            }

            long long f_curr_ramp = (long long)round(current_ramp_in * tb[t].sr_dest / 1000.0);
            if (tr->last_f_dest == -1 || main_looped || (f_curr_ramp - tr->last_f_dest > 100000)) {
                tr->last_f_dest = f_curr_ramp - 1;
            }

            double f1, f2;
            for (long long f_ramp = tr->last_f_dest + 1; f_ramp <= f_curr_ramp; f_ramp++) {
                long long f_wrapped = f_ramp % tb[t].n_frames_dest;
                if (f_wrapped < 0) f_wrapped += tb[t].n_frames_dest;

                double max_abs[2] = {0.0, 0.0};
                double interleaved_s[2][16]; // Max 16 channels for interpolation
                memset(interleaved_s, 0, sizeof(interleaved_s));

                // Linear Interpolation for source lookups
                for (int j = 0; j < 2; j++) {
                    if (tb[t].samples_src[j]) {
                        double v_at_f = (double)f_ramp * 1000.0 / tb[t].sr_dest + tr->slot_most_negative[j];
                        double src_ms = tr->offset[j] + v_at_f;
                        double f_src_raw = src_ms * tb[t].sr_src[j] / 1000.0;
                        long long f_low = (long long)floor(f_src_raw);
                        long long f_high = f_low + 1;
                        double frac = f_src_raw - (double)f_low;

                        if (f_low >= 0 && f_high < tb[t].n_frames_src[j]) {
                            long n_chans = tb[t].n_chans_src[j] > 16 ? 16 : tb[t].n_chans_src[j];
                            for (long c = 0; c < n_chans; c++) {
                                float s_low = tb[t].samples_src[j][f_low * tb[t].n_chans_src[j] + c];
                                float s_high = tb[t].samples_src[j][f_high * tb[t].n_chans_src[j] + c];
                                double s_interp = (double)s_low + (double)(s_high - s_low) * frac;
                                interleaved_s[j][c] = s_interp;
                                double a = fabs(s_interp);
                                if (a > max_abs[j]) max_abs[j] = a;
                            }
                        }
                    }
                }

                ramp_process(&tr->xf.ramp1, max_abs[0], tr->xf.direction, f_ramp, tb[t].sr_dest, x->low_ms, x->high_ms, &f1);
                ramp_process(&tr->xf.ramp2, max_abs[1], tr->xf.direction * -1.0, f_ramp, tb[t].sr_dest, x->low_ms, x->high_ms, &f2);
                tr->xf.direction = 0.0; // Direction is only applied once

                for (long c = 0; c < tb[t].n_chans_dest; c++) {
                    double mix1 = (c < 16) ? interleaved_s[0][c] * f1 * tr->gain[0] : 0.0;
                    double mix2 = (c < 16) ? interleaved_s[1][c] * f2 * tr->gain[1] : 0.0;
                    tb[t].samples_dest[f_wrapped * tb[t].n_chans_dest + c] = (float)(mix1 + mix2);
                }
            }

            int r1_done = (tr->xf.ramp1.toggle > 0.5) ? (f1 <= 0.0) : (f1 >= 1.0);
            int r2_done = (tr->xf.ramp2.toggle > 0.5) ? (f2 <= 0.0) : (f2 >= 1.0);
            if (r1_done && r2_done && !tr->waiting_for_dict) tr->busy = 0;

            tr->xf.last_control = tr->control;
            tr->xf.elapsed = f_curr_ramp;
            tr->last_f_dest = f_curr_ramp;
            tr->dirty_dest = 1;

            if (x->visualize) {
                int gain_changed = (tr->viz_gain[0] != tr->gain[0] || tr->viz_gain[1] != tr->gain[1]);
                tr->viz_f1 = f1;
                tr->viz_f2 = f2;
                tr->viz_busy = tr->busy;
                tr->viz_gain[0] = tr->gain[0];
                tr->viz_gain[1] = tr->gain[1];

                if (current_scan >= tr->last_viz_sent_ms + 333.33 || current_scan < tr->last_viz_sent_ms || tr->viz_busy != tr->busy || gain_changed) {
                    tr->viz_dirty = 1;
                    tr->last_viz_sent_ms = current_scan;
                }
            }

            tr->last_track_scan = tr_scan;
        }
        last_scan = current_scan;
        last_ramp_in = current_ramp_in;
    }

    // 4. Unlock Phase
    for (long t = 0; t < x->track_cache_count; t++) {
        if (tb[t].buf_dest && tb[t].samples_dest) {
            buffer_unlocksamples(tb[t].buf_dest);
        }
        for (int j = 0; j < 2; j++) {
            if (tb[t].buf_src[j] && tb[t].samples_src[j]) {
                buffer_unlocksamples(tb[t].buf_src[j]);
            }
        }
    }

    x->last_scan_val = (sampleframes > 0) ? (ramp_in[sampleframes - 1] + x->most_negative_bar) : last_scan;
    x->last_ramp_in_val = (sampleframes > 0) ? ramp_in[sampleframes - 1] : last_ramp_in;
    qelem_set(x->audio_qelem);
}

static void weaver_log_dsp_stall(void *x, double duration_ms, long sampleframes) {
    FILE *f = fopen("max_dsp_stall_breadcrumbs.log", "a");
    if (f) {
        fprintf(f, "[DSP STALL] weaver~ %p: perform64 took %.3f ms for %ld sampleframes (> 10.0ms)\n", x, duration_ms, sampleframes);
        fflush(f);
        fclose(f);
    }
}

void weaver_perform64(t_weaver *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam) {
    if (x->consolidate_running) return;
    double t0 = (double)systime_ms();
    weaver_process_vector(x, ins[0], sampleframes);
    double duration_ms = (double)systime_ms() - t0;
    if (duration_ms > 10.0) {
        weaver_log_dsp_stall(x, duration_ms, sampleframes);
    }
}

void weaver_audio_qtask(t_weaver *x) {
    weaver_check_attachments(x);

    // Drain log queue
    critical_enter(x->log_queue.lock);
    t_weaver_log_entry *log_entry = x->log_queue.head;
    x->log_queue.head = NULL;
    x->log_queue.tail = NULL;
    critical_exit(x->log_queue.lock);

    while (log_entry) {
        if (log_entry->type == WEAVER_LOG_MSG) {
            weaver_log(x, "%s", log_entry->message);
        } else if (log_entry->type == WEAVER_LOG_DIRTY) {
            if (log_entry->buffer) buffer_setdirty(log_entry->buffer);
        } else if (log_entry->type == WEAVER_LOG_FINISH) {
            t_weaver_consolidate_job *job = (t_weaver_consolidate_job *)log_entry->job;
            if (job) {
                weaver_log(x, "Consolidate finished (Worker job: %p)", job);
                sysmem_freeptr(job);
                outlet_bang(x->bang_outlet);
            }
        }
        t_weaver_log_entry *next = log_entry->next;
        sysmem_freeptr(log_entry);
        log_entry = next;
    }
    int clear_sent = 0;

    while (x->fifo_head != x->fifo_tail) {
        t_fifo_entry hit_entry = x->hit_bars[x->fifo_head];
        x->fifo_head = (x->fifo_head + 1) % 4096;

        long target_track = hit_entry.track_id;
        t_weaver_track *tr = NULL;
        if (target_track > 0 && target_track <= x->track_cache_count) {
            tr = x->track_cache[target_track - 1];
        }

        if (hit_entry.type == TYPE_LOOP) {
            outlet_int(x->loop_outlet, (t_atom_long)hit_entry.track_id);
            if (x->visualize && hit_entry.song_loop && !clear_sent) {
                visualize((t_object *)x, "{\"clear\": 1}");
                clear_sent = 1;
            }
            continue;
        }

        t_bar_cache hit = hit_entry.bar;

        // DATA Hit logic
        t_symbol *bar_key = hit.sym;
        if (!bar_key) {
            char bstr[64];
            snprintf(bstr, 64, "%ld", (long)round(hit_entry.rel_time));
            bar_key = gensym(bstr);
        }

        t_dictionary *dict = dictobj_findregistered_retain(x->audio_dict_name);
        if (dict) {
            char tstr[64];
            snprintf(tstr, 64, "%ld", target_track);
            t_symbol *track_sym = gensym(tstr);
            t_dictionary *track_dict = NULL;

            int found_in_dict = 0;
            t_symbol *palette = _sym_nothing;
            double offset = 0.0;
            double rating = 1.0;
            int palette_exists = 0;

            if (dictionary_getdictionary(dict, track_sym, (t_object **)&track_dict) == MAX_ERR_NONE && track_dict) {
                t_dictionary *bar_dict = NULL;
                if (dictionary_getdictionary(track_dict, bar_key, (t_object **)&bar_dict) == MAX_ERR_NONE && bar_dict) {
                    found_in_dict = 1;
                    if (x->consolidate_running) {
                        weaver_queue_log(x, "Consolidate: processing track %ld bar %s", target_track, bar_key->s_name);
                    }

                    t_atomarray *palette_aa = NULL;
                    t_atom p_atom;
                    if (dictionary_getatomarray(bar_dict, gensym("palette"), (t_object **)&palette_aa) == MAX_ERR_NONE && palette_aa) {
                        if (atomarray_getindex(palette_aa, 0, &p_atom) == MAX_ERR_NONE) palette = atom_getsym(&p_atom);
                    } else if (dictionary_getatom(bar_dict, gensym("palette"), &p_atom) == MAX_ERR_NONE) {
                        palette = atom_getsym(&p_atom);
                    }

                    t_atomarray *offset_aa = NULL;
                    t_atom o_atom;
                    if (dictionary_getatomarray(bar_dict, gensym("offset"), (t_object **)&offset_aa) == MAX_ERR_NONE && offset_aa) {
                        if (atomarray_getindex(offset_aa, 0, &o_atom) == MAX_ERR_NONE) offset = atom_getfloat(&o_atom);
                    } else if (dictionary_getatom(bar_dict, gensym("offset"), &o_atom) == MAX_ERR_NONE) {
                        offset = atom_getfloat(&o_atom);
                    }

                    t_atomarray *rating_aa = NULL;
                    t_atom r_atom;
                    if (dictionary_getatomarray(bar_dict, gensym("rating"), (t_object **)&rating_aa) == MAX_ERR_NONE && rating_aa) {
                        if (atomarray_getindex(rating_aa, 0, &r_atom) == MAX_ERR_NONE) rating = atom_getfloat(&r_atom);
                    } else if (dictionary_getatom(bar_dict, gensym("rating"), &r_atom) == MAX_ERR_NONE) {
                        rating = atom_getfloat(&r_atom);
                    }

                    if (palette != _sym_nothing && palette != _sym_dash) {
                        t_buffer_ref *temp_ref = buffer_ref_new((t_object *)x, palette);
                        if (!buffer_ref_getobject(temp_ref)) {
                            if (!tr->src_error_sent[1]) {
                                object_warn((t_object *)x, "Track %lld: palette '%s' not found. Kicking...", (long long)target_track, palette->s_name);
                                buffer_ref_set(temp_ref, _sym_nothing);
                                buffer_ref_set(temp_ref, palette);
                                if (!buffer_ref_getobject(temp_ref)) {
                                    object_error((t_object *)x, "Track %lld: palette '%s' still NOT FOUND after kick.", (long long)target_track, palette->s_name);
                                    tr->src_error_sent[1] = 1;
                                    tr->src_found[1] = 0;
                                } else {
                                    palette_exists = 1;
                                }
                            }
                        } else {
                            palette_exists = 1;
                        }

                        if (palette_exists) {
                            if (!tr->src_found[1]) {
                                weaver_log(x, "Track %lld: successfully bound palette '%s'", (long long)target_track, palette->s_name);
                                tr->src_found[1] = 1;
                                tr->src_error_sent[1] = 0;
                            }
                        }
                        object_free(temp_ref);
                    }
                }
            }

            if (found_in_dict) {
                if (palette == _sym_dash || palette == _sym_nothing) {
                    weaver_log(x, "Track %lld: bar %s found in dictionary (palette: -, offset: %.2f, rating: %.2f)", (long long)target_track, bar_key->s_name, offset, rating);
                    weaver_update_track_metadata(x, target_track, _sym_dash, hit.value, offset, bar_key, hit_entry.rel_time, rating, 1);
                } else if (palette_exists) {
                    if (strncmp(palette->s_name, "stems.", 6) == 0) {
                        offset = -x->most_negative_bar;
                    }
                    weaver_log(x, "Track %lld: bar %s found in dictionary (palette: %s, offset: %.2f, rating: %.2f)", (long long)target_track, bar_key->s_name, palette->s_name, offset, rating);
                    weaver_update_track_metadata(x, target_track, palette, hit.value, offset, bar_key, hit_entry.rel_time, rating, 1);
                } else {
                    object_error((t_object *)x, "Track %lld: palette '%s' for bar %s not found. Falling back to silence.", (long long)target_track, palette->s_name, bar_key->s_name);
                    weaver_update_track_metadata(x, target_track, _sym_dash, hit.value, 0.0, bar_key, hit_entry.rel_time, 1.0, 1);
                }
            } else {
                weaver_log(x, "Track %lld: bar %s not found in dictionary. Falling back to silence.", (long long)target_track, bar_key->s_name);
                weaver_update_track_metadata(x, target_track, _sym_dash, hit.value, 0.0, bar_key, hit_entry.rel_time, 1.0, 0);
            }

            dictobj_release(dict);
        } else {
            // Even if dictionary is missing, we must trigger something (e.g. silence) to progress
            weaver_update_track_metadata(x, target_track, _sym_dash, hit.value, 0.0, bar_key, hit_entry.rel_time, 1.0, 0);
        }
    }

    // 1. Post-DSP Buffer and Busy Management
    for (long t = 0; t < x->track_cache_count; t++) {
        t_weaver_track *tr = x->track_cache[t];
        if (tr) {
            if (tr->dirty_dest) {
                t_buffer_obj *b = buffer_ref_getobject(tr->dest_ref);
                if (!b) {
                    if (!tr->dest_warn_sent) {
                        char bufname[256];
                        snprintf(bufname, 256, "%s.%ld", x->poly_prefix->s_name, t + 1);
                        object_warn((t_object *)x, "Track %ld: destination buffer %s not found. Kicking...", t + 1, bufname);
                        buffer_ref_set(tr->dest_ref, _sym_nothing);
                        buffer_ref_set(tr->dest_ref, gensym(bufname));
                        b = buffer_ref_getobject(tr->dest_ref);
                        if (!b) {
                            tr->dest_found = 0;
                            object_error((t_object *)x, "Track %ld: destination buffer %s still NOT FOUND after kick.", t + 1, bufname);
                            tr->dest_warn_sent = 1;
                        }
                    }
                }
                if (b) {
                    if (!tr->dest_found) {
                        char bufname[256];
                        snprintf(bufname, 256, "%s.%ld", x->poly_prefix->s_name, t + 1);
                        weaver_log(x, "successfully found destination buffer %s", bufname);
                        tr->dest_found = 1;
                        tr->dest_warn_sent = 0;
                    }
                    buffer_setdirty(b);
                }
                tr->dirty_dest = 0;
            }

        }
    }

    // 2. Visualization Polling
    if (x->visualize) {
        double current_ms = (double)systime_ms();
        if (current_ms >= x->last_viz_check_ms + 333.33) {
            for (long t = 0; t < x->track_cache_count; t++) {
                t_weaver_track *tr = x->track_cache[t];
                if (!tr) continue;

                char l_msg[256] = "";
                char msg[256] = "";
                int has_l = 0, has_m = 0;

                // Capture data quickly under lock
                critical_enter(x->lock);
                if (tr->viz_trigger_dirty) {
                    snprintf(l_msg, sizeof(l_msg), "{\"track\": %ld, \"ms\": %.2f, \"palette\": \"%s\", \"offset\": %.0f, \"bar\": \"%s\", \"len\": %.0f, \"f2\": %.1f, \"busy\": %d}",
                             t + 1, tr->viz_absolute_ms, tr->viz_palette->s_name, tr->viz_offset, tr->viz_bar_symbol->s_name, tr->viz_track_length, (double)round(tr->viz_control), tr->viz_busy);
                    tr->viz_trigger_dirty = 0;
                    has_l = 1;
                }

                if (tr->viz_dirty) {
                    double min_r = weaver_get_rolling_min_rating(x);
                    snprintf(msg, sizeof(msg), "{\"track\": %ld, \"ms\": %.2f, \"f1\": %.4f, \"f2\": %.4f, \"busy\": %d, \"len\": %.0f, \"dynamic_gain\": %ld, \"g1\": %.4f, \"g2\": %.4f, \"song_length\": %.2f, \"min_rating\": %.3f}",
                             t + 1, x->last_scan_val, tr->viz_f1, tr->viz_f2, tr->viz_busy, tr->viz_track_length, x->dynamic_gain, tr->viz_gain[0], tr->viz_gain[1], x->song_length, min_r);
                    tr->viz_dirty = 0;
                    has_m = 1;
                }
                critical_exit(x->lock);

                // Send data outside lock
                if (has_l) visualize((t_object *)x, l_msg);
                if (has_m) visualize((t_object *)x, msg);
            }
            x->last_viz_check_ms = current_ms;
        }
    }
}
