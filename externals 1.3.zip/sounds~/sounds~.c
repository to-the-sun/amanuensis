#include "ext.h"
#include "ext_obex.h"
#include "ext_critical.h"
#include "ext_path.h"
#include "ext_dictobj.h"
#include "z_dsp.h"
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

#define MAX_VOICES 32
#define MAX_MODULES 64
#define EVENT_QUEUE_SIZE 512

typedef enum {
    EVENT_NOTE_ON,
    EVENT_NOTE_OFF,
    EVENT_PRESET,
    EVENT_FLUSH
} t_event_type;

typedef struct {
    t_event_type type;
    int note;
    int velocity;
    int preset;
} t_sound_event;

typedef struct {
    char type[16];
    int note;
    int velocity;
    double time;
} MidiMessage;

typedef void* (*create_voice_ptr)(int note, int velocity, int sample_rate);
typedef void (*note_off_voice_ptr)(void* voice_ptr);
typedef int (*process_voice_ptr)(void* voice_ptr, double* buffer, int num_samples);
typedef void (*free_voice_ptr)(void* voice_ptr);
typedef double* (*render_midi_ptr)(MidiMessage* midi_messages, int num_messages, double duration, int sample_rate, int* num_samples_out);

typedef struct {
    HINSTANCE hLib;
    create_voice_ptr create_voice;
    note_off_voice_ptr note_off_voice;
    process_voice_ptr process_voice;
    free_voice_ptr free_voice;
    render_midi_ptr render_midi;
    char name[256];
} t_sound_module;

typedef struct {
    void* voice_instance;
    create_voice_ptr create_voice;
    note_off_voice_ptr note_off_voice;
    process_voice_ptr process_voice;
    free_voice_ptr free_voice;
    int note;
    int velocity;
    int active;
    int releasing;
} t_voice;

typedef struct _sounds {
    t_pxobject obj;
    t_sound_module modules[MAX_MODULES];
    int num_modules;
    int current_module;
    t_voice voices[MAX_VOICES];
    t_critical lock;
    double sample_rate;

    t_sound_event event_queue[EVENT_QUEUE_SIZE];
    volatile int queue_head;
    volatile int queue_tail;

    t_symbol* dict_name;
    double preset_durations[MAX_MODULES];
    double last_dict_val[MAX_MODULES];
    int dict_initialized[MAX_MODULES];
    t_clock* dict_clock;
    void* outlet_preset;
} t_sounds;

void* sounds_new(t_symbol* s, long argc, t_atom* argv);
void sounds_free(t_sounds* x);
void sounds_dsp64(t_sounds* x, t_object* dsp64, short* count, double samplerate, long maxvectorsize, long flags);
void sounds_perform64(t_sounds* x, t_object* dsp64, double** ins, long numins, double** outs, long numouts, long sampleframes, long flags, void* userparam);
void sounds_list(t_sounds* x, t_symbol* s, short argc, t_atom* argv);
void sounds_midievent(t_sounds* x, t_symbol* s, short argc, t_atom* argv);
void sounds_preset(t_sounds* x, long n);
void sounds_random(t_sounds* x);
void sounds_flush(t_sounds* x);
void sounds_assist(t_sounds* x, void* b, long m, long a, char* s);
void sounds_sync_dict(t_sounds* x);
void sounds_dict_clock_tick(t_sounds* x);

static t_class* sounds_class;

void ext_main(void* r) {
    t_class* c = class_new("sounds~", (method)sounds_new, (method)sounds_free, sizeof(t_sounds), 0L, A_GIMME, 0);

    class_addmethod(c, (method)sounds_dsp64, "dsp64", A_CANT, 0);
    class_addmethod(c, (method)sounds_list, "list", A_GIMME, 0);
    class_addmethod(c, (method)sounds_midievent, "midievent", A_GIMME, 0);
    class_addmethod(c, (method)sounds_preset, "preset", A_LONG, 0);
    class_addmethod(c, (method)sounds_random, "random", 0);
    class_addmethod(c, (method)sounds_flush, "flush", 0);
    class_addmethod(c, (method)sounds_assist, "assist", A_CANT, 0);

    class_dspinit(c);
    class_register(CLASS_BOX, c);
    sounds_class = c;

    common_symbols_init();
    srand((unsigned int)time(NULL));
}

static void sounds_enqueue_event(t_sounds* x, t_sound_event ev) {
    critical_enter(x->lock);
    int next_head = (x->queue_head + 1) % EVENT_QUEUE_SIZE;
    if (next_head != x->queue_tail) {
        x->event_queue[x->queue_head] = ev;
        x->queue_head = next_head;
    }
    critical_exit(x->lock);
}

void* sounds_new(t_symbol* s, long argc, t_atom* argv) {
    t_sounds* x = (t_sounds*)object_alloc(sounds_class);

    if (x) {
        x->dict_name = _sym_nothing;
        if (argc > 0 && atom_gettype(argv) == A_SYM && strncmp(atom_getsym(argv)->s_name, "@", 1) != 0) {
            x->dict_name = atom_getsym(argv);
            argc--;
            argv++;
        }

        dsp_setup((t_pxobject*)x, 1);
        x->outlet_preset = outlet_new(x, NULL); // Preset Int (Rightmost)
        outlet_new(x, "signal"); // Right
        outlet_new(x, "signal"); // Left

        critical_new(&x->lock);
        x->num_modules = 0;
        x->current_module = 0;
        x->sample_rate = 44100.0;
        x->queue_head = 0;
        x->queue_tail = 0;

        for (int i = 0; i < MAX_VOICES; i++) {
            x->voices[i].active = 0;
            x->voices[i].voice_instance = NULL;
        }

        for (int i = 0; i < MAX_MODULES; i++) {
            x->preset_durations[i] = 1.0;
            x->last_dict_val[i] = 1.0;
            x->dict_initialized[i] = 0;
        }

        x->dict_clock = clock_new(x, (method)sounds_dict_clock_tick);

        attr_args_process(x, argc, argv);

        char module_dir_abs[MAX_PATH_CHARS];
        char module_dir_rel[] = "modules";
        short pathid = 0;
        t_fourcc type = 0;

        char object_filename[MAX_FILENAME_CHARS];
        strncpy(object_filename, "sounds~.mxe64", MAX_FILENAME_CHARS);

        if (locatefile_extended(object_filename, &pathid, &type, NULL, 0) == 0) {
            char object_path[MAX_PATH_CHARS];
            path_toabsolutesystempath(pathid, object_filename, object_path);

            char* last_slash = strrchr(object_path, '\\');
            if (!last_slash) last_slash = strrchr(object_path, '/');
            if (last_slash) {
                *last_slash = '\0';
                snprintf(module_dir_abs, MAX_PATH_CHARS, "%s\\modules", object_path);
            } else {
                strncpy(module_dir_abs, module_dir_rel, MAX_PATH_CHARS);
            }
        } else {
            strncpy(module_dir_abs, module_dir_rel, MAX_PATH_CHARS);
        }

        char search_path[MAX_PATH_CHARS];
        snprintf(search_path, MAX_PATH_CHARS, "%s\\*.dll", module_dir_abs);

        WIN32_FIND_DATA findData;
        HANDLE hFind = FindFirstFile(search_path, &findData);
        if (hFind != INVALID_HANDLE_VALUE) {
            do {
                if (x->num_modules >= MAX_MODULES) break;

                char dllPath[MAX_PATH_CHARS];
                snprintf(dllPath, MAX_PATH_CHARS, "%s\\%s", module_dir_abs, findData.cFileName);

                HINSTANCE h = LoadLibrary(dllPath);
                if (h) {
                    create_voice_ptr create_fn = (create_voice_ptr)GetProcAddress(h, "create_voice");
                    note_off_voice_ptr off_fn = (note_off_voice_ptr)GetProcAddress(h, "note_off_voice");
                    process_voice_ptr proc_fn = (process_voice_ptr)GetProcAddress(h, "process_voice");
                    free_voice_ptr free_fn = (free_voice_ptr)GetProcAddress(h, "free_voice");
                    render_midi_ptr render_fn = (render_midi_ptr)GetProcAddress(h, "render_midi");

                    if (create_fn && off_fn && proc_fn && free_fn) {
                        x->modules[x->num_modules].hLib = h;
                        x->modules[x->num_modules].create_voice = create_fn;
                        x->modules[x->num_modules].note_off_voice = off_fn;
                        x->modules[x->num_modules].process_voice = proc_fn;
                        x->modules[x->num_modules].free_voice = free_fn;
                        x->modules[x->num_modules].render_midi = render_fn;
                        strncpy(x->modules[x->num_modules].name, findData.cFileName, 256);
                        x->num_modules++;
                        object_post((t_object*)x, "Loaded module %d: %s", x->num_modules, findData.cFileName);
                    } else {
                        FreeLibrary(h);
                    }
                }
            } while (FindNextFile(hFind, &findData));
            FindClose(hFind);
        }

        if (x->num_modules == 0) {
            object_error((t_object*)x, "No sound modules found in %s directory!", module_dir_abs);
        }

        if (x->dict_name != _sym_nothing) {
            sounds_sync_dict(x);
            clock_delay(x->dict_clock, 100);
        }
    }
    return x;
}

void sounds_free(t_sounds* x) {
    dsp_free((t_pxobject*)x);
    if (x->dict_clock) {
        object_free(x->dict_clock);
        x->dict_clock = NULL;
    }
    if (x->dict_name != _sym_nothing) {
        sounds_sync_dict(x);
    }
    critical_enter(x->lock);
    for (int i = 0; i < MAX_VOICES; i++) {
        if (x->voices[i].active && x->voices[i].voice_instance && x->voices[i].free_voice) {
            x->voices[i].free_voice(x->voices[i].voice_instance);
            x->voices[i].voice_instance = NULL;
            x->voices[i].active = 0;
        }
    }
    for (int i = 0; i < x->num_modules; i++) {
        FreeLibrary(x->modules[i].hLib);
    }
    critical_exit(x->lock);
    critical_free(x->lock);
}

void sounds_dict_clock_tick(t_sounds* x) {
    if (x->dict_name != _sym_nothing) {
        sounds_sync_dict(x);
        clock_delay(x->dict_clock, 100);
    }
}

void sounds_sync_dict(t_sounds* x) {
    if (!x || x->dict_name == _sym_nothing || x->num_modules == 0) return;

    critical_enter(x->lock);
    t_dictionary* d = dictobj_findregistered_retain(x->dict_name);
    if (!d) {
        critical_exit(x->lock);
        return;
    }

    int dict_changed = 0;

    for (int i = 0; i < x->num_modules; i++) {
        char key_str[32];
        snprintf(key_str, sizeof(key_str), "%d", i + 1);
        t_symbol* key_sym = gensym(key_str);

        if (!x->dict_initialized[i]) {
            if (dictionary_hasentry(d, key_sym)) {
                double val = 1.0;
                t_atom a;
                if (dictionary_getatom(d, key_sym, &a) == MAX_ERR_NONE) {
                    if (atom_gettype(&a) == A_FLOAT) val = atom_getfloat(&a);
                    else if (atom_gettype(&a) == A_LONG) val = (double)atom_getlong(&a);
                }
                x->preset_durations[i] = val;
                x->last_dict_val[i] = val;
            } else {
                x->preset_durations[i] = 1.0;
                x->last_dict_val[i] = 1.0;
                t_atom a;
                atom_setfloat(&a, 1.0);
                dictionary_appendatom(d, key_sym, &a);
                dict_changed = 1;
            }
            x->dict_initialized[i] = 1;
        } else {
            if (dictionary_hasentry(d, key_sym)) {
                t_atom a;
                if (dictionary_getatom(d, key_sym, &a) == MAX_ERR_NONE) {
                    double current_dict_val = 0.0;
                    if (atom_gettype(&a) == A_FLOAT) current_dict_val = atom_getfloat(&a);
                    else if (atom_gettype(&a) == A_LONG) current_dict_val = (double)atom_getlong(&a);

                    if (fabs(current_dict_val - x->last_dict_val[i]) > 1e-6) {
                        double diff = current_dict_val - x->last_dict_val[i];
                        x->preset_durations[i] += diff;
                    }
                }
            }

            if (fabs(x->preset_durations[i] - x->last_dict_val[i]) > 1e-6 || !dictionary_hasentry(d, key_sym)) {
                t_atom a;
                atom_setfloat(&a, (float)x->preset_durations[i]);
                dictionary_appendatom(d, key_sym, &a);
                x->last_dict_val[i] = x->preset_durations[i];
                dict_changed = 1;
            }
        }
    }
    critical_exit(x->lock);

    if (dict_changed) {
        object_notify((t_object *)d, gensym("modified"), NULL);
    }
    dictobj_release(d);
}

void sounds_preset(t_sounds* x, long n) {
    if (x->num_modules == 0) return;
    long zero_based = (n - 1) % x->num_modules;
    if (zero_based < 0) zero_based += x->num_modules;

    t_sound_event ev;
    ev.type = EVENT_PRESET;
    ev.preset = (int)zero_based;
    sounds_enqueue_event(x, ev);

    object_post((t_object*)x, "Switched to preset %d: %s", (int)zero_based + 1, x->modules[zero_based].name);
    if (x->outlet_preset) {
        outlet_int(x->outlet_preset, (int)zero_based + 1);
    }
}

void sounds_flush(t_sounds* x) {
    t_sound_event ev;
    ev.type = EVENT_FLUSH;
    sounds_enqueue_event(x, ev);
}

void sounds_random(t_sounds* x) {
    if (x->num_modules <= 1) return;

    if (x->dict_name == _sym_nothing) {
        int next = rand() % x->num_modules;
        while (next == x->current_module) next = rand() % x->num_modules;
        sounds_preset(x, next + 1);
    } else {
        sounds_sync_dict(x);

        critical_enter(x->lock);
        double total_weight = 0.0;
        for (int i = 0; i < x->num_modules; i++) {
            double w = x->preset_durations[i];
            if (w < 0.0) w = 0.0;
            total_weight += w;
        }

        if (total_weight <= 0.0) {
            critical_exit(x->lock);
            int next = rand() % x->num_modules;
            while (next == x->current_module) next = rand() % x->num_modules;
            sounds_preset(x, next + 1);
            return;
        }

        double r = ((double)rand() / ((double)RAND_MAX + 1.0)) * total_weight;
        int chosen = x->num_modules - 1;
        double accum = 0.0;
        for (int i = 0; i < x->num_modules; i++) {
            double w = x->preset_durations[i];
            if (w < 0.0) w = 0.0;
            accum += w;
            if (r < accum) {
                chosen = i;
                break;
            }
        }
        critical_exit(x->lock);

        sounds_preset(x, chosen + 1);
    }
}

void sounds_midievent(t_sounds* x, t_symbol* s, short argc, t_atom* argv) {
    if (argc < 1) return;

    long status = atom_getlong(&argv[0]);
    long cmd = status & 0xF0;

    switch (cmd) {
        case 0x80: { // Note Off
            if (argc >= 2) {
                long note = atom_getlong(&argv[1]);
                t_atom list_argv[2];
                atom_setlong(&list_argv[0], note);
                atom_setlong(&list_argv[1], 0);
                sounds_list(x, NULL, 2, list_argv);
            }
            break;
        }
        case 0x90: { // Note On
            if (argc >= 3) {
                long note = atom_getlong(&argv[1]);
                long vel = atom_getlong(&argv[2]);
                t_atom list_argv[2];
                atom_setlong(&list_argv[0], note);
                atom_setlong(&list_argv[1], vel);
                sounds_list(x, NULL, 2, list_argv);
            } else if (argc >= 2) {
                long note = atom_getlong(&argv[1]);
                t_atom list_argv[2];
                atom_setlong(&list_argv[0], note);
                atom_setlong(&list_argv[1], 64);
                sounds_list(x, NULL, 2, list_argv);
            }
            break;
        }
        case 0xC0: { // Program Change
            if (argc >= 2) {
                long pgm = atom_getlong(&argv[1]);
                sounds_preset(x, pgm + 1);
            }
            break;
        }
        default:
            break;
    }
}

void sounds_list(t_sounds* x, t_symbol* s, short argc, t_atom* argv) {
    if (argc < 2) return;
    int note = atom_getlong(argv);
    int velocity = atom_getlong(argv + 1);

    if (x->num_modules == 0) return;

    t_sound_event ev;
    if (velocity > 0) {
        ev.type = EVENT_NOTE_ON;
        ev.note = note;
        ev.velocity = velocity;
    } else {
        ev.type = EVENT_NOTE_OFF;
        ev.note = note;
        ev.velocity = 0;
    }
    sounds_enqueue_event(x, ev);
}

void sounds_dsp64(t_sounds* x, t_object* dsp64, short* count, double samplerate, long maxvectorsize, long flags) {
    x->sample_rate = samplerate;
    dsp_add64(dsp64, (t_object*)x, (t_perfroutine64)sounds_perform64, 0, NULL);
}

static void sounds_log_dsp_stall(void *x, double duration_ms, long sampleframes) {
    FILE *f = fopen("max_dsp_stall_breadcrumbs.log", "a");
    if (f) {
        fprintf(f, "[DSP STALL] sounds~ %p: perform64 took %.3f ms for %ld sampleframes (> 10.0ms)\n", x, duration_ms, sampleframes);
        fflush(f);
        fclose(f);
    }
}

void sounds_perform64(t_sounds* x, t_object* dsp64, double** ins, long numins, double** outs, long numouts, long sampleframes, long flags, void* userparam) {
    double t0 = (double)systime_ms();
    double* outL = outs[0];
    double* outR = outs[1];

    for (int i = 0; i < sampleframes; i++) {
        outL[i] = 0.0;
        outR[i] = 0.0;
    }

    // Process queued events in the audio thread
    while (x->queue_tail != x->queue_head) {
        t_sound_event ev = x->event_queue[x->queue_tail];
        x->queue_tail = (x->queue_tail + 1) % EVENT_QUEUE_SIZE;

        if (ev.type == EVENT_PRESET) {
            if (ev.preset >= 0 && ev.preset < x->num_modules) {
                x->current_module = ev.preset;
            }
        } else if (ev.type == EVENT_FLUSH) {
            for (int i = 0; i < MAX_VOICES; i++) {
                if (x->voices[i].active && !x->voices[i].releasing) {
                    x->voices[i].releasing = 1;
                    if (x->voices[i].note_off_voice && x->voices[i].voice_instance) {
                        x->voices[i].note_off_voice(x->voices[i].voice_instance);
                    }
                }
            }
        } else if (ev.type == EVENT_NOTE_OFF) {
            for (int i = 0; i < MAX_VOICES; i++) {
                if (x->voices[i].active && x->voices[i].note == ev.note && !x->voices[i].releasing) {
                    x->voices[i].releasing = 1;
                    if (x->voices[i].note_off_voice && x->voices[i].voice_instance) {
                        x->voices[i].note_off_voice(x->voices[i].voice_instance);
                    }
                    break;
                }
            }
        } else if (ev.type == EVENT_NOTE_ON) {
            if (x->num_modules > 0 && x->current_module >= 0 && x->current_module < x->num_modules) {
                t_sound_module* mod = &x->modules[x->current_module];
                if (mod->create_voice) {
                    void* new_inst = mod->create_voice(ev.note, ev.velocity, (int)x->sample_rate);
                    if (new_inst) {
                        // Issue #3 Solution: Put existing active voice on same pitch into release mode
                        for (int i = 0; i < MAX_VOICES; i++) {
                            if (x->voices[i].active && x->voices[i].note == ev.note && !x->voices[i].releasing) {
                                x->voices[i].releasing = 1;
                                if (x->voices[i].note_off_voice && x->voices[i].voice_instance) {
                                    x->voices[i].note_off_voice(x->voices[i].voice_instance);
                                }
                            }
                        }

                        // Find a free voice slot
                        int voice_idx = -1;
                        for (int i = 0; i < MAX_VOICES; i++) {
                            if (!x->voices[i].active) {
                                voice_idx = i;
                                break;
                            }
                        }

                        // If all slots active, find a slot currently in release
                        if (voice_idx == -1) {
                            for (int i = 0; i < MAX_VOICES; i++) {
                                if (x->voices[i].releasing) {
                                    voice_idx = i;
                                    break;
                                }
                            }
                        }

                        // Fallback: steal slot 0
                        if (voice_idx == -1) {
                            voice_idx = 0;
                        }

                        if (x->voices[voice_idx].active && x->voices[voice_idx].voice_instance && x->voices[voice_idx].free_voice) {
                            x->voices[voice_idx].free_voice(x->voices[voice_idx].voice_instance);
                            x->voices[voice_idx].voice_instance = NULL;
                        }

                        x->voices[voice_idx].voice_instance = new_inst;
                        x->voices[voice_idx].create_voice = mod->create_voice;
                        x->voices[voice_idx].note_off_voice = mod->note_off_voice;
                        x->voices[voice_idx].process_voice = mod->process_voice;
                        x->voices[voice_idx].free_voice = mod->free_voice;
                        x->voices[voice_idx].note = ev.note;
                        x->voices[voice_idx].velocity = ev.velocity;
                        x->voices[voice_idx].releasing = 0;
                        x->voices[voice_idx].active = 1;
                    }
                }
            }
        }
    }

    double temp_buf[2048];
    int active_voices = 0;

    for (int offset = 0; offset < (int)sampleframes; offset += 2048) {
        int frames_to_process = ((int)sampleframes - offset > 2048) ? 2048 : ((int)sampleframes - offset);

        for (int v = 0; v < MAX_VOICES; v++) {
            if (x->voices[v].active && x->voices[v].voice_instance && x->voices[v].process_voice) {
                memset(temp_buf, 0, frames_to_process * sizeof(double));
                int still_active = x->voices[v].process_voice(x->voices[v].voice_instance, temp_buf, frames_to_process);

                for (int i = 0; i < frames_to_process; i++) {
                    outL[offset + i] += temp_buf[i];
                    outR[offset + i] += temp_buf[i];
                }

                if (!still_active) {
                    if (x->voices[v].free_voice) {
                        x->voices[v].free_voice(x->voices[v].voice_instance);
                    }
                    x->voices[v].voice_instance = NULL;
                    x->voices[v].active = 0;
                    x->voices[v].releasing = 0;
                } else if (offset == 0) {
                    active_voices++;
                }
            }
        }
    }

    if (active_voices > 0 && x->dict_name != _sym_nothing && x->num_modules > 0) {
        if (x->current_module >= 0 && x->current_module < x->num_modules) {
            double delta_sec = (double)sampleframes / x->sample_rate;
            x->preset_durations[x->current_module] += delta_sec;
        }
    }

    double duration_ms = (double)systime_ms() - t0;
    if (duration_ms > 10.0) {
        sounds_log_dsp_stall(x, duration_ms, sampleframes);
    }
}

void sounds_assist(t_sounds* x, void* b, long m, long a, char* s) {
    if (m == ASSIST_INLET) {
        sprintf(s, "MIDI (list), midievent, messages (flush, preset, random). Optional argument: duration dict name");
    } else {
        if (a == 0) sprintf(s, "(signal) Left Output");
        else if (a == 1) sprintf(s, "(signal) Right Output");
        else if (a == 2) sprintf(s, "(int) Current Preset Index (1-based)");
    }
}
